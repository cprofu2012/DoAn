#include <htc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "uart.h"

__CONFIG(XT & WDTDIS& LVPDIS);

void main()
{
	// 2: UART
	uart_init();
	// 3: test UART
	uart_puts("1");
//	uart_puts("0987654321");
	__delay_ms(100);
	asm("SLEEP");
}