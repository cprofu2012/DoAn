#ifndef _TOUCH_H_
#define _TOUCH_H_

#define PERCENT_ON		30
#define DEBOUNCE	5
void touch_init();
void touch_service();
void touch_close();
extern volatile bit touch_pressed;
#endif