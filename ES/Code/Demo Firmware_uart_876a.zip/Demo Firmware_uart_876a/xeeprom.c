#include <htc.h>
#include "xeeprom.h"

void spi_init()
{
	SSPEN = 0;
	// IO PORT
	TRISC3 = 0;		// SCK la output
	TRISC5 = 0;		// SDO la output
	TRISC4 = 1;		// SDI la input
	TRISD0 = 0;		// 25LC256 chip select
	RD0 = 1;		// deselect chip
	
	//SSPSTAT 
	SMP = 1; 		// lay mau o giua chu ky bus
	CKE = 1; 		// du lieu ra tren SDO theo canh lenh cua SCK
	//SSPCON
	SSPCON = 0b00100000;	// CKP = 0, SPI mode baudrate = Fosc/4
}

unsigned char spi(unsigned char b)
{
	WCOL = 0;		// clear any write collision condition
	SSPIF = 0;		// clear SSP interrupt flag
	SSPBUF = b;		// load the SSP buffer with data
	while(!SSPIF);	// wait for SSPIF to be set
	return SSPBUF;
}
void xeeprom_read(unsigned int address, unsigned int byte_count, unsigned char *data)
{
	RD0 = 0;			// enable access
	
	spi(0x03);			// READ command
	spi(address>>8);	// address MSB first
	spi(address&0xFF);	//
	
	while(byte_count--){
		*data++ = spi(0xff);
	}
	
	RD0 = 1;			// disable access
}
void xeeprom_page_write(unsigned int address, unsigned int byte_count, const unsigned char *data)
{
	while(xeeprom_status()&0x01);
	RD0 = 0;			// enable access
	spi(0x06);			// WREN command
	RD0 = 1;			// disable access
	
	while(xeeprom_status()&0x01);
	
	RD0 = 0;
	spi(0x02);			// WRITE command
	spi(address>>8);	// address MSB first
	spi(address&0xFF);	//
	
	while(byte_count--){
		spi(*data++);
	}
	RD0 = 1;			// disable access
}
void xeeprom_write(unsigned int address, unsigned int byte_count, const unsigned char *data)
{
	unsigned char byte_write = 64 - (address & 0x3F); // number of byte from address in this page
	
	// check if number of byte to be written is fit in this page
	if(byte_write>=byte_count)
		byte_write = byte_count;
	
	while(byte_count){
		xeeprom_page_write(address, byte_write, data);
		// update data pointer
		byte_count -= byte_write;
		data += byte_write;
		address += byte_write;
		
		if(byte_count>64)byte_write = 64;
		else byte_write = byte_count;
		while(xeeprom_status()&0x01);
	}
}
unsigned char xeeprom_status()
{
	unsigned char tmp;
	
	RD0 = 0;			// enable access
	spi(0x05);			// READ STATUS
	tmp = spi(0xff);
	RD0 = 1;			// disable access
	
	return tmp;
}