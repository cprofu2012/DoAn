#include <htc.h>
#include <stdio.h>
#include "touch.h"

volatile bit touch_pressed=0;

static volatile bit touch_initialized = 0;
static volatile unsigned char calibrate;
static volatile long average;

void touch_init()
{
	TRISA0 = 1;		// C12IN0-
	TRISA2 = 1;		// C2IN+
	ANS2 = 1;		// 
	ANS0 = 1;
	
	TRISA5 = 0;		// C2OUT
	ANS5 = 0;
	
	TRISC0 = 1;		// T1CKI
	
	// comparator 1
	C1OE = 1;
	C1POL = 1;
	C1R = 1;
	C1ON = 1;
	// comparator 2
	C2OE = 1;
	C2ON = 1;
	
	CM2CON1 = 0b00100000;
	
	// VREF = 2/3 Vdd
	//VRCON = 0b10001111;
	VRCON = 0b10001111;
	// SR latch control
	SRCON = 0xF0;
	// timer 1
	TMR1L = 0;
	TMR1H = 0;
	average = 0;
	calibrate = 128;
	touch_initialized = 1;
	T1CON = 0b00000111;
}
void touch_close()
{
	TRISA5 = 1;
	CM1CON0 = 0;
	CM2CON0 = 0;
	T1CON = 0;
	touch_initialized = 0;
}
void touch_service()
{
	static unsigned char debounce = DEBOUNCE;
	long raw, percent;
	
	if(!touch_initialized) return;
	
	TMR1ON = 0;			// dung timer 1
	// 1: Doc gia tri timer 1
	raw = ((unsigned int)TMR1H<<8) + TMR1L;
	
	// 2: khi moi khoi dong can tinh toan gia tri Average ban dau de lam moc so sanh
	if(calibrate){
		average = (average * 15 + raw)/16;
		calibrate--;
		TMR1L = 0;
		TMR1H = 0;
		TMR1ON = 1;
		return;
	}
	
	if(average==0){
		TMR1L = 0;
		TMR1H = 0;
		TMR1ON = 1;
		return;
	}
	
	// 3: tinh toan % thay doi cua gia tri raw so voi gia tri trung binh Average
	percent = average - raw;
	if(percent<0)
		percent = 0;
	else{
		percent *= 1000;
		percent /= average;
	}
	
	// 4: kiem tra neu su thay doi vuot qua nguong dinh san
	if(percent > PERCENT_ON){			// pressed
		if(debounce==0)
			touch_pressed = 1;
		else
			debounce--;
			
	}else{
		debounce = DEBOUNCE;
		touch_pressed = 0;
		average = (average * 15 + raw)/16;
		if(raw > average)
			average = (average * 15 + raw)/16;
	}
	
	
	// 5: reset timer1, dem lai tu dau
	TMR1L = 0;
	TMR1H = 0;
	TMR1ON = 1;
}
