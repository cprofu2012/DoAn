#include <htc.h>
#include "led.h"

volatile LED led;
volatile bit SW4, SW5, SW6, SW7, SW8, SW9, SW10;

void led_button_init()
{
	TRISB |= 0x07;			// SW4, SW5, SW6
	TRISA4 = 1;				// SW7
	TRISE |= 0b00000110;
	ANSELH = 0;
	WPUB = 0b00000111;		// SW4, SW5, SW6
	RBPU = 0;
	led.val = 0;
}

void led_button_scan()
{
	static unsigned char count;
	PORTE |= 0b00000110;
	TRISE |= 0b00000110;
	TRISB |= 0b00111000;			// turn all LEDs off
	_delay(20);
	// kiem tra phim bam
	if(!RB0)SW4 = 1;
	else SW4 = 0;
	
	if(!RB1)SW5 = 1;
	else SW5 = 0;
	
	if(!RB2)SW6 = 1;
	else SW6 = 0;
	
	SW8=0;SW9=0;
	if(!RA4)SW7 = 1;
	else{
		SW7 = 0;
		RB3 = 0;TRISB3=0;
		_delay(20);
		if(!RA4)SW8 = 1;
		else SW8 = 0;
		TRISB3 = 1;
		
		RB4 = 0;TRISB4=0;
		_delay(20);
		if(!RA4)SW9 = 1;
		else SW9 = 0;
		TRISB4 = 1;
		
		RB5 = 0;TRISB5=0;
		_delay(20);
		if(!RA4)SW10 = 1;
		else SW10 = 0;
		TRISB5 = 1;
	}
	
	switch(count){
		case 0:
			if(led.bits.l0){
				TRISE2 = 0;
			}
		case 1:
			if(led.bits.l1){
				TRISE1 = 0;
			}
			break;
		case 2:
			if(led.bits.l2){
				TRISB3 = 0;
				TRISB4 = 0;
				RB3 = 1;
				RB4 = 0;
			}
			break;
		case 3:
			if(led.bits.l3){
				TRISB3 = 0;
				TRISB4 = 0;
				RB3 = 0;
				RB4 = 1;
			}
			break;
		case 4:
			if(led.bits.l4){
				TRISB4 = 0;
				TRISB5 = 0;
				RB4 = 1;
				RB5 = 0;
			}
			break;
		case 5:
			if(led.bits.l5){
				TRISB4 = 0;
				TRISB5 = 0;
				RB4 = 0;
				RB5 = 1;
			}
			break;
		case 6:
			if(led.bits.l6){
				TRISB3 = 0;
				TRISB5 = 0;
				RB3 = 0;
				RB5 = 1;
			}
			break;
		case 7:
			if(led.bits.l7){
				TRISB3 = 0;
				TRISB5 = 0;
				RB3 = 1;
				RB5 = 0;
			}
			break;
	}
	
	count++;
	if(count>7)count=0;
	
}