#ifndef _XEEPROM_H_
#define _XEEPROM_H_
void spi_init();
void xeeprom_read(unsigned int address, unsigned int byte_count, unsigned char *data);
void xeeprom_write(unsigned int address, unsigned int byte_count, const unsigned char *data);
unsigned char xeeprom_status();
#endif
