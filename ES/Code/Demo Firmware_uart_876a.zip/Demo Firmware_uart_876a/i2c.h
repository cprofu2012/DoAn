#ifndef	_I2C_H_
#define	_I2C_H_

void i2c_start();
void i2c_stop();
void i2c_init();
void i2c_restart();
unsigned char i2c_read(unsigned char ack);
unsigned char i2c_write(unsigned char d);

#endif