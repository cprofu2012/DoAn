#ifndef _LED_H_
#define _LED_H_

typedef union {
	unsigned char val;
	struct{
		unsigned l0:1;
		unsigned l1:1;
		unsigned l2:1;
		unsigned l3:1;
		unsigned l4:1;
		unsigned l5:1;
		unsigned l6:1;
		unsigned l7:1;
	}bits;
} LED;

extern volatile LED led;
extern volatile bit SW4, SW5, SW6, SW7, SW8, SW9, SW10;

void led_button_scan();
void led_button_init();

#endif