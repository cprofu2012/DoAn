﻿using System;
using System.Data;
using System.Windows.Forms;
using GasManager;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_ImportExport
{
    /// <summary>
    /// Form Export new products
    /// </summary>
    public partial class ExportToUse_Add : Form
    {
        private const string IDENTIFY_VALUE_GAS = "1";
        private const string IDENTIFY_VALUE_SHELL = "3";
        private const string IDENTIFY_VALUE_VALVE = "2";
        private readonly GSS_GasTableAdapter _gasAdapter = new GSS_GasTableAdapter();
        private readonly GSS_OrderTableAdapter _orderAdapter = new GSS_OrderTableAdapter();
        private readonly ExportToUse _parent;
        private readonly GSS_ShellTableAdapter _shellAdapter = new GSS_ShellTableAdapter();
        private readonly GSS_ValveTableAdapter _valveAdapter = new GSS_ValveTableAdapter();
        private int STORE_CUSTOMER_ID;

        /// <summary>
        /// Initializes a new instance of the "ExportToUse_Add" form.
        /// </summary>
        /// <param name="parent">The form Export products.</param>
        public ExportToUse_Add(ExportToUse parent)
        {
            InitializeComponent();
            _parent = parent;
            GetProductsDataTable(cbb_ImportProduct, null);
        }

        /// <summary>
        /// Handles the TextChanged event of the textbox quantity.
        /// </summary>
        private void quantity_TextChanged(object sender, EventArgs e)
        {
            for (int count = 0; count < txt_quantity.Text.Length; count++)
            {
                if ((txt_quantity.Text[count]) != '0'
                    && (txt_quantity.Text[count]) != '1'
                    && (txt_quantity.Text[count]) != '2'
                    && (txt_quantity.Text[count]) != '3'
                    && (txt_quantity.Text[count]) != '4'
                    && (txt_quantity.Text[count]) != '5'
                    && (txt_quantity.Text[count]) != '6'
                    && (txt_quantity.Text[count]) != '7'
                    && (txt_quantity.Text[count]) != '8'
                    && (txt_quantity.Text[count]) != '9'
                    )
                {
                    txt_quantity.Text = txt_quantity.Text.Remove(count, 1);
                    count--;
                }
            }
        }

        /// <summary>
        /// Gets the products data table.
        /// </summary>
        /// <param name="combobox">The combobox.</param>
        /// <param name="selectedValue">The selected value of the combobox.</param>
        public void GetProductsDataTable(ComboBox combobox, object selectedValue)
        {
            var dataTable = new DataTable();
            dataTable.Columns.Add(Definitions.FIELD_TEXT);
            dataTable.Columns.Add(Definitions.FIELD_VALUE);
            combobox.DataSource = dataTable;
            combobox.DisplayMember = Definitions.FIELD_TEXT;
            combobox.ValueMember = Definitions.FIELD_VALUE;

            var gases = _gasAdapter.GetGass();
            var valves = _valveAdapter.GetValves();
            var shelles = _shellAdapter.GetShells();

            foreach (var gas in gases)
            {
                dataTable.Rows.Add(new object[] {gas.gas_Name, IDENTIFY_VALUE_GAS + "|" + gas.gas_Id});
            }
            foreach (var valve in valves)
            {
                dataTable.Rows.Add(new object[] {valve.valve_Name, IDENTIFY_VALUE_VALVE + "|" + valve.valve_Id});
            }
            foreach (var shell in shelles)
            {
                dataTable.Rows.Add(new object[] {shell.shell_Name, IDENTIFY_VALUE_SHELL + "|" + shell.shell_Id});
            }


            if (selectedValue != null && selectedValue != DBNull.Value)
                combobox.SelectedValue = selectedValue;
            else if (dataTable.Rows.Count > 0)
                combobox.SelectedValue = dataTable.Rows[0][1];
        }

        /// <summary>
        /// Handles the Click event of the button Save.
        /// </summary>
        private void btn_save_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(txt_quantity.Text.Trim()) == 0)
            {
                MessageBox.Show(Resources.Msb_Export_Add_Zero_Error, Resources.Msb_Title_Import_Product_Error,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            string productDetail = cbb_ImportProduct.SelectedValue.ToString();
            string[] strList = productDetail.Split(new[] {'|'});
            int productId = Int32.Parse(strList[1]);

            int quantity = Int32.Parse(txt_quantity.Text);

            int price = 0;
            int originalQuantity = 0;

            if (strList[0].Equals(IDENTIFY_VALUE_GAS))
            {
                DataAccessLayer.GSS.GSS_GasDataTable gases = _gasAdapter.GetDataById(productId);
                foreach (DataAccessLayer.GSS.GSS_GasRow gas in gases)
                {
                    price = gas.gas_Price;
                    originalQuantity = gas.gas_Quantity;
                }

                if (originalQuantity < quantity)
                {
                    MessageBox.Show(Resources.Msb_Export_Over_Maximum_Error + originalQuantity,
                        Resources.Msb_Title_Export_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                _orderAdapter.InsertGasExportToUse(STORE_CUSTOMER_ID, quantity, DateTime.Now, productId,
                    Resources.ExportToUse, price*quantity, MainForm._user.user_Id);
                _gasAdapter.UpdateQuantity(originalQuantity - quantity, productId);
            }
            else if (strList[0].Equals(IDENTIFY_VALUE_VALVE))
            {
                var valves = _valveAdapter.GetValveImportPriceById(productId);

                foreach (var valve in valves)
                {
                    price = valve.valve_Price;
                    originalQuantity = valve.valve_Quantity;
                }

                if (originalQuantity < quantity)
                {
                    MessageBox.Show(Resources.Msb_Export_Over_Maximum_Error +
                                    originalQuantity);
                    return;
                }

                _orderAdapter.InsertValveExportToUse(
                    STORE_CUSTOMER_ID,
                    quantity,
                    DateTime.Now,
                    productId,
                    Resources.ExportToUse,
                    price*quantity,
                    MainForm._user.user_Id);
                _valveAdapter.UpdateQuantity(originalQuantity - quantity, productId);
            }
            else if (strList[0].Equals(IDENTIFY_VALUE_SHELL))
            {
                var shell = _shellAdapter.GetImportPriceById(productId);

                foreach (var gas in shell)
                {
                    price = gas.shell_Price;
                    originalQuantity = gas.shell_Quantity;
                }

                if (originalQuantity < quantity)
                {
                    MessageBox.Show(Resources.Msb_Export_Over_Maximum_Error +
                                    originalQuantity);
                    return;
                }

                _orderAdapter.InsertShellExportToUse(
                    STORE_CUSTOMER_ID,
                    quantity,
                    DateTime.Now,
                    Resources.ExportToUse,
                    productId,
                    price*quantity,
                    MainForm._user.user_Id);

                _shellAdapter.UpdateQuantity(originalQuantity - quantity, productId);
            }

            _parent.GetOrders();
        }
    }
}