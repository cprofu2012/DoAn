﻿using System;
using System.Collections;
using System.Data;
using System.Windows.Forms;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;

namespace GSS.View.Menu_ImportExport
{
    /// <summary>
    ///   Import product's form
    /// </summary>
    public partial class ImportProduct : Form
    {
        private const string IDENTIFY_VALUE_GAS = "1";
        private const string IDENTIFY_VALUE_SHELL = "3";
        private const string IDENTIFY_VALUE_VALVE = "2";
        private readonly GSS_GasTableAdapter _gasAdapter = new GSS_GasTableAdapter();
        private readonly GSS_GasImportTableAdapter _gasImportAdapter = new GSS_GasImportTableAdapter();
        private readonly GSS_ShellTableAdapter _shellAdapter = new GSS_ShellTableAdapter();
        private readonly GSS_ShellImportTableAdapter _shellImportAdapter = new GSS_ShellImportTableAdapter();
        private readonly GSS_ValveTableAdapter _valveAdapter = new GSS_ValveTableAdapter();
        private readonly GSS_ValveImportTableAdapter _valveImportAdapter = new GSS_ValveImportTableAdapter();

        /// <summary>
        ///   Initializes a new instance of the "ImportProduct" form.
        /// </summary>
        public ImportProduct()
        {
            InitializeComponent();
            LoadImport();
        }

        /// <summary>
        ///   Loads imports record.
        /// </summary>
        public void LoadImport()
        {
            dtg_export.Rows.Clear();
            var product = new Hashtable();

            var gasAdapter = new GSS_GasTableAdapter();
            var valveAdapter = new GSS_ValveTableAdapter();
            var shellAdapter = new GSS_ShellTableAdapter();

            var gasses = gasAdapter.GetGass();
            var valves = valveAdapter.GetValves();
            var shelles = shellAdapter.GetShells();

            foreach (var gas in gasses)
            {
                product.Add(IDENTIFY_VALUE_GAS + "|" + gas.gas_Id, gas.gas_Name);
            }
            foreach (var valve in valves)
            {
                product.Add(IDENTIFY_VALUE_VALVE + "|" + valve.valve_Id, valve.valve_Name);
            }
            foreach (var shell in shelles)
            {
                product.Add(IDENTIFY_VALUE_SHELL + "|" + shell.shell_Id, shell.shell_Name);
            }


            var gasimportdt = _gasImportAdapter.GetData();
            var valveimportdt = _valveImportAdapter.GetData();
            var shellimportdt = _shellImportAdapter.GetData();

            foreach (var gas in gasimportdt)
            {
                dtg_export.Rows.Add(new[] {gas.gi_date, product[IDENTIFY_VALUE_GAS + "|" + gas.gas_id], gas.gi_quantity});
            }
            foreach (var valve in valveimportdt)
            {
                dtg_export.Rows.Add(new[]
                                        {
                                            valve.vi_date, product[IDENTIFY_VALUE_VALVE + "|" + valve.valve_id],
                                            valve.vi_quantity
                                        });
            }
            foreach (var shell in shellimportdt)
            {
                dtg_export.Rows.Add(new[]
                                        {
                                            shell.si_date, product[IDENTIFY_VALUE_SHELL + "|" + shell.shell_id],
                                            shell.si_quantity
                                        });
            }
        }

        /// <summary>
        ///   Gets the products data table.
        /// </summary>
        /// <param name = "combobox">The combobox.</param>
        /// <param name = "SelectedValue">The selected value of the combobox.</param>
        public void GetProductsDataTable(DataGridViewComboBoxCell combobox, object SelectedValue)
        {
            var dataTable = new DataTable();
            dataTable.Columns.Add(Definitions.FIELD_TEXT);
            dataTable.Columns.Add(Definitions.FIELD_VALUE);
            combobox.DataSource = dataTable;
            combobox.DisplayMember = Definitions.FIELD_TEXT;
            combobox.ValueMember = Definitions.FIELD_VALUE;

            var gases = _gasAdapter.GetGass();
            var valves = _valveAdapter.GetValves();
            var shelles = _shellAdapter.GetShells();

            foreach (var gas in gases)
            {
                dataTable.Rows.Add(new object[] {gas.gas_Name, IDENTIFY_VALUE_GAS + "|" + gas.gas_Id});
            }
            foreach (var valve in valves)
            {
                dataTable.Rows.Add(new object[] {valve.valve_Name, IDENTIFY_VALUE_VALVE + "|" + valve.valve_Id});
            }
            foreach (var shell in shelles)
            {
                dataTable.Rows.Add(new object[] {shell.shell_Name, IDENTIFY_VALUE_SHELL + "|" + shell.shell_Id});
            }


            if (SelectedValue != null && SelectedValue != DBNull.Value)
                combobox.Value = SelectedValue;
            else if (dataTable.Rows.Count > 0)
                combobox.Value = dataTable.Rows[0][1];
        }

        /// <summary>
        ///   Handles the Click event of the button Add.
        /// </summary>
        private void btn_add_Click(object sender, EventArgs e)
        {
            var importProductAdd = new ImportProduct_Add(this);
            importProductAdd.ShowDialog();
        }
    }
}