﻿using System;
using System.Data;
using System.Windows.Forms;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_ImportExport
{
    /// <summary>
    /// Form import new products
    /// </summary>
    public partial class ImportProduct_Add : Form
    {
        private const string IDENTIFY_VALUE_GAS = "1";
        private const string IDENTIFY_VALUE_SHELL = "3";
        private const string IDENTIFY_VALUE_VALVE = "2";
        private readonly GSS_GasTableAdapter _gasAdapter = new GSS_GasTableAdapter();
        private readonly GSS_GasImportTableAdapter _gasImportAdapter = new GSS_GasImportTableAdapter();
        private readonly ImportProduct _parent;
        private readonly GSS_ShellTableAdapter _shellAdapter = new GSS_ShellTableAdapter();
        private readonly GSS_ShellImportTableAdapter _shellImportAdapter = new GSS_ShellImportTableAdapter();
        private readonly GSS_ValveTableAdapter _valveAdapter = new GSS_ValveTableAdapter();
        private readonly GSS_ValveImportTableAdapter _valveImportAdapter = new GSS_ValveImportTableAdapter();

        /// <summary>
        /// Initializes a new instance of the "ImportProduct_Add" form.
        /// </summary>
        /// <param name="parent">Import product form.</param>
        public ImportProduct_Add(ImportProduct parent)
        {
            InitializeComponent();
            GetProductsDataTable(cbb_ImportProduct, null);
            _parent = parent;
        }


        /// <summary>
        /// Handles the Click event of the button Save.
        /// </summary>
        private void btn_save_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(txt_quantity.Text.Trim()) == 0)
            {
                MessageBox.Show(Resources.Msb_Import_Zero_Error, Resources.Msb_Title_Import_Product_Error,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            String productDetail = cbb_ImportProduct.SelectedValue.ToString();
            String[] strList = productDetail.Split(new[] {'|'});
            int productId = Int32.Parse(strList[1]);

            int quantity = Int32.Parse(txt_quantity.Text);

            if (strList[0].Equals(IDENTIFY_VALUE_GAS))
            {
                _gasImportAdapter.Insert(quantity, DateTime.Now, productId);

                _gasAdapter.UpdateIncreaseQuantity(quantity, productId);
            }
            else if (strList[0].Equals(IDENTIFY_VALUE_VALVE))
            {
                _valveImportAdapter.InsertQuery(quantity, DateTime.Now, productId);
                _valveAdapter.UpdateIncreaseQuantity(quantity, productId);
            }
            else if (strList[0].Equals(IDENTIFY_VALUE_SHELL))
            {
                _shellImportAdapter.InsertQuery(quantity, DateTime.Now, productId);
                _shellAdapter.UpdateIncreaseQuantity(quantity, productId);
            }

            _parent.LoadImport();
        }

        /// <summary>
        /// Gets the products data table.
        /// </summary>
        /// <param name="combobox">The combobox.</param>
        /// <param name="SelectedValue">The selected value of the combobox.</param>
        public void GetProductsDataTable(ComboBox combobox, object SelectedValue)
        {
            var dataTable = new DataTable();
            dataTable.Columns.Add(Definitions.FIELD_TEXT);
            dataTable.Columns.Add(Definitions.FIELD_VALUE);
            combobox.DataSource = dataTable;
            combobox.DisplayMember = Definitions.FIELD_TEXT;
            combobox.ValueMember = Definitions.FIELD_VALUE;

            DataAccessLayer.GSS.GSS_GasDataTable gases = _gasAdapter.GetGass();
            DataAccessLayer.GSS.GSS_ValveDataTable valves = _valveAdapter.GetValves();
            DataAccessLayer.GSS.GSS_ShellDataTable shelles = _shellAdapter.GetShells();

            foreach (var gas in gases)
            {
                dataTable.Rows.Add(new object[] {gas.gas_Name, IDENTIFY_VALUE_GAS + "|" + gas.gas_Id});
            }
            foreach (var valve in valves)
            {
                dataTable.Rows.Add(new object[] {valve.valve_Name, IDENTIFY_VALUE_VALVE + "|" + valve.valve_Id});
            }
            foreach (var shell in shelles)
            {
                dataTable.Rows.Add(new object[] {shell.shell_Name, IDENTIFY_VALUE_SHELL + "|" + shell.shell_Id});
            }

            if (SelectedValue != null && SelectedValue != DBNull.Value)
                combobox.SelectedValue = SelectedValue;
            else if (dataTable.Rows.Count > 0)
                combobox.SelectedValue = dataTable.Rows[0][1];
        }

        /// <summary>
        /// Handles the TextChanged event of the textbox Quantity.
        /// </summary>
        private void quantity_TextChanged(object sender, EventArgs e)
        {
            for (var count = 0; count < txt_quantity.Text.Length; count++)
            {
                if ((txt_quantity.Text[count]) != '0'
                    && (txt_quantity.Text[count]) != '1'
                    && (txt_quantity.Text[count]) != '2'
                    && (txt_quantity.Text[count]) != '3'
                    && (txt_quantity.Text[count]) != '4'
                    && (txt_quantity.Text[count]) != '5'
                    && (txt_quantity.Text[count]) != '6'
                    && (txt_quantity.Text[count]) != '7'
                    && (txt_quantity.Text[count]) != '8'
                    && (txt_quantity.Text[count]) != '9'
                    )
                {
                    txt_quantity.Text = txt_quantity.Text.Remove(count, 1);
                    count--;
                }
            }
        }
    }
}