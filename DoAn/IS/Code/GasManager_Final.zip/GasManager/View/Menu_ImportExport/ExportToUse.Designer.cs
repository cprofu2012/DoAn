﻿namespace GSS.View.Menu_ImportExport
{
    partial class ExportToUse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExportToUse));
            this.dtg_export = new System.Windows.Forms.DataGridView();
            this.EXPORT_TO_USE_DATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EXPORT_TO_USE_PRODUCT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EXPORT_TO_USE_QUANTITY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_add = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_export)).BeginInit();
            this.SuspendLayout();
            // 
            // dtg_export
            // 
            this.dtg_export.AllowUserToAddRows = false;
            this.dtg_export.AllowUserToDeleteRows = false;
            this.dtg_export.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_export.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_export.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_export.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EXPORT_TO_USE_DATE,
            this.EXPORT_TO_USE_PRODUCT,
            this.EXPORT_TO_USE_QUANTITY});
            this.dtg_export.Location = new System.Drawing.Point(12, 12);
            this.dtg_export.Name = "dtg_export";
            this.dtg_export.ReadOnly = true;
            this.dtg_export.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_export.Size = new System.Drawing.Size(483, 387);
            this.dtg_export.TabIndex = 0;
            // 
            // EXPORT_TO_USE_DATE
            // 
            this.EXPORT_TO_USE_DATE.HeaderText = "Ngày";
            this.EXPORT_TO_USE_DATE.Name = "EXPORT_TO_USE_DATE";
            this.EXPORT_TO_USE_DATE.ReadOnly = true;
            // 
            // EXPORT_TO_USE_PRODUCT
            // 
            this.EXPORT_TO_USE_PRODUCT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.EXPORT_TO_USE_PRODUCT.HeaderText = "Mặt hàng";
            this.EXPORT_TO_USE_PRODUCT.Name = "EXPORT_TO_USE_PRODUCT";
            this.EXPORT_TO_USE_PRODUCT.ReadOnly = true;
            this.EXPORT_TO_USE_PRODUCT.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.EXPORT_TO_USE_PRODUCT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // EXPORT_TO_USE_QUANTITY
            // 
            this.EXPORT_TO_USE_QUANTITY.HeaderText = "Số lượng";
            this.EXPORT_TO_USE_QUANTITY.Name = "EXPORT_TO_USE_QUANTITY";
            this.EXPORT_TO_USE_QUANTITY.ReadOnly = true;
            this.EXPORT_TO_USE_QUANTITY.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.EXPORT_TO_USE_QUANTITY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // btn_add
            // 
            this.btn_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_add.Image = ((System.Drawing.Image)(resources.GetObject("btn_add.Image")));
            this.btn_add.Location = new System.Drawing.Point(455, 405);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(40, 40);
            this.btn_add.TabIndex = 2;
            this.toolTip1.SetToolTip(this.btn_add, "Thêm");
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // ExportToUse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 448);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.dtg_export);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ExportToUse";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Xuất hàng để sử dụng";
            ((System.ComponentModel.ISupportInitialize)(this.dtg_export)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtg_export;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.DataGridViewTextBoxColumn EXPORT_TO_USE_DATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn EXPORT_TO_USE_PRODUCT;
        private System.Windows.Forms.DataGridViewTextBoxColumn EXPORT_TO_USE_QUANTITY;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}