﻿using System;
using System.Collections;
using System.Windows.Forms;
using GSS.DataAccessLayer.GSSTableAdapters;

namespace GSS.View.Menu_ImportExport
{
    /// <summary>
    ///   Export product's form
    /// </summary>
    public partial class ExportToUse : Form
    {
        private const string IDENTIFY_VALUE_GAS = "1";
        private const string IDENTIFY_VALUE_SHELL = "3";
        private const string IDENTIFY_VALUE_VALVE = "2";
        private readonly GSS_OrderTableAdapter _orderAdapter = new GSS_OrderTableAdapter();

        /// <summary>
        ///   Initializes a new instance of the "ExportToUse" form.
        /// </summary>
        public ExportToUse()
        {
            InitializeComponent();
            GetOrders();
        }

        /// <summary>
        ///   Gets the orders.
        /// </summary>
        public void GetOrders()
        {
            var product = new Hashtable();

            var gasAdapter = new GSS_GasTableAdapter();
            var valveAdapter = new GSS_ValveTableAdapter();
            var shellAdapter = new GSS_ShellTableAdapter();

            var gasses = gasAdapter.GetGass();
            var valves = valveAdapter.GetValves();
            var shelles = shellAdapter.GetShells();

            foreach (var gas in gasses)
            {
                product.Add(IDENTIFY_VALUE_GAS + "|" + gas.gas_Id, gas.gas_Name);
            }
            foreach (var valve in valves)
            {
                product.Add(IDENTIFY_VALUE_VALVE + "|" + valve.valve_Id, valve.valve_Name);
            }
            foreach (var shell in shelles)
            {
                product.Add(IDENTIFY_VALUE_SHELL + "|" + shell.shell_Id, shell.shell_Name);
            }

            dtg_export.Rows.Clear();
            var orderdt = _orderAdapter.GetExportToUseOrder();

            foreach (var order in orderdt)
            {
                if (!order.IsNull("ode_ValveId"))
                {
                    dtg_export.Rows.Add(new[]
                                            {
                                                order.ode_Date, product[IDENTIFY_VALUE_VALVE + "|" + order.ode_ValveId],
                                                order.ode_Quantity
                                            });
                }
                else if (!order.IsNull("ode_ShellId"))
                {
                    dtg_export.Rows.Add(new[]
                                            {
                                                order.ode_Date, product[IDENTIFY_VALUE_SHELL + "|" + order.ode_ShellId],
                                                order.ode_Quantity
                                            });
                }
                else if (!order.IsNull("ode_GasId"))
                {
                    dtg_export.Rows.Add(new[]
                                            {
                                                order.ode_Date, product[IDENTIFY_VALUE_GAS + "|" + order.ode_GasId],
                                                order.ode_Quantity
                                            });
                }
            }
        }

        /// <summary>
        ///   Handles the Click event of the button Add.
        /// </summary>
        private void btn_add_Click(object sender, EventArgs e)
        {
            var exportToUseAdd = new ExportToUse_Add(this);
            exportToUseAdd.ShowDialog();
        }
    }
}