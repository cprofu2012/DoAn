﻿namespace GSS.View.Menu_Account
{
    partial class Form_ManagerAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_ManagerAccount));
            this.tct_accountmanager = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_edit = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.dtg_Manager = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btn_edit_normal = new System.Windows.Forms.Button();
            this.btn_add_normal = new System.Windows.Forms.Button();
            this.dtg_NomalUser = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbx_selectAll = new System.Windows.Forms.CheckBox();
            this.cbx_borrowmoneylist = new System.Windows.Forms.CheckBox();
            this.cbx_shellborrow = new System.Windows.Forms.CheckBox();
            this.cbx_deliversell = new System.Windows.Forms.CheckBox();
            this.cbx_goodsold = new System.Windows.Forms.CheckBox();
            this.cbx_checkproduct = new System.Windows.Forms.CheckBox();
            this.cbx_exporttouse = new System.Windows.Forms.CheckBox();
            this.cbx_importproduct = new System.Windows.Forms.CheckBox();
            this.cbx_restore = new System.Windows.Forms.CheckBox();
            this.cbx_backup = new System.Windows.Forms.CheckBox();
            this.cbx_billsetup = new System.Windows.Forms.CheckBox();
            this.cbx_suppliertist = new System.Windows.Forms.CheckBox();
            this.cbx_employeetist = new System.Windows.Forms.CheckBox();
            this.cbx_productist = new System.Windows.Forms.CheckBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tct_accountmanager.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Manager)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_NomalUser)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tct_accountmanager
            // 
            this.tct_accountmanager.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tct_accountmanager.Controls.Add(this.tabPage1);
            this.tct_accountmanager.Controls.Add(this.tabPage2);
            this.tct_accountmanager.Location = new System.Drawing.Point(12, 12);
            this.tct_accountmanager.Name = "tct_accountmanager";
            this.tct_accountmanager.SelectedIndex = 0;
            this.tct_accountmanager.Size = new System.Drawing.Size(873, 518);
            this.tct_accountmanager.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btn_edit);
            this.tabPage1.Controls.Add(this.btn_add);
            this.tabPage1.Controls.Add(this.dtg_Manager);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(865, 492);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Quản lý";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btn_edit
            // 
            this.btn_edit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_edit.Enabled = false;
            this.btn_edit.Image = ((System.Drawing.Image)(resources.GetObject("btn_edit.Image")));
            this.btn_edit.Location = new System.Drawing.Point(773, 446);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(40, 40);
            this.btn_edit.TabIndex = 0;
            this.btn_edit.UseVisualStyleBackColor = true;
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // btn_add
            // 
            this.btn_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_add.Image = ((System.Drawing.Image)(resources.GetObject("btn_add.Image")));
            this.btn_add.Location = new System.Drawing.Point(819, 446);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(40, 40);
            this.btn_add.TabIndex = 1;
            this.toolTip1.SetToolTip(this.btn_add, "Thêm quản lý");
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // dtg_Manager
            // 
            this.dtg_Manager.AllowUserToAddRows = false;
            this.dtg_Manager.AllowUserToDeleteRows = false;
            this.dtg_Manager.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_Manager.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_Manager.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_Manager.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column5,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dtg_Manager.Location = new System.Drawing.Point(6, 6);
            this.dtg_Manager.Name = "dtg_Manager";
            this.dtg_Manager.ReadOnly = true;
            this.dtg_Manager.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_Manager.Size = new System.Drawing.Size(853, 435);
            this.dtg_Manager.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Mã";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 60;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Tài khoản";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 130;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "Tên";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Số điện thoại";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 200;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "CMT/ Mã cá nhân";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 150;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btn_edit_normal);
            this.tabPage2.Controls.Add(this.btn_add_normal);
            this.tabPage2.Controls.Add(this.dtg_NomalUser);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(865, 492);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Người dùng";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btn_edit_normal
            // 
            this.btn_edit_normal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_edit_normal.Enabled = false;
            this.btn_edit_normal.Image = ((System.Drawing.Image)(resources.GetObject("btn_edit_normal.Image")));
            this.btn_edit_normal.Location = new System.Drawing.Point(773, 446);
            this.btn_edit_normal.Name = "btn_edit_normal";
            this.btn_edit_normal.Size = new System.Drawing.Size(40, 40);
            this.btn_edit_normal.TabIndex = 4;
            this.toolTip1.SetToolTip(this.btn_edit_normal, "Sửa nhân viên");
            this.btn_edit_normal.UseVisualStyleBackColor = true;
            this.btn_edit_normal.Click += new System.EventHandler(this.btn_edit_normal_Click);
            // 
            // btn_add_normal
            // 
            this.btn_add_normal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_add_normal.Image = ((System.Drawing.Image)(resources.GetObject("btn_add_normal.Image")));
            this.btn_add_normal.Location = new System.Drawing.Point(819, 446);
            this.btn_add_normal.Name = "btn_add_normal";
            this.btn_add_normal.Size = new System.Drawing.Size(40, 40);
            this.btn_add_normal.TabIndex = 3;
            this.toolTip1.SetToolTip(this.btn_add_normal, "Thêm nhân viên");
            this.btn_add_normal.UseVisualStyleBackColor = true;
            this.btn_add_normal.Click += new System.EventHandler(this.btn_add_normal_Click);
            // 
            // dtg_NomalUser
            // 
            this.dtg_NomalUser.AllowUserToAddRows = false;
            this.dtg_NomalUser.AllowUserToDeleteRows = false;
            this.dtg_NomalUser.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_NomalUser.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_NomalUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_NomalUser.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.Column6});
            this.dtg_NomalUser.Location = new System.Drawing.Point(6, 103);
            this.dtg_NomalUser.Name = "dtg_NomalUser";
            this.dtg_NomalUser.ReadOnly = true;
            this.dtg_NomalUser.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_NomalUser.Size = new System.Drawing.Size(853, 335);
            this.dtg_NomalUser.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Mã";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 60;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Tài khoản";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 130;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.HeaderText = "Tên";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Số điện thoại";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 200;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "CMT/ Mã cá nhân";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 150;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Trạng thái";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.cbx_selectAll);
            this.groupBox2.Controls.Add(this.cbx_borrowmoneylist);
            this.groupBox2.Controls.Add(this.cbx_shellborrow);
            this.groupBox2.Controls.Add(this.cbx_deliversell);
            this.groupBox2.Controls.Add(this.cbx_goodsold);
            this.groupBox2.Controls.Add(this.cbx_checkproduct);
            this.groupBox2.Controls.Add(this.cbx_exporttouse);
            this.groupBox2.Controls.Add(this.cbx_importproduct);
            this.groupBox2.Controls.Add(this.cbx_restore);
            this.groupBox2.Controls.Add(this.cbx_backup);
            this.groupBox2.Controls.Add(this.cbx_billsetup);
            this.groupBox2.Controls.Add(this.cbx_suppliertist);
            this.groupBox2.Controls.Add(this.cbx_employeetist);
            this.groupBox2.Controls.Add(this.cbx_productist);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(853, 91);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Quyền hạn truy cập";
            // 
            // cbx_selectAll
            // 
            this.cbx_selectAll.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_selectAll.AutoSize = true;
            this.cbx_selectAll.Location = new System.Drawing.Point(678, 67);
            this.cbx_selectAll.Name = "cbx_selectAll";
            this.cbx_selectAll.Size = new System.Drawing.Size(81, 17);
            this.cbx_selectAll.TabIndex = 29;
            this.cbx_selectAll.Text = "Chọn tất cả";
            this.cbx_selectAll.UseVisualStyleBackColor = true;
            this.cbx_selectAll.CheckedChanged += new System.EventHandler(this.SelectAll);
            // 
            // cbx_borrowmoneylist
            // 
            this.cbx_borrowmoneylist.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_borrowmoneylist.AutoSize = true;
            this.cbx_borrowmoneylist.Location = new System.Drawing.Point(347, 21);
            this.cbx_borrowmoneylist.Name = "cbx_borrowmoneylist";
            this.cbx_borrowmoneylist.Size = new System.Drawing.Size(146, 17);
            this.cbx_borrowmoneylist.TabIndex = 27;
            this.cbx_borrowmoneylist.Text = "Danh sách khách nợ tiền";
            this.cbx_borrowmoneylist.UseVisualStyleBackColor = true;
            // 
            // cbx_shellborrow
            // 
            this.cbx_shellborrow.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_shellborrow.AutoSize = true;
            this.cbx_shellborrow.Location = new System.Drawing.Point(678, 21);
            this.cbx_shellborrow.Name = "cbx_shellborrow";
            this.cbx_shellborrow.Size = new System.Drawing.Size(141, 17);
            this.cbx_shellborrow.TabIndex = 26;
            this.cbx_shellborrow.Text = "Danh sách khách nợ vỏ";
            this.cbx_shellborrow.UseVisualStyleBackColor = true;
            // 
            // cbx_deliversell
            // 
            this.cbx_deliversell.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_deliversell.AutoSize = true;
            this.cbx_deliversell.Location = new System.Drawing.Point(347, 44);
            this.cbx_deliversell.Name = "cbx_deliversell";
            this.cbx_deliversell.Size = new System.Drawing.Size(170, 17);
            this.cbx_deliversell.TabIndex = 23;
            this.cbx_deliversell.Text = "Thông kê bán hàng nhân viên";
            this.cbx_deliversell.UseVisualStyleBackColor = true;
            // 
            // cbx_goodsold
            // 
            this.cbx_goodsold.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_goodsold.AutoSize = true;
            this.cbx_goodsold.Location = new System.Drawing.Point(201, 67);
            this.cbx_goodsold.Name = "cbx_goodsold";
            this.cbx_goodsold.Size = new System.Drawing.Size(124, 17);
            this.cbx_goodsold.TabIndex = 20;
            this.cbx_goodsold.Text = "Doanh thu bán hàng";
            this.cbx_goodsold.UseVisualStyleBackColor = true;
            // 
            // cbx_checkproduct
            // 
            this.cbx_checkproduct.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_checkproduct.AutoSize = true;
            this.cbx_checkproduct.Location = new System.Drawing.Point(531, 67);
            this.cbx_checkproduct.Name = "cbx_checkproduct";
            this.cbx_checkproduct.Size = new System.Drawing.Size(76, 17);
            this.cbx_checkproduct.TabIndex = 19;
            this.cbx_checkproduct.Text = "Kiểm hàng";
            this.cbx_checkproduct.UseVisualStyleBackColor = true;
            // 
            // cbx_exporttouse
            // 
            this.cbx_exporttouse.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_exporttouse.AutoSize = true;
            this.cbx_exporttouse.Location = new System.Drawing.Point(531, 44);
            this.cbx_exporttouse.Name = "cbx_exporttouse";
            this.cbx_exporttouse.Size = new System.Drawing.Size(138, 17);
            this.cbx_exporttouse.TabIndex = 18;
            this.cbx_exporttouse.Text = "Xuất hàng để tiêu dùng";
            this.cbx_exporttouse.UseVisualStyleBackColor = true;
            // 
            // cbx_importproduct
            // 
            this.cbx_importproduct.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_importproduct.AutoSize = true;
            this.cbx_importproduct.Location = new System.Drawing.Point(531, 21);
            this.cbx_importproduct.Name = "cbx_importproduct";
            this.cbx_importproduct.Size = new System.Drawing.Size(128, 17);
            this.cbx_importproduct.TabIndex = 17;
            this.cbx_importproduct.Text = "Nhập từ nhà sản xuất";
            this.cbx_importproduct.UseVisualStyleBackColor = true;
            // 
            // cbx_restore
            // 
            this.cbx_restore.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_restore.AutoSize = true;
            this.cbx_restore.Location = new System.Drawing.Point(201, 44);
            this.cbx_restore.Name = "cbx_restore";
            this.cbx_restore.Size = new System.Drawing.Size(121, 17);
            this.cbx_restore.TabIndex = 6;
            this.cbx_restore.Text = "Phục hồi từ bản sao";
            this.cbx_restore.UseVisualStyleBackColor = true;
            // 
            // cbx_backup
            // 
            this.cbx_backup.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_backup.AutoSize = true;
            this.cbx_backup.Location = new System.Drawing.Point(201, 21);
            this.cbx_backup.Name = "cbx_backup";
            this.cbx_backup.Size = new System.Drawing.Size(120, 17);
            this.cbx_backup.TabIndex = 5;
            this.cbx_backup.Text = "Tạo bản sao dữ liệu";
            this.cbx_backup.UseVisualStyleBackColor = true;
            // 
            // cbx_billsetup
            // 
            this.cbx_billsetup.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_billsetup.AutoSize = true;
            this.cbx_billsetup.Location = new System.Drawing.Point(347, 67);
            this.cbx_billsetup.Name = "cbx_billsetup";
            this.cbx_billsetup.Size = new System.Drawing.Size(126, 17);
            this.cbx_billsetup.TabIndex = 4;
            this.cbx_billsetup.Text = "Cài đặt mẫu hóa đơn";
            this.cbx_billsetup.UseVisualStyleBackColor = true;
            // 
            // cbx_suppliertist
            // 
            this.cbx_suppliertist.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_suppliertist.AutoSize = true;
            this.cbx_suppliertist.Location = new System.Drawing.Point(16, 67);
            this.cbx_suppliertist.Name = "cbx_suppliertist";
            this.cbx_suppliertist.Size = new System.Drawing.Size(147, 17);
            this.cbx_suppliertist.TabIndex = 2;
            this.cbx_suppliertist.Text = "Danh sách nhà cung cấp";
            this.cbx_suppliertist.UseVisualStyleBackColor = true;
            // 
            // cbx_employeetist
            // 
            this.cbx_employeetist.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_employeetist.AutoSize = true;
            this.cbx_employeetist.Location = new System.Drawing.Point(16, 44);
            this.cbx_employeetist.Name = "cbx_employeetist";
            this.cbx_employeetist.Size = new System.Drawing.Size(178, 17);
            this.cbx_employeetist.TabIndex = 1;
            this.cbx_employeetist.Text = "Danh sách nhân viên giao hàng";
            this.cbx_employeetist.UseVisualStyleBackColor = true;
            // 
            // cbx_productist
            // 
            this.cbx_productist.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbx_productist.AutoSize = true;
            this.cbx_productist.Location = new System.Drawing.Point(16, 21);
            this.cbx_productist.Name = "cbx_productist";
            this.cbx_productist.Size = new System.Drawing.Size(126, 17);
            this.cbx_productist.TabIndex = 0;
            this.cbx_productist.Text = "Danh sách hàng hóa";
            this.cbx_productist.UseVisualStyleBackColor = true;
            // 
            // Form_ManagerAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 542);
            this.Controls.Add(this.tct_accountmanager);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(843, 580);
            this.Name = "Form_ManagerAccount";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý tài khoản";
            this.tct_accountmanager.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Manager)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_NomalUser)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tct_accountmanager;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox cbx_employeetist;
        private System.Windows.Forms.CheckBox cbx_productist;
        private System.Windows.Forms.CheckBox cbx_borrowmoneylist;
        private System.Windows.Forms.CheckBox cbx_shellborrow;
        private System.Windows.Forms.CheckBox cbx_deliversell;
        private System.Windows.Forms.CheckBox cbx_goodsold;
        private System.Windows.Forms.CheckBox cbx_checkproduct;
        private System.Windows.Forms.CheckBox cbx_exporttouse;
        private System.Windows.Forms.CheckBox cbx_importproduct;
        private System.Windows.Forms.CheckBox cbx_restore;
        private System.Windows.Forms.CheckBox cbx_backup;
        private System.Windows.Forms.CheckBox cbx_billsetup;
        private System.Windows.Forms.CheckBox cbx_suppliertist;
        private System.Windows.Forms.DataGridView dtg_Manager;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridView dtg_NomalUser;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Button btn_edit;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_edit_normal;
        private System.Windows.Forms.Button btn_add_normal;
        private System.Windows.Forms.CheckBox cbx_selectAll;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}