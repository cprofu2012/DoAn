﻿using System;
using System.Data;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_Account
{
    /// <summary>
    /// Form Register to add new user or admin
    /// </summary>
    public partial class Register : Form
    {
        private readonly Form_ManagerAccount _formManagerAccount;
        private readonly DataAccessLayer.GSS.GSS_UserRow _currentUser;
        private readonly GSS_RoleTableAdapter _roleAdapter = new GSS_RoleTableAdapter();
        private readonly GSS_UserTableAdapter _userAdapter = new GSS_UserTableAdapter();

        /// <summary>
        /// Initializes a new instance of the "Register" form.
        /// </summary>
        /// <param name="formManagerAccount">The form manage accounts.</param>
        public Register(Form_ManagerAccount formManagerAccount)
        {
            InitializeComponent();

            _formManagerAccount = formManagerAccount;
            LoadRoles();
            cbb_Roles.SelectedIndex = 0;
            LoadActive();
            cbb_active.SelectedValue = 1;
            cbb_active.Enabled = false;

            cbb_Roles.SelectedValueChanged += cbb_Roles_SelectedValueChanged;
        }

        /// <summary>
        /// Initializes a new instance of the "Register" form.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <param name="formManagerAccount">The form manage accounts.</param>
        public Register(DataAccessLayer.GSS.GSS_UserRow user, Form_ManagerAccount formManagerAccount)
        {
            InitializeComponent();
            _formManagerAccount = formManagerAccount;
            LoadRoles();
            LoadActive();

            cbb_Roles.SelectedValue = user.user_roleId;
            cbb_active.SelectedValue = user.user_active;

            if (user.user_roleId == 1)
            {
                cbb_active.SelectedValue = 1;
                cbb_active.Enabled = false;
            }
            else
            {
                cbb_active.Enabled = true;
            }

            _currentUser = user;
            txt_name.Text = user.user_name;
            txt_password.Text = String.Empty;
            txt_phone.Text = user.user_telephone;
            txt_UID.Text = user.user_UID;
            txt_username.Text = user.user_username;


            cbb_Roles.SelectedValueChanged += cbb_Roles_SelectedValueChanged;
        }

        /// <summary>
        /// Handles the SelectedValueChanged event of the combobox Roles.
        /// </summary>
        private void cbb_Roles_SelectedValueChanged(object sender, EventArgs e)
        {
            if (Int32.Parse(cbb_Roles.SelectedValue.ToString()) == 1)
            {
                cbb_active.SelectedValue = 1;
                cbb_active.Enabled = false;
            }
            else
            {
                cbb_active.Enabled = true;
            }
        }

        /// <summary>
        /// Loads the roles.
        /// </summary>
        public void LoadRoles()
        {
            DataAccessLayer.GSS.GSS_RoleDataTable roles = _roleAdapter.GetRoles();

            var delivererTable = new DataTable();
            delivererTable.Columns.Add(Definitions.FIELD_TEXT);
            delivererTable.Columns.Add(Definitions.FIELD_VALUE);
            cbb_Roles.DataSource = delivererTable;
            cbb_Roles.DisplayMember = Definitions.FIELD_TEXT;
            cbb_Roles.ValueMember = Definitions.FIELD_VALUE;
            delivererTable.Clear();


            foreach (DataAccessLayer.GSS.GSS_RoleRow role in roles)
            {
                DataRow DataRow = delivererTable.NewRow();
                DataRow[0] = role.role_name;
                DataRow[1] = role.role_Id;
                delivererTable.Rows.Add(DataRow);
            }
        }

        /// <summary>
        /// Loads the active column.
        /// </summary>
        public void LoadActive()
        {
            var delivererTable = new DataTable();
            delivererTable.Columns.Add(Definitions.FIELD_TEXT);
            delivererTable.Columns.Add(Definitions.FIELD_VALUE);
            cbb_active.DataSource = delivererTable;
            cbb_active.DisplayMember = Definitions.FIELD_TEXT;
            cbb_active.ValueMember = Definitions.FIELD_VALUE;
            delivererTable.Clear();


            var dataRow = delivererTable.NewRow();
            dataRow[0] = Resources.Active;
            dataRow[1] = 1;
            delivererTable.Rows.Add(dataRow);

            dataRow = delivererTable.NewRow();
            dataRow[0] = Resources.Deactive;
            dataRow[1] = 0;
            delivererTable.Rows.Add(dataRow);
        }

        /// <summary>
        /// Handles the TextChanged event of the textbox phone.
        /// </summary>
        private void txt_phone_TextChanged(object sender, EventArgs e)
        {
            txt_phone.Text = txt_phone.Text.Trim();
            if (txt_phone.Text.Trim().Length == 0)
                return;

            for (int count = 0; count < txt_phone.Text.Length; count++)
            {
                if ((txt_phone.Text[count]) != '0'
                    && (txt_phone.Text[count]) != '1'
                    && (txt_phone.Text[count]) != '2'
                    && (txt_phone.Text[count]) != '3'
                    && (txt_phone.Text[count]) != '4'
                    && (txt_phone.Text[count]) != '5'
                    && (txt_phone.Text[count]) != '6'
                    && (txt_phone.Text[count]) != '7'
                    && (txt_phone.Text[count]) != '8'
                    && (txt_phone.Text[count]) != '9'
                    )
                {
                    txt_phone.Text = txt_phone.Text.Remove(count, 1);
                    count--;
                }
            }
        }

        /// <summary>
        /// Handles the Click event of the button Save.
        /// </summary>
        private void btn_save_Click(object sender, EventArgs e)
        {
            if (txt_name.Text.Trim().Length == 0
                || txt_phone.Text.Trim().Length == 0
                || txt_UID.Text.Trim().Length == 0
                || txt_username.Text.Trim().Length == 0
                || txt_password.Text.Trim().Length == 0
                )
            {
                MessageBox.Show(Resources.Msb_Information_require, Resources.Msb_Title_Error, MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }


            if (txt_UID.Text.Length < 9)
            {
                MessageBox.Show(Resources.Msb_ID_Digit, Resources.Msb_Title_Error, MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            else if (txt_phone.Text.Length < 10)
            {
                MessageBox.Show(Resources.Msb_PhoneNo_Digit, Resources.Msb_Title_Error, MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }


            if (_currentUser == null)
            {
                DataAccessLayer.GSS.GSS_UserDataTable users = _userAdapter.GetDataByUsername(txt_username.Text.Trim());
                if (users.Count == 0)
                {
                    _userAdapter.InsertUser(GetMD5(txt_password.Text), txt_name.Text,
                        Int32.Parse(cbb_Roles.SelectedValue.ToString()), txt_phone.Text,
                        Int32.Parse(cbb_active.SelectedValue.ToString()), txt_UID.Text, txt_username.Text);
                    MessageBox.Show(Resources.Msb_Register_Success, Resources.Msb_Title_Inform, MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    _formManagerAccount.LoadManager();
                    _formManagerAccount.LoadUser();
                }
                else
                {
                    MessageBox.Show(Resources.Msb_Register_Exist, Resources.Msb_Title_Error, MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
            else
            {
                DataAccessLayer.GSS.GSS_UserDataTable users = _userAdapter.GetDataByUsername(txt_username.Text.Trim());
                if (users.Count == 0)
                {
                    _userAdapter.UpdateUser(txt_username.Text, GetMD5(txt_password.Text), txt_name.Text,
                        Int32.Parse(cbb_Roles.SelectedValue.ToString()), txt_phone.Text,
                        Int32.Parse(cbb_active.SelectedValue.ToString()), txt_UID.Text, _currentUser.user_Id);
                    MessageBox.Show(Resources.Msb_Edit_Success, Resources.Msb_Title_Inform, MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    _formManagerAccount.LoadManager();
                    _formManagerAccount.LoadUser();
                }
                if (users.Count == 1 && _currentUser.user_Id == users[0].user_Id)
                {
                    _userAdapter.UpdateUser(txt_username.Text, GetMD5(txt_password.Text), txt_name.Text,
                        Int32.Parse(cbb_Roles.SelectedValue.ToString()), txt_phone.Text,
                        Int32.Parse(cbb_active.SelectedValue.ToString()), txt_UID.Text, _currentUser.user_Id);
                    MessageBox.Show(Resources.Msb_Edit_Success);
                    _formManagerAccount.LoadManager();
                    _formManagerAccount.LoadUser();
                }
                else
                {
                    MessageBox.Show(Resources.Msb_Register_Exist);
                }
            }
        }

        /// <summary>
        /// Gets the MD5 code of string 'text'.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns>MD5 code</returns>
        private static string GetMD5(string text)
        {
            var UE = new UnicodeEncoding();
            byte[] message = UE.GetBytes(text);
            MD5 hashString = new MD5CryptoServiceProvider();
            string hex = String.Empty;
            byte[] hashValue = hashString.ComputeHash(message);
            foreach (byte x in hashValue)
            {
                hex += String.Format("{0:x2}", x);
            }
            return hex;
        }

        /// <summary>
        /// Handles the TextChanged event of the textbox UID.
        /// </summary>
        private void txt_UID_TextChanged(object sender, EventArgs e)
        {
            txt_UID.Text = txt_UID.Text.Trim();
            if (txt_UID.Text.Trim().Length == 0)
                return;

            for (int count = 0; count < txt_UID.Text.Length; count++)
            {
                if ((txt_UID.Text[count]) != '0'
                    && (txt_UID.Text[count]) != '1'
                    && (txt_UID.Text[count]) != '2'
                    && (txt_UID.Text[count]) != '3'
                    && (txt_UID.Text[count]) != '4'
                    && (txt_UID.Text[count]) != '5'
                    && (txt_UID.Text[count]) != '6'
                    && (txt_UID.Text[count]) != '7'
                    && (txt_UID.Text[count]) != '8'
                    && (txt_UID.Text[count]) != '9'
                    )
                {
                    txt_UID.Text = txt_UID.Text.Remove(count, 1);
                    count--;
                }
            }
        }
    }
}