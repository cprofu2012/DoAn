﻿using System;
using System.Windows.Forms;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_Account
{
    /// <summary>
    /// Account Management's form
    /// </summary>
    
    public partial class Form_ManagerAccount : Form
    {
        private readonly GSS_UserTableAdapter _userAdapter = new GSS_UserTableAdapter();


        /// <summary>
        /// Initializes a new instance of the "Form_ManagerAccount" form.
        /// </summary>
        
        public Form_ManagerAccount()
        {
            InitializeComponent();

            cbx_productist.Checked = Settings.Default.cbx_productist;
            cbx_employeetist.Checked = Settings.Default.cbx_employeetist;
            cbx_suppliertist.Checked = Settings.Default.cbx_suppliertist;
            cbx_billsetup.Checked = Settings.Default.cbx_billsetup;
            cbx_goodsold.Checked = Settings.Default.cbx_goodsold;
            cbx_backup.Checked = Settings.Default.cbx_backup;
            cbx_restore.Checked = Settings.Default.cbx_restore;


            cbx_shellborrow.Checked = Settings.Default.cbx_shellborrow;
            cbx_borrowmoneylist.Checked = Settings.Default.cbx_borrowmoneylist;
            cbx_importproduct.Checked = Settings.Default.cbx_importproduct;
            cbx_exporttouse.Checked = Settings.Default.cbx_exporttouse;
            cbx_checkproduct.Checked = Settings.Default.cbx_checkproduct;
            cbx_deliversell.Checked = Settings.Default.cbx_deliversell;

            cbx_productist.CheckedChanged += Save;
            cbx_employeetist.CheckedChanged += Save;
            cbx_suppliertist.CheckedChanged += Save;
            cbx_billsetup.CheckedChanged += Save;
            cbx_goodsold.CheckedChanged += Save;
            cbx_backup.CheckedChanged += Save;
            cbx_restore.CheckedChanged += Save;


            cbx_shellborrow.CheckedChanged += Save;

            cbx_borrowmoneylist.CheckedChanged += Save;

            cbx_importproduct.CheckedChanged += Save;
            cbx_exporttouse.CheckedChanged += Save;
            cbx_checkproduct.CheckedChanged += Save;
            cbx_deliversell.CheckedChanged += Save;

            dtg_Manager.SelectionChanged += dtg_Manager_SelectionChanged;
            dtg_NomalUser.SelectionChanged += dtg_NomalUser_SelectionChanged;
            LoadManager();
            LoadUser();
        }

        /// <summary>
        /// Loads managers.
        /// </summary>
        
        public void LoadManager()
        {
            dtg_Manager.Rows.Clear();
            DataAccessLayer.GSS.GSS_UserDataTable users = _userAdapter.GetManagers();
            foreach (DataAccessLayer.GSS.GSS_UserRow user in users)
            {
                dtg_Manager.Rows.Add(new object[]
                                         {
                                             user.user_Id, user.user_username, user.user_name, user.user_telephone,
                                             user.user_UID
                                         });
            }
        }

        /// <summary>
        /// Loads users.
        /// </summary>
        
        public void LoadUser()
        {
            dtg_NomalUser.Rows.Clear();
            DataAccessLayer.GSS.GSS_UserDataTable users = _userAdapter.GetNormalUser();
            foreach (DataAccessLayer.GSS.GSS_UserRow user in users)
            {
                dtg_NomalUser.Rows.Add(new object[]
                                           {
                                               user.user_Id, user.user_username, user.user_name, user.user_telephone,
                                               user.user_UID, user.user_active == 0 ? "Chưa kích hoạt" : "Đã kích hoạt"
                                           });
            }
        }

        /// <summary>
        /// Handles the SelectionChanged event of the DataGridView dtg_NomalUser.
        /// </summary>
        
        
        
        private void dtg_NomalUser_SelectionChanged(object sender, EventArgs e)
        {
            btn_edit_normal.Enabled = dtg_NomalUser.SelectedRows.Count == 1;
        }

        /// <summary>
        /// Handles the SelectionChanged event of the DataGridView dtg_Manager.
        /// </summary>
        
        
        
        private void dtg_Manager_SelectionChanged(object sender, EventArgs e)
        {
            btn_edit.Enabled = dtg_Manager.SelectedRows.Count == 1;
        }

        /// <summary>
        /// Saves the roles.
        /// </summary>
        
        
        private void Save(object sender, EventArgs e)
        {
            Settings.Default.cbx_productist = cbx_productist.Checked;
            Settings.Default.cbx_employeetist = cbx_employeetist.Checked;
            Settings.Default.cbx_suppliertist = cbx_suppliertist.Checked;
            Settings.Default.cbx_billsetup = cbx_billsetup.Checked;
            Settings.Default.cbx_goodsold = cbx_goodsold.Checked;
            Settings.Default.cbx_backup = cbx_backup.Checked;
            Settings.Default.cbx_restore = cbx_restore.Checked;
            Settings.Default.cbx_shellborrow = cbx_shellborrow.Checked;
            Settings.Default.cbx_borrowmoneylist = cbx_borrowmoneylist.Checked;
            Settings.Default.cbx_importproduct = cbx_importproduct.Checked;
            Settings.Default.cbx_exporttouse = cbx_exporttouse.Checked;
            Settings.Default.cbx_checkproduct = cbx_checkproduct.Checked;
            Settings.Default.cbx_deliversell = cbx_deliversell.Checked;
            cbx_selectAll.CheckedChanged -= SelectAll;
            cbx_selectAll.Checked = false;
            cbx_selectAll.CheckedChanged += SelectAll;
            Settings.Default.Save();
        }

        /// <summary>
        /// Handles the Click event of the button Add.
        /// </summary>
        
        
        
        private void btn_add_Click(object sender, EventArgs e)
        {
            var register = new Register(this) {Text = Resources.Title_Account_Add, cbb_Roles = {SelectedValue = 1}};
            register.ShowDialog();
        }

        /// <summary>
        /// Handles the Click event of the button btn_add_normal.
        /// </summary>
        
        
        
        private void btn_add_normal_Click(object sender, EventArgs e)
        {
            var register = new Register(this) {Text = Resources.Title_Account_Add, cbb_Roles = {SelectedValue = 2}};
            register.ShowDialog();
        }

        /// <summary>
        /// Handles the Click event of the button btn_edit_normal.
        /// </summary>
        
        
        
        private void btn_edit_normal_Click(object sender, EventArgs e)
        {
            var selectedId = Int32.Parse(dtg_NomalUser.SelectedRows[0].Cells[0].Value.ToString());
            DataAccessLayer.GSS.GSS_UserDataTable users = _userAdapter.GetDataById(selectedId);

            var register = new Register(users[0], this) {Text = Resources.Title_Account_Edit};

            register.ShowDialog();
        }

        /// <summary>
        /// Handles the Click event of the button btn_edit.
        /// </summary>
        
        
        
        private void btn_edit_Click(object sender, EventArgs e)
        {
            var selectedId = Int32.Parse(dtg_Manager.SelectedRows[0].Cells[0].Value.ToString());
            var users = _userAdapter.GetDataById(selectedId);

            var register = new Register(users[0], this) {Text = Resources.Title_Account_Edit};
            register.ShowDialog();
        }

        /// <summary>
        /// Set full roles for user accounts.
        /// </summary>
        
        
        private void SelectAll(object sender, EventArgs e)
        {
            cbx_productist.CheckedChanged -= Save;
            cbx_employeetist.CheckedChanged -= Save;
            cbx_suppliertist.CheckedChanged -= Save;
            cbx_billsetup.CheckedChanged -= Save;
            cbx_goodsold.CheckedChanged -= Save;
            cbx_backup.CheckedChanged -= Save;
            cbx_restore.CheckedChanged -= Save;
            cbx_shellborrow.CheckedChanged -= Save;
            cbx_borrowmoneylist.CheckedChanged -= Save;
            cbx_importproduct.CheckedChanged -= Save;
            cbx_exporttouse.CheckedChanged -= Save;
            cbx_checkproduct.CheckedChanged -= Save;
            cbx_deliversell.CheckedChanged -= Save;

            cbx_productist.Checked = cbx_selectAll.Checked;
            cbx_employeetist.Checked = cbx_selectAll.Checked;
            cbx_suppliertist.Checked = cbx_selectAll.Checked;
            cbx_billsetup.Checked = cbx_selectAll.Checked;
            cbx_goodsold.Checked = cbx_selectAll.Checked;
            cbx_backup.Checked = cbx_selectAll.Checked;
            cbx_restore.Checked = cbx_selectAll.Checked;
            cbx_shellborrow.Checked = cbx_selectAll.Checked;
            cbx_borrowmoneylist.Checked = cbx_selectAll.Checked;
            cbx_importproduct.Checked = cbx_selectAll.Checked;
            cbx_exporttouse.Checked = cbx_selectAll.Checked;
            cbx_checkproduct.Checked = cbx_selectAll.Checked;
            cbx_deliversell.Checked = cbx_selectAll.Checked;

            Settings.Default.cbx_productist = cbx_productist.Checked;
            Settings.Default.cbx_employeetist = cbx_employeetist.Checked;
            Settings.Default.cbx_suppliertist = cbx_suppliertist.Checked;
            Settings.Default.cbx_billsetup = cbx_billsetup.Checked;
            Settings.Default.cbx_goodsold = cbx_goodsold.Checked;
            Settings.Default.cbx_backup = cbx_backup.Checked;
            Settings.Default.cbx_restore = cbx_restore.Checked;
            Settings.Default.cbx_shellborrow = cbx_shellborrow.Checked;
            Settings.Default.cbx_borrowmoneylist = cbx_borrowmoneylist.Checked;
            Settings.Default.cbx_importproduct = cbx_importproduct.Checked;
            Settings.Default.cbx_exporttouse = cbx_exporttouse.Checked;
            Settings.Default.cbx_checkproduct = cbx_checkproduct.Checked;
            Settings.Default.cbx_deliversell = cbx_deliversell.Checked;
            Settings.Default.Save();

            cbx_productist.CheckedChanged += Save;
            cbx_employeetist.CheckedChanged += Save;
            cbx_suppliertist.CheckedChanged += Save;
            cbx_billsetup.CheckedChanged += Save;
            cbx_goodsold.CheckedChanged += Save;
            cbx_backup.CheckedChanged += Save;
            cbx_restore.CheckedChanged += Save;
            cbx_shellborrow.CheckedChanged += Save;
            cbx_borrowmoneylist.CheckedChanged += Save;
            cbx_importproduct.CheckedChanged += Save;
            cbx_exporttouse.CheckedChanged += Save;
            cbx_checkproduct.CheckedChanged += Save;
            cbx_deliversell.CheckedChanged += Save;
        }
    }
}