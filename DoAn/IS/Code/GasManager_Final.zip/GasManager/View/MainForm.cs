﻿using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using GSS.Control;
using GSS.Control.Excel_Object;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Objects;
using GSS.Properties;
using GSS.View;
using GSS.View.Menu_Account;
using GSS.View.Menu_Check;
using GSS.View.Menu_ImportExport;
using GSS.View.Menu_Report;
using GSS.View.Menu_System;
using GSS.View.Menu_Tool;
using Microsoft.Office.Interop.Word;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;
using Application = System.Windows.Forms.Application;
using Login = GSS.View.Login;
using Rectangle = System.Drawing.Rectangle;
using Settings = GSS.Properties.Settings;
using Table = Microsoft.Office.Interop.Word.Table;

namespace GasManager
{
    /// <summary>
    ///   Main form of the program
    /// </summary>
    public partial class MainForm : Form, IMainFormInterface
    {
        #region Definition

        #region Delegates

        /// <summary>
        ///   Delegate Add node to tree node panel
        /// </summary>
        /// <param name = "user">The user.</param>
        /// <param name = "tree">The tree.</param>
        /// <param name = "parentNode">The parent node.</param>
        /// <param name = "selected">if set to <c>true</c> [selected].</param>
        public delegate void AddNodeCallback(TreeNode_User user, TreeView tree, int parentNode, bool selected);

        /// <summary>
        ///   Delegate increase the number of miss call on the tree node panel
        /// </summary>
        /// <param name = "user">The user.</param>
        /// <param name = "tree">The tree.</param>
        /// <param name = "add">The add.</param>
        /// <param name = "isAns">if set to <c>true</c> [is ans].</param>
        /// <param name = "isFocus">if set to <c>true</c> [is focus].</param>
        public delegate void IncreaseNodeCallback(TreeNode_User user, TreeView tree, int add, bool isAns, bool isFocus);

        /// <summary>
        ///   Delegate update contact to form Call or send message
        /// </summary>
        /// <param name = "contacts">The contacts.</param>
        /// <remarks>
        /// </remarks>
        public delegate void SelectContactDelegate(string contacts);

        #endregion

        public static GSS.DataAccessLayer.GSS.GSS_UserRow _user;

        public static int NODE_ALL;

        public static int NODE_EDIT = 1;

        public static int NODE_CALL = 2;

        public static int NODE_ORDER = 3;

        public static int CALL_STATUS_ANSWER = 1;

        public static int CALL_STATUS_MISSING = 2;

        public static int CALL_STATUS_CALL = 3;

        private readonly GSS_CustomerTableAdapter _customerAdapter = new GSS_CustomerTableAdapter();

        private readonly GSS_DelivererTableAdapter _deliverAdapter = new GSS_DelivererTableAdapter();

        private readonly DataTable _delivererTable = new DataTable();

        public readonly GSS_GasTableAdapter _gasAdapter = new GSS_GasTableAdapter();

        private readonly GasValueTableAdapter _gasvalueAdapter = new GasValueTableAdapter();

        public readonly GSS_OrderTableAdapter _orderAdapter = new GSS_OrderTableAdapter();

        private readonly Login _parentLogin;

        private readonly GSS_ShellTableAdapter _shellAdapter = new GSS_ShellTableAdapter();

        private readonly ShellValueTableAdapter _shellvalueAdapter = new ShellValueTableAdapter();

        public readonly Hashtable _userHashTable = new Hashtable();

        public readonly GSS_ValueTableAdapter _valueAdapter = new GSS_ValueTableAdapter();
        private readonly GSS_ValveTableAdapter _valveAdapter = new GSS_ValveTableAdapter();
        private readonly ValveValueTableAdapter _valvevalueAdapter = new ValveValueTableAdapter();
        public DataTable CustomerTable = new DataTable();
        public DataTable GasTable = new DataTable();
        public Form_Call ObjFormCall;
        public Form_ReceiveCall ObjReceiveCall;
        public Form_SendMessage ObjSendMessage;
        public DataTable ShellTable = new DataTable();
        public SelectContactDelegate UpdateCallNo;
        public SelectContactDelegate UpdateMessagePhone;
        public DataTable ValveTable = new DataTable();
        private GSS_CallTableAdapter _callAdapter;
        private GSS.DataAccessLayer.GSS.GSS_CustomerDataTable _customers;
        private DateTime _da;
        public Modem_Control _modem;
        private GSS.DataAccessLayer.GSS.GSS_OrderDataTable _orders;
        private string _status;
        public string phone;

        #region Nested type: PanelCallBack

        /// <summary>
        ///   Delegate set visible of End Call panel when receive a call
        /// </summary>
        /// <param name = "isAnswer">if set to <c>true</c> [is answer].</param>
        private delegate void PanelCallBack(bool isAnswer);

        #endregion

        #region Nested type: Show_FormCallBack

        /// <summary>
        ///   Delegate show form relate to gsm function (call, send message, receive call)
        /// </summary>
        /// <param name = "form">The form.</param>
        private delegate void Show_FormCallBack(Popup_Form form);

        #endregion

        #region Nested type: UpdateStatusCallback

        /// <summary>
        ///   Delegate update status
        /// </summary>
        /// <param name = "text">The text.</param>
        private delegate void UpdateStatusCallback(string text);

        #endregion

        #endregion

        /// <summary>
        ///   Initializes a new instance of the "MainForm" form.
        /// </summary>
        /// <param name = "parentLogin">The login form.</param>
        /// <param name = "user">The user logined.</param>
        public MainForm(Login parentLogin, GSS.DataAccessLayer.GSS.GSS_UserRow user)
        {
            InitializeComponent();

            _user = user;
            _parentLogin = parentLogin;

            #region Component initial

            GasTable.Columns.Add(Definitions.FIELD_TEXT);
            GasTable.Columns.Add(Definitions.FIELD_VALUE);
            ValveTable.Columns.Add(Definitions.FIELD_TEXT);
            ValveTable.Columns.Add(Definitions.FIELD_VALUE);
            ShellTable.Columns.Add(Definitions.FIELD_TEXT);
            ShellTable.Columns.Add(Definitions.FIELD_VALUE);


            _delivererTable.Columns.Add(Definitions.FIELD_TEXT);
            _delivererTable.Columns.Add(Definitions.FIELD_VALUE);
            cbb_OrderDeliverer.DataSource = _delivererTable;
            cbb_OrderDeliverer.DisplayMember = Definitions.FIELD_TEXT;
            cbb_OrderDeliverer.ValueMember = Definitions.FIELD_VALUE;

            CustomerTable.Columns.Add(Definitions.FIELD_TEXT);
            CustomerTable.Columns.Add(Definitions.FIELD_VALUE);
            cbb_Customer.DataSource = CustomerTable;
            cbb_Customer.DisplayMember = Definitions.FIELD_TEXT;
            cbb_Customer.ValueMember = Definitions.FIELD_VALUE;

            ptb_order.Image = null;

            listPanel.Location = new Point(175, 105);
            editPanel.Location = new Point(175, 105);
            pnl_EditOrder.Location = new Point(175, 105);

            listPanel.Size = new Size(826, 420);
            editPanel.Size = new Size(826, 420);
            pnl_EditOrder.Size = new Size(826, 420);

            txt_NameCustomer.TextChanged += txt_NameCustomer_TextChanged;


            editTreeView.BeforeSelect += editTreeView_BeforeSelect;
            editTreeView.AfterSelect += editTreeView_AfterSelect;

            cbb_Customer.SelectedValueChanged += cbb_CustomerId_SelectedValueChanged;

            dtg_Customer.SelectionChanged += dtg_Customer_SelectionChanged;

            dtg_Customer.CellFormatting += dtg_customer_CellFormatting;
            dtg_Customer.CellPainting += dtg_customer_CellPainting;

            dtg_Order.CellFormatting += dtg_Order_CellFormatting;
            dtg_Order.CellPainting += dtg_Order_CellPainting;

            editPanel.Visible = false;
            pnl_EditOrder.Visible = false;

            cbb_OrderKindGood.Items.Add(Definitions.COMBOBOX_KINDOF_GAS);
            cbb_OrderKindGood.Items.Add(Definitions.COMBOBOX_KINDOF_VALVE);
            cbb_OrderKindGood.Items.Add(Definitions.COMBOBOX_KINDOF_SHELL);

            cbb_OrderKindGood.SelectedValueChanged += cbb_OrderKindGood_SelectedValueChanged;

            cbb_OrderDeliverer.SelectedValueChanged += cbb_OrderDeliverer_SelectedValueChanged;
            cbb_OrderGoodCode.SelectedValueChanged += cbb_OrderGoodCode_SelectedValueChanged;

            txt_OrderQuantity.Text = "0";
            txt_OrderQuantity.TextChanged += txt_OrderQuantity_TextChanged;
            txt_HomePhoneCustomer.TextChanged += txt_OrderCustomerHomePhone_TextChanged;
            txt_MobileCutomer.TextChanged += txt_OrderCustomerMobile_TextChanged;

            LoadCustomers();

            LoadDeliver();

            LoadOrder();
            try
            {
                cbb_Customer.SelectedIndex = 0;
                cbb_OrderKindGood.SelectedIndex = 0;
                cbb_OrderGoodCode.SelectedIndex = 0;
            }
            catch
            {
            }


            dtg_Order.SelectionChanged += dtg_Order_SelectionChanged;

            dtg_Customer.CellClick += dtg_Customer_CellClick;
            dtg_Order.CellClick += dtg_Order_CellClick;

            dtg_Customer.CellDoubleClick += dtg_Customer_CellDoubleClick;
            dtg_Order.CellDoubleClick += dtg_Order_CellDoubleClick;
            ckb_CustomerDateFilter.CheckedChanged += ckb_CustomerDateFilter_CheckedChanged;
            ckb_CustomerRecordFilter.CheckedChanged += ckb_CustomerRecordFilter_CheckedChanged;

            dtp_FromDate.ValueChanged += dtp_Date_ValueChanged;
            dtp_ToDate.ValueChanged += dtp_Date_ValueChanged;
            txt_CustomerRecordFilter.TextChanged += txt_CustomerRecordFilter_TextChanged;

            tmr_SearchOrder.Enabled = false;
            tmr_SearchCustomer.Enabled = false;

            txt_searchOrder.TextChanged += txt_searchOrder_TextChanged;
            txt_SearchCustomer.TextChanged += txt_SearchCustomer_TextChanged;
            txt_OrderPrice.TextChanged += txt_OrderPrice_TextChanged;

            #endregion

            UserPemission(_user.user_roleId);

            #region Check Modem at startup

            UpdateStatus(String.Empty);
            try
            {
                if (CheckModem())
                    UpdateStatus(Resources.Connect_Success);
            }
            catch (Exception ex)
            {
                UpdateStatus(ex.Message);
            }

            #endregion
        }

        #region IMainFormInterface Members

        /// <summary>
        ///   Receives the call and show receive call form.
        /// </summary>
        /// <param name = "status">The status.</param>
        /// <param name = "number">The number.</param>
        public void ReceiveCall(String status, String number)
        {
            TreeNode_User currentNode = null;
            for (int count = 0; count < editTreeView.Nodes[NODE_CALL].Nodes.Count; count++)
            {
                currentNode = ((TreeNode_User) editTreeView.Nodes[NODE_CALL].Nodes[count]);
                if (((currentNode.cus_HomeNumber.Equals(number) || currentNode.cus_PhoneNumber.Equals(number)) &&
                     currentNode.call == 0) && !currentNode.isAnswered)
                {
                    return;
                }
            }


            GSS.DataAccessLayer.GSS.GSS_CustomerDataTable customers = _customerAdapter.GetCustomerByTelephone(number);

            if (customers.Rows.Count == 0)
            {
                if (ObjReceiveCall == null)
                {

                    ObjReceiveCall = new Form_ReceiveCall(Resources.User_New, number,
                            Resources.MainForm_ReceiveCall_Unknown, 0, 0, this, customers);
                    ObjReceiveCall.Show_Form();
                }
                else
                {
                    ObjReceiveCall.SetCall(Resources.User_New, number, Resources.MainForm_ReceiveCall_Unknown, 0, 0,
                        customers);

                    ObjReceiveCall.SetOpacity(100);
                    ObjReceiveCall.Show_Form();
                }
            }
            else
            {
                if (customers[0].cus_Id != 0)
                {
                    if (ObjReceiveCall == null)
                    {
                        var orderNumber = (int) _orderAdapter.GetOrderNumberByCustomerId(customers[0].cus_Id);
                        int revenue = 0;

                        if (_orderAdapter.GetRevenueByUserId(customers[0].cus_Id) != null)
                        {
                            revenue = (int) _orderAdapter.GetRevenueByUserId(customers[0].cus_Id);
                        }

                        ObjReceiveCall = new Form_ReceiveCall(customers[0].cus_Name, number, customers[0].cus_Address,
                            orderNumber,
                            revenue, this, customers);
                        ObjReceiveCall.Show_Form();
                    }
                    else
                    {
                        var orderNumber = (int) _orderAdapter.GetOrderNumberByCustomerId(customers[0].cus_Id);
                        int revenue = 0;

                        if (_orderAdapter.GetRevenueByUserId(customers[0].cus_Id) != null)
                        {
                            revenue = (int) _orderAdapter.GetRevenueByUserId(customers[0].cus_Id);
                        }
                        UpdateStatus("_ _ _");
                        ObjReceiveCall.SetCall(customers[0].cus_Name, number, customers[0].cus_Address, orderNumber,
                            revenue,
                            customers);
                        ObjReceiveCall.SetOpacity(100);
                        ObjReceiveCall.Show_Form();
    
                    }
                }
                else
                {
                    return;
                }
            }
            ShowForm(ObjReceiveCall);
        }


        /// <summary>
        ///   Answers the call.
        /// </summary>
        /// <param name = "phoneNo">The phone number.</param>
        public void Answer(String phoneNo)
        {
            pnl_Call.Invoke((MethodInvoker) (() => PnlVisible(true)));
            tmr_Call.Start();
            lbl_PhoneNo.Text = phoneNo;
            InsertAnswerCall(phoneNo);
            if (ObjReceiveCall.phone == phoneNo)
            {
                ObjReceiveCall.Hide_Form();
                try
                {
                    _modem.ReceiveCall();
                    foreach (TreeNode_User user in
                        editTreeView.Nodes[NODE_CALL].Nodes.Cast<TreeNode_User>().Where(
                            node => node.cus_HomeNumber == phoneNo || node.cus_HomeNumber == phoneNo))
                    {
                        IncreaseNode(user, editTreeView, 0 - user.call, true, true);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    UpdateStatus(ex.Message);
                }
            }
        }

        /// <summary>
        ///   Miss call.
        /// </summary>
        /// <param name = "phoneNo">The phone.</param>
        public void UnAnswer(String phoneNo)
        {
            InsertMissingCall(phoneNo);
            if (ObjReceiveCall.phone == phoneNo)
            {
                ObjReceiveCall.Hide_Form();
                foreach (TreeNode_User user in
                    editTreeView.Nodes[NODE_CALL].Nodes.Cast<TreeNode_User>().Where( 
                       node => node.cus_PhoneNumber == phoneNo || node.cus_HomeNumber == phoneNo))
                {
                    IncreaseNode(user, editTreeView, 1, false, false);
                    return;
                }

                _customers = _customerAdapter.GetCustomerByTelephone(phoneNo);
                if (_customers.Rows.Count == 0)
                {
                    var newUser = new TreeNode_User(phoneNo);
                    newUser.cus_HomeNumber = phoneNo;
                    newUser.cus_Name = phoneNo;
                    newUser.cus_PhoneNumber = phoneNo;

                    AddNode(newUser, editTreeView, NODE_CALL, false);
                    IncreaseNode(newUser, editTreeView, 1, false, false);
                }
                else
                {
                    GSS.DataAccessLayer.GSS.GSS_CustomerRow customer_row = _customers[0];
                    var newUser = new TreeNode_User(customer_row.cus_Name);
                    newUser.node_customer = customer_row;
                    newUser.loadNode();

                    AddNode(newUser, editTreeView, NODE_CALL, false);
                    IncreaseNode(newUser, editTreeView, 1, false, false);
                }
            }
        }

        #endregion

        /// <summary>
        ///   Declines the call.
        /// </summary>
        /// <param name = "phoneNo">The phone.</param>
        public void Decline(string phoneNo)
        {

            InsertMissingCall(phoneNo);
            if (ObjReceiveCall.phone == phoneNo)
            {
                ObjReceiveCall.Hide_Form();
                
                _modem.HangUpCall();
                foreach (TreeNode_User user in
                    editTreeView.Nodes[NODE_CALL].Nodes.Cast<TreeNode_User>().Where(
                        node => node.cus_HomeNumber == phoneNo || node.cus_HomeNumber == phoneNo))
                {
                    IncreaseNode(user, editTreeView, 0, true, false);
                    return;
                }
            }
        }

        /// <summary>
        ///   Create a new thread to open Receive Call's Form.
        /// </summary>
        public void ReceiveCallThread()
        {
            ReceiveCall(_status, phone);
        }

        /// <summary>
        ///   Shows the form.
        /// </summary>
        /// <param name = "form">The form.</param>
        public void ShowForm(Popup_Form form)
        {
            if (form == null)
            {
                return;
            }
            if (form.InvokeRequired)
            {
                Show_FormCallBack d = ShowForm;
                form.Invoke(d, new object[] {form});
            }
            else
            {
                try
                {
                    Application.Run(form);
                }
                catch
                {
                    form.Show();
                }
            }
        }

        /// <summary>
        ///   Handles the CellDoubleClick event of the DataGridView dtg_Order control.
        /// </summary>
        private void dtg_Order_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            for (int count = 0; count < editTreeView.Nodes[NODE_ORDER].Nodes.Count; count++)
            {
                if (((TreeNode_Order) editTreeView.Nodes[NODE_ORDER].Nodes[count]).node_order != null &&
                    ((TreeNode_Order) editTreeView.Nodes[NODE_ORDER].Nodes[count]).node_order.ode_Id ==
                    ((DataGridViewRow_Order) dtg_Order.SelectedRows[0]).row_order.ode_Id)
                {
                    editTreeView.Nodes[NODE_ORDER].Expand();
                    editTreeView.SelectedNode = editTreeView.Nodes[NODE_ORDER].Nodes[count];
                    editTreeView.Focus();
                    return;
                }
            }

            GSS.DataAccessLayer.GSS.GSS_OrderRow order_row =
                ((DataGridViewRow_Order) dtg_Order.SelectedRows[0]).row_order;

            var newOrder =
                new TreeNode_Order(
                    (dtg_Order.SelectedRows[0]).Cells[Definitions.COLUMN_NAME_ORDER_CUSNAME].Value.ToString());

            newOrder.node_order = order_row;

            newOrder.LoadNode();

            editTreeView.Nodes[NODE_ORDER].Nodes.Add(newOrder);

            editTreeView.Nodes[NODE_ORDER].Expand();
            editTreeView.SelectedNode = newOrder;
            editTreeView.Focus();
        }

        /// <summary>
        ///   Handles the CellDoubleClick event of the DataGridView dtg_Customer control.
        /// </summary>
        private void dtg_Customer_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            for (int count = 0; count < editTreeView.Nodes[NODE_EDIT].Nodes.Count; count++)
            {
                if (((TreeNode_User) editTreeView.Nodes[NODE_EDIT].Nodes[count]).node_customer != null &&
                    ((TreeNode_User) editTreeView.Nodes[NODE_EDIT].Nodes[count]).node_customer.cus_Id ==
                    ((DataGridViewRow_Customer) dtg_Customer.SelectedRows[0]).row_customer.cus_Id)
                {
                    editTreeView.Nodes[NODE_EDIT].Expand();
                    editTreeView.SelectedNode = editTreeView.Nodes[NODE_EDIT].Nodes[count];
                    editTreeView.Focus();
                    return;
                }
            }

            GSS.DataAccessLayer.GSS.GSS_CustomerRow customer_row =
                ((DataGridViewRow_Customer) dtg_Customer.SelectedRows[0]).row_customer;

            var newUser = new TreeNode_User(customer_row.cus_Name) {node_customer = customer_row};

            newUser.loadNode();

            editTreeView.Nodes[NODE_EDIT].Nodes.Add(newUser);


            editTreeView.Nodes[NODE_EDIT].Expand();
            editTreeView.SelectedNode = newUser;
            editTreeView.Focus();
        }

        /// <summary>
        ///   Handles the TextChanged event of the textbox txt_OrderCustomerMobile control.
        /// </summary>
        private void txt_OrderCustomerMobile_TextChanged(object sender, EventArgs e)
        {
            txt_MobileCutomer.Text = txt_MobileCutomer.Text.Trim();
            if (txt_MobileCutomer.Text.Trim().Length == 0)
                return;

            for (int count = 0; count < txt_MobileCutomer.Text.Length; count++)
            {
                if ((txt_MobileCutomer.Text[count]) != '0'
                    && (txt_MobileCutomer.Text[count]) != '1'
                    && (txt_MobileCutomer.Text[count]) != '2'
                    && (txt_MobileCutomer.Text[count]) != '3'
                    && (txt_MobileCutomer.Text[count]) != '4'
                    && (txt_MobileCutomer.Text[count]) != '5'
                    && (txt_MobileCutomer.Text[count]) != '6'
                    && (txt_MobileCutomer.Text[count]) != '7'
                    && (txt_MobileCutomer.Text[count]) != '8'
                    && (txt_MobileCutomer.Text[count]) != '9'
                    )
                {
                    txt_MobileCutomer.Text = txt_MobileCutomer.Text.Remove(count, 1);
                    count--;
                }
            }
        }

        /// <summary>
        ///   Handles the TextChanged event of the textbox txt_OrderCustomerHomePhone control.
        /// </summary>
        private void txt_OrderCustomerHomePhone_TextChanged(object sender, EventArgs e)
        {
            txt_HomePhoneCustomer.Text = txt_HomePhoneCustomer.Text.Trim();
            if (txt_HomePhoneCustomer.Text.Trim().Length == 0)
                return;

            for (int count = 0; count < txt_HomePhoneCustomer.Text.Length; count++)
            {
                if ((txt_HomePhoneCustomer.Text[count]) != '0'
                    && (txt_HomePhoneCustomer.Text[count]) != '1'
                    && (txt_HomePhoneCustomer.Text[count]) != '2'
                    && (txt_HomePhoneCustomer.Text[count]) != '3'
                    && (txt_HomePhoneCustomer.Text[count]) != '4'
                    && (txt_HomePhoneCustomer.Text[count]) != '5'
                    && (txt_HomePhoneCustomer.Text[count]) != '6'
                    && (txt_HomePhoneCustomer.Text[count]) != '7'
                    && (txt_HomePhoneCustomer.Text[count]) != '8'
                    && (txt_HomePhoneCustomer.Text[count]) != '9'
                    )
                {
                    txt_HomePhoneCustomer.Text = txt_HomePhoneCustomer.Text.Remove(count, 1);
                    count--;
                }
            }
        }


        /// <summary>
        ///   Handles the TextChanged event of the textbox txt_OrderPrice control.
        /// </summary>
        private void txt_OrderPrice_TextChanged(object sender, EventArgs e)
        {
            txt_PaidMoney.Text = "0";
        }

        /// <summary>
        ///   Handles the TextChanged event of the textbox txt_SearchCustomer control.
        /// </summary>
        private void txt_SearchCustomer_TextChanged(object sender, EventArgs e)
        {
            tmr_SearchCustomer.Enabled = false;
            if (txt_SearchCustomer.Text.Trim().Length > 0)
                tmr_SearchCustomer.Enabled = true;
            else
                LoadCustomers();
        }

        /// <summary>
        ///   Handles the TextChanged event of the textbox txt_searchOrder control.
        /// </summary>
        private void txt_searchOrder_TextChanged(object sender, EventArgs e)
        {
            tmr_SearchOrder.Enabled = false;
            if (txt_searchOrder.Text.Trim().Length > 0)
                tmr_SearchOrder.Enabled = true;
            else
                LoadOrder();
        }

        /// <summary>
        ///   Handles the TextChanged event of the textbox txt_CustomerRecordFilter control.
        /// </summary>
        private void txt_CustomerRecordFilter_TextChanged(object sender, EventArgs e)
        {
            for (int count = 0; count < txt_CustomerRecordFilter.Text.Length; count++)
            {
                if ((txt_CustomerRecordFilter.Text[count]) != '0'
                    && (txt_CustomerRecordFilter.Text[count]) != '1'
                    && (txt_CustomerRecordFilter.Text[count]) != '2'
                    && (txt_CustomerRecordFilter.Text[count]) != '3'
                    && (txt_CustomerRecordFilter.Text[count]) != '4'
                    && (txt_CustomerRecordFilter.Text[count]) != '5'
                    && (txt_CustomerRecordFilter.Text[count]) != '6'
                    && (txt_CustomerRecordFilter.Text[count]) != '7'
                    && (txt_CustomerRecordFilter.Text[count]) != '8'
                    && (txt_CustomerRecordFilter.Text[count]) != '9'
                    )
                {
                    txt_CustomerRecordFilter.Text = txt_CustomerRecordFilter.Text.Remove(count, 1);
                    count--;
                }
            }

            if (txt_CustomerRecordFilter.Text.Trim().Length == 0 ||
                Int32.Parse(txt_CustomerRecordFilter.Text.Trim()) == 0)
            {
                txt_CustomerRecordFilter.Text = "1";
            }

            LoadOrder();
        }

        /// <summary>
        ///   Handles the CheckedChanged event of the checkbox ckb_CustomerRecordFilter control.
        /// </summary>
        private void ckb_CustomerRecordFilter_CheckedChanged(object sender, EventArgs e)
        {
            txt_CustomerRecordFilter.Enabled = ckb_CustomerRecordFilter.Checked;
            if (!ckb_CustomerRecordFilter.Checked && txt_CustomerRecordFilter.Text.Trim().Length > 0)
            {
                LoadOrder();
            }
            else if (ckb_CustomerRecordFilter.Checked && txt_CustomerRecordFilter.Text.Trim().Length > 0)
            {
                LoadOrder();
            }
        }

        /// <summary>
        ///   Handles the ValueChanged event of the DateTimePicker dtp_Date control.
        /// </summary>
        private void dtp_Date_ValueChanged(object sender, EventArgs e)
        {
            if (DateTime.Compare(dtp_FromDate.Value, dtp_ToDate.Value) > 0)
            {
                MessageBox.Show(Resources.Due_Date_Error, Resources.Msb_Title_Error,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                dtp_FromDate.ValueChanged -= dtp_Date_ValueChanged;
                dtp_ToDate.ValueChanged -= dtp_Date_ValueChanged;
                dtp_ToDate.Value = dtp_FromDate.Value;
                dtp_FromDate.ValueChanged += dtp_Date_ValueChanged;
                dtp_ToDate.ValueChanged += dtp_Date_ValueChanged;
            }
            else
            {
                dtp_FromDate.ValueChanged -= dtp_Date_ValueChanged;
                dtp_ToDate.ValueChanged -= dtp_Date_ValueChanged;
                dtp_FromDate.Value =
                    dtp_FromDate.Value.AddHours(0 - dtp_FromDate.Value.Hour).AddMinutes(0 - dtp_FromDate.Value.Minute).
                        AddSeconds(0 - dtp_FromDate.Value.Second);
                dtp_ToDate.Value =
                    dtp_ToDate.Value.AddHours(0 - dtp_ToDate.Value.Hour).AddMinutes(0 - dtp_ToDate.Value.Minute).
                        AddSeconds(0 - dtp_ToDate.Value.Second);
                dtp_FromDate.ValueChanged += dtp_Date_ValueChanged;
                dtp_ToDate.ValueChanged += dtp_Date_ValueChanged;
                LoadOrder();
            }
        }

        /// <summary>
        ///   Handles the CheckedChanged event of the ckb_CustomerDateFilter control.
        /// </summary>
        /// <param name = "sender">The source of the event.</param>
        /// <param name = "e">The <see cref = "EventArgs" /> instance containing the event data.</param>
        /// <remarks>
        /// </remarks>
        private void ckb_CustomerDateFilter_CheckedChanged(object sender, EventArgs e)
        {
            dtp_FromDate.Enabled = ckb_CustomerDateFilter.Checked;
            dtp_ToDate.Enabled = ckb_CustomerDateFilter.Checked;
            if (!ckb_CustomerDateFilter.Checked)
            {
                LoadOrder();
            }
        }

        /// <summary>
        ///   Handles the CellClick event of the DataGridView dtg_Order control.
        /// </summary>
        private void dtg_Order_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dtg_Order.Columns[Definitions.COLUMN_NAME_ORDER_REMOVE].Index &&
                dtg_Order[e.ColumnIndex, e.RowIndex] is DataGridViewButtonCell)
            {
                DialogResult result =
                    MessageBox.Show(
                        string.Format(Resources.Msb_Order_Delete_Confirm,
                            (dtg_Order.Rows[e.RowIndex]).Cells[Definitions.COLUMN_NAME_ORDER_CUSNAME].Value),
                        Resources.Msb_Title_Delete_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (((DataGridViewRow_Order) dtg_Order.Rows[e.RowIndex]).row_order == null)
                    {
                        dtg_Order.Rows.RemoveAt(e.RowIndex);
                    }
                    else
                    {
                        try
                        {
                            _orderAdapter.DeleteOrder(
                                ((DataGridViewRow_Order) dtg_Order.Rows[e.RowIndex]).row_order.ode_Id);
                            dtg_Order.Rows.RemoveAt(e.RowIndex);
                            LoadOrder();
                        }
                        catch (Exception ext)
                        {
                            MessageBox.Show(Resources.Msb_Order_Delete_Error, Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        /// <summary>
        ///   Handles the CellClick event of the DataGridView dtg_Customer control.
        /// </summary>
        private void dtg_Customer_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            #region Delete Customer

            if (e.ColumnIndex == dtg_Customer.Columns[Definitions.COLUMN_NAME_CUSTOMER_REMOVE].Index &&
                dtg_Customer[e.ColumnIndex, e.RowIndex] is DataGridViewButtonCell)
            {
                DialogResult result =
                    MessageBox.Show(
                        string.Format(Resources.Msb_Customer_Delete_Confirm,
                            (dtg_Customer.Rows[e.RowIndex]).Cells[Definitions.COLUMN_NAME_CUSTOMER_NAME].Value),
                        Resources.Msb_Title_Delete_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (((DataGridViewRow_Customer) dtg_Customer.Rows[e.RowIndex]).row_customer == null)
                    {
                        dtg_Customer.Rows.RemoveAt(e.RowIndex);
                    }
                    else
                    {
                        try
                        {
                            _customerAdapter.DeleteCustomer(
                                ((DataGridViewRow_Customer) dtg_Customer.Rows[e.RowIndex]).row_customer.cus_Id);
                            dtg_Customer.Rows.RemoveAt(e.RowIndex);
                            LoadCustomers();
                        }
                        catch (Exception)
                        {
                            MessageBox.Show(Resources.Msb_Customer_Delete_Error,
                                Resources.Msb_Title_Customer_Delete_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }

            #endregion

            if (ObjFormCall == null && ObjSendMessage == null) return;
            if (e.RowIndex < 0) return;
            if (ObjFormCall != null)
            {
                if (e.ColumnIndex == dtg_Customer.Columns[Definitions.COLUMN_NAME_CUSTOMER_MOBILE].Index)
                {
                    string _phone = dtg_Customer[e.ColumnIndex, e.RowIndex].FormattedValue.ToString();
                    if (string.IsNullOrEmpty(_phone))
                    {
                        _phone =
                            dtg_Customer[Definitions.COLUMN_NAME_CUSTOMER_HOMEPHONE, e.RowIndex].FormattedValue.ToString
                                ();
                    }
                    UpdateCallNo(_phone);
                }
                else if (e.ColumnIndex == dtg_Customer.Columns[Definitions.COLUMN_NAME_CUSTOMER_HOMEPHONE].Index)
                {
                    UpdateCallNo(dtg_Customer[e.ColumnIndex, e.RowIndex].FormattedValue.ToString());
                }
                else
                {
                    UpdateCallNo(
                        dtg_Customer[Definitions.COLUMN_NAME_CUSTOMER_MOBILE, e.RowIndex].FormattedValue.ToString());
                }
            }
            if (ObjSendMessage != null)
            {
                var _phone = dtg_Customer[Definitions.COLUMN_NAME_CUSTOMER_MOBILE, e.RowIndex].FormattedValue.ToString();
                UpdateMessagePhone(_phone);
            }
        }

        /// <summary>
        ///   Handles the SelectionChanged event of the DataGridView dtg_Order control.
        /// </summary>
        private void dtg_Order_SelectionChanged(object sender, EventArgs e)
        {
            if (dtg_Order.SelectedRows.Count > 1 || dtg_Order.SelectedRows.Count == 0)
            {
                btn_EditExistingOrder.Enabled = false;
            }

            else
            {
                btn_EditExistingOrder.Enabled = true;
            }
        }

        /// <summary>
        ///   Handles the TextChanged event of the textbox txt_Ordertextbox Quantity.
        /// </summary>
        private void txt_OrderQuantity_TextChanged(object sender, EventArgs e)
        {
            txt_OrderQuantity.Text = txt_OrderQuantity.Text.Trim();
            for (int count = 0; count < txt_OrderQuantity.Text.Length; count++)
            {
                if ((txt_OrderQuantity.Text[count]) != '0'
                    && (txt_OrderQuantity.Text[count]) != '1'
                    && (txt_OrderQuantity.Text[count]) != '2'
                    && (txt_OrderQuantity.Text[count]) != '3'
                    && (txt_OrderQuantity.Text[count]) != '4'
                    && (txt_OrderQuantity.Text[count]) != '5'
                    && (txt_OrderQuantity.Text[count]) != '6'
                    && (txt_OrderQuantity.Text[count]) != '7'
                    && (txt_OrderQuantity.Text[count]) != '8'
                    && (txt_OrderQuantity.Text[count]) != '9'
                    )
                {
                    txt_OrderQuantity.Text = txt_OrderQuantity.Text.Remove(count, 1);
                    count--;
                }
            }

            if (txt_OrderQuantity.Text.Trim().Length > 0)
                txt_OrderQuantity.Text = Int64.Parse(txt_OrderQuantity.Text) + String.Empty;


            if (txt_OrderQuantity.Text.Trim().Length == 0 || Int32.Parse(txt_OrderQuantity.Text.Trim()) == 0)
            {
                txt_OrderQuantity.Text = "0";
                txt_OrderPrice.Text = "0";
                lbl_BorrowMoney.Text = string.Format(Resources.Borrow_Money_One_Arg,
                    (Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim())));
                return;
            }


            String currentGood = cbb_OrderKindGood.SelectedItem.ToString().Trim();

            if (currentGood == Definitions.COMBOBOX_KINDOF_GAS)
            {
                int ret;
                if (cbb_OrderGoodCode.SelectedValue != null &&
                    Int32.TryParse(cbb_OrderGoodCode.SelectedValue.ToString(), out ret))
                {
                    GSS.DataAccessLayer.GSS.GasValueDataTable gases = _gasvalueAdapter.GetValueByGasId(ret);
                    foreach (GSS.DataAccessLayer.GSS.GasValueRow gas in gases)
                    {
                        txt_OrderPrice.Text = Int32.Parse(txt_OrderQuantity.Text)*gas.val_Price + String.Empty;
                    }
                }
            }
            else if (currentGood == Definitions.COMBOBOX_KINDOF_VALVE)
            {
                int ret;
                if (cbb_OrderGoodCode.SelectedValue != null &&
                    Int32.TryParse(cbb_OrderGoodCode.SelectedValue.ToString(), out ret))
                {
                    GSS.DataAccessLayer.GSS.ValveValueDataTable valves = _valvevalueAdapter.GetValueByValveId(ret);


                    foreach (GSS.DataAccessLayer.GSS.ValveValueRow valve in valves)
                    {
                        txt_OrderPrice.Text = Int32.Parse(txt_OrderQuantity.Text)*valve.val_Price + String.Empty;
                    }
                }
            }
            else if (currentGood == Definitions.COMBOBOX_KINDOF_SHELL)
            {
                int ret;
                if (cbb_OrderGoodCode.SelectedValue != null &&
                    Int32.TryParse(cbb_OrderGoodCode.SelectedValue.ToString(), out ret))
                {
                    GSS.DataAccessLayer.GSS.ShellValueDataTable shelles = _shellvalueAdapter.GetValueByShellId(ret);


                    foreach (GSS.DataAccessLayer.GSS.ShellValueRow shell in shelles)
                    {
                        txt_OrderPrice.Text = Int32.Parse(txt_OrderQuantity.Text)*shell.val_Price + String.Empty;
                    }
                }
            }

            if (currentGood != Definitions.COMBOBOX_KINDOF_GAS)
            {
                txt_ReturnShell.Text = "0";
                lbl_BorrowShell.Text = string.Format(Resources.Borrow_Shell_One_Arg, 0);
            }
            else
            {
                txt_ReturnShell.Text = txt_OrderQuantity.Text;
                lbl_BorrowShell.Text = string.Format(Resources.Borrow_Shell_One_Arg,
                    Int32.Parse(txt_OrderQuantity.Text) - Int32.Parse(txt_ReturnShell.Text));
            }


            lbl_BorrowMoney.Text = string.Format(Resources.Borrow_Money_One_Arg,
                (Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim())));
        }

        /// <summary>
        ///   Handles the SelectedValueChanged event of the combobox cbb_OrderGoodCode control.
        /// </summary>
        private void cbb_OrderGoodCode_SelectedValueChanged(object sender, EventArgs e)
        {
            var order = ((TreeNode_Order) editTreeView.SelectedNode);

            String currentGood = cbb_OrderKindGood.SelectedItem.ToString().Trim();

            if (currentGood == Definitions.COMBOBOX_KINDOF_GAS)
            {
                int ret;
                if (cbb_OrderGoodCode.SelectedValue != null &&
                    Int32.TryParse(cbb_OrderGoodCode.SelectedValue.ToString(), out ret))
                {
                    GSS.DataAccessLayer.GSS.GasValueDataTable gases = _gasvalueAdapter.GetValueByGasId(ret);


                    foreach (GSS.DataAccessLayer.GSS.GasValueRow gas in gases)
                    {
                        try
                        {
                            txt_OrderPrice.Text = Int32.Parse(txt_OrderQuantity.Text)*gas.val_Price + String.Empty;
                        }
                        catch (Exception)
                        {
                            txt_OrderPrice.Text = gas.val_Price + String.Empty;
                        }

                        if (order != null)
                        {
                            order.ode_GasValueId = gas.val_Id;
                            order.ode_ValveValueId = -1;
                            order.ode_ShellValueId = -1;
                        }
                    }
                }
            }
            else if (currentGood == Definitions.COMBOBOX_KINDOF_VALVE)
            {
                int ret;
                if (cbb_OrderGoodCode.SelectedValue != null &&
                    Int32.TryParse(cbb_OrderGoodCode.SelectedValue.ToString(), out ret))
                {
                    GSS.DataAccessLayer.GSS.ValveValueDataTable valves = _valvevalueAdapter.GetValueByValveId(ret);


                    foreach (GSS.DataAccessLayer.GSS.ValveValueRow valve in valves)
                    {
                        try
                        {
                            txt_OrderPrice.Text = Int32.Parse(txt_OrderQuantity.Text)*valve.val_Price + String.Empty;
                        }
                        catch (Exception)
                        {
                            txt_OrderPrice.Text = valve.val_Price + String.Empty;
                        }

                        if (order != null)
                        {
                            order.ode_ValveValueId = valve.val_Id;
                            order.ode_GasValueId = -1;
                            order.ode_ShellValueId = -1;
                        }
                    }
                }
            }
            else if (currentGood == Definitions.COMBOBOX_KINDOF_SHELL)
            {
                int ret;
                if (cbb_OrderGoodCode.SelectedValue != null &&
                    Int32.TryParse(cbb_OrderGoodCode.SelectedValue.ToString(), out ret))
                {
                    GSS.DataAccessLayer.GSS.ShellValueDataTable shelles = _shellvalueAdapter.GetValueByShellId(ret);


                    foreach (GSS.DataAccessLayer.GSS.ShellValueRow shell in shelles)
                    {
                        try
                        {
                            txt_OrderPrice.Text = Int32.Parse(txt_OrderQuantity.Text)*shell.val_Price + String.Empty;
                        }
                        catch (Exception)
                        {
                            txt_OrderPrice.Text = shell.val_Price + String.Empty;
                        }

                        if (order != null)
                        {
                            order.ode_ShellValueId = shell.val_Id;
                            order.ode_GasValueId = -1;
                            order.ode_ValveValueId = -1;
                        }
                    }
                }
            }

            lbl_BorrowMoney.Text = string.Format(Resources.Borrow_Money_One_Arg,
                (Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim())));
        }

        /// <summary>
        ///   Handles the SelectedValueChanged event of the combobox cbb_OrderDeliverer control.
        /// </summary>
        private static void cbb_OrderDeliverer_SelectedValueChanged(object sender, EventArgs e)
        {
        }

        /// <summary>
        ///   Handles the SelectedValueChanged event of the combobox cbb_OrderKindGood control.
        /// </summary>
        private void cbb_OrderKindGood_SelectedValueChanged(object sender, EventArgs e)
        {
            String currentGood = cbb_OrderKindGood.SelectedItem.ToString().Trim();

            if (currentGood == Definitions.COMBOBOX_KINDOF_GAS)
            {
                txt_ReturnShell.Enabled = true;

                txt_ReturnShell.Text = txt_OrderQuantity.Text;

                cbb_OrderGoodCode.DataSource = null;
                cbb_OrderGoodCode.Items.Clear();

                GSS.DataAccessLayer.GSS.GSS_GasDataTable gases = _gasAdapter.GetGass();


                var DataTable = new DataTable();
                DataRow DataRow;

                DataTable.Columns.Add(Definitions.FIELD_TEXT);
                DataTable.Columns.Add(Definitions.FIELD_VALUE);

                foreach (GSS.DataAccessLayer.GSS.GSS_GasRow gas in gases)
                {
                    DataRow = DataTable.NewRow();
                    DataRow[0] = gas.gas_Name;
                    DataRow[1] = gas.gas_Id;
                    DataTable.Rows.Add(DataRow);
                }

                cbb_OrderGoodCode.DataSource = DataTable;
                cbb_OrderGoodCode.DisplayMember = Definitions.FIELD_TEXT;
                cbb_OrderGoodCode.ValueMember = Definitions.FIELD_VALUE;

                var order = ((TreeNode_Order) editTreeView.SelectedNode);
                if (order != null)
                {
                    order.ode_ValveId = -1;
                    order.ode_ShellId = -1;
                }

                lbl_BorrowMoney.Text = string.Format(Resources.Borrow_Money_One_Arg,
                    (Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim())));
                lbl_BorrowShell.Text = string.Format(Resources.Borrow_Shell_One_Arg,
                    (Int32.Parse(txt_OrderQuantity.Text.Trim()) -
                     Int32.Parse(txt_ReturnShell.Text.Trim())));
            }
            else if (currentGood == Definitions.COMBOBOX_KINDOF_VALVE)
            {
                txt_ReturnShell.Enabled = false;
                lbl_BorrowShell.Text = "Nợ: 0 vỏ";
                txt_ReturnShell.Text = "0";
                cbb_OrderGoodCode.DataSource = null;
                cbb_OrderGoodCode.Items.Clear();

                GSS.DataAccessLayer.GSS.GSS_ValveDataTable valves = _valveAdapter.GetValves();


                var DataTable = new DataTable();
                DataRow DataRow;

                DataTable.Columns.Add(Definitions.FIELD_TEXT);
                DataTable.Columns.Add(Definitions.FIELD_VALUE);

                foreach (GSS.DataAccessLayer.GSS.GSS_ValveRow valve in valves)
                {
                    DataRow = DataTable.NewRow();
                    DataRow[0] = valve.valve_Name;
                    DataRow[1] = valve.valve_Id;
                    DataTable.Rows.Add(DataRow);
                }

                cbb_OrderGoodCode.DataSource = DataTable;
                cbb_OrderGoodCode.DisplayMember = Definitions.FIELD_TEXT;
                cbb_OrderGoodCode.ValueMember = Definitions.FIELD_VALUE;

                var order = ((TreeNode_Order) editTreeView.SelectedNode);
                if (order != null)
                {
                    order.ode_GasId = -1;
                    order.ode_ShellId = -1;
                }
                lbl_BorrowMoney.Text = string.Format(Resources.Borrow_Money_One_Arg,
                    (Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim())));
            }
            else if (currentGood == Definitions.COMBOBOX_KINDOF_SHELL)
            {
                txt_ReturnShell.Enabled = false;
                txt_ReturnShell.Text = "0";
                lbl_BorrowShell.Text = "Nợ: 0 vỏ";
                cbb_OrderGoodCode.DataSource = null;
                cbb_OrderGoodCode.Items.Clear();

                GSS.DataAccessLayer.GSS.GSS_ShellDataTable shelles = _shellAdapter.GetShells();


                var DataTable = new DataTable();
                DataRow DataRow;

                DataTable.Columns.Add(Definitions.FIELD_TEXT);
                DataTable.Columns.Add(Definitions.FIELD_VALUE);

                foreach (GSS.DataAccessLayer.GSS.GSS_ShellRow shell in shelles)
                {
                    DataRow = DataTable.NewRow();
                    DataRow[0] = shell.shell_Name;
                    DataRow[1] = shell.shell_Id;
                    DataTable.Rows.Add(DataRow);
                }

                cbb_OrderGoodCode.DataSource = DataTable;
                cbb_OrderGoodCode.DisplayMember = Definitions.FIELD_TEXT;
                cbb_OrderGoodCode.ValueMember = Definitions.FIELD_VALUE;

                var order = ((TreeNode_Order) editTreeView.SelectedNode);
                if (order != null)
                {
                    order.ode_GasId = -1;
                    order.ode_ValveId = -1;
                }

                lbl_BorrowMoney.Text = string.Format(Resources.Borrow_Money_One_Arg,
                    (Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim())));
            }
        }

        /// <summary>
        ///   Handles the SelectedValueChanged event of the combobox cbb_CustomerId control.
        /// </summary>
        private void cbb_CustomerId_SelectedValueChanged(object sender, EventArgs e)
        {
            String currentId = cbb_Customer.SelectedValue.ToString().Trim();

            if (currentId.Length == 0)
            {
                if (ptb_order.Image != null)
                    ptb_order.Image.Dispose();
                ptb_order.Image = null;
                return;
            }

            //userHashTable
            if (_userHashTable.ContainsKey(currentId))
            {
                GSS.DataAccessLayer.GSS.GSS_CustomerRow selectedCustomer =
                    ((GSS.DataAccessLayer.GSS.GSS_CustomerRow) _userHashTable[currentId]);

                txt_OrderCustomerName.Text = selectedCustomer.cus_Name;
                txt_OrderCustomerMobile.Text = selectedCustomer.cus_PhoneNumber;
                txt_OrderCustomerHomePhone.Text = selectedCustomer.cus_HomeNumber;
                txt_OrderCustomerDistrict.Text = selectedCustomer.cus_Distric;
                txt_OrderCustomerCity.Text = selectedCustomer.cus_City;
                txt_OrderCustomerAddess.Text = selectedCustomer.cus_Address;

                if (ptb_order.Image != null)
                    ptb_order.Image.Dispose();
                ptb_order.Image = null;
                if (
                    File.Exists(string.Format(Resources.Map_Path_Two_Argument,
                        Path.GetDirectoryName(Application.ExecutablePath), cbb_Customer.SelectedValue)))
                    ptb_order.Image =
                        new Bitmap(string.Format(Resources.Map_Path_Two_Argument,
                            Path.GetDirectoryName(Application.ExecutablePath), cbb_Customer.SelectedValue));

                var currentOrder = ((TreeNode_Order) editTreeView.SelectedNode);
                if (currentOrder != null)
                    currentOrder.Text = txt_OrderCustomerName.Text;
            }
            checkBorrowCustomer();
            //Refresh();
        }

        /// <summary>
        ///   Loads the user to edit panel.
        /// </summary>
        /// <param name = "user">The user.</param>
        private void LoadUserToEditPanel(TreeNode_User user)
        {
            txt_IdCustomer.Enabled = false;
            if (user.node_customer == null)
            {
                txt_IdCustomer.Text = String.Empty;


                if (ptb_map.Image != null)
                    ptb_map.Image.Dispose();

                ptb_map.Image = null;
            }
            else
            {
                txt_IdCustomer.Text = user.node_customer.cus_Id + String.Empty;

                if (ptb_map.Image != null)
                    ptb_map.Image.Dispose();
                ptb_map.Image = null;
                if (
                    File.Exists(string.Format(Resources.Map_Path_Two_Argument,
                        Path.GetDirectoryName(Application.ExecutablePath), txt_IdCustomer.Text.Trim())))
                    ptb_map.Image =
                        new Bitmap(string.Format(Resources.Map_Path_Two_Argument,
                            Path.GetDirectoryName(Application.ExecutablePath), txt_IdCustomer.Text.Trim()));
            }

            txt_HomePhoneCustomer.Text = user.cus_HomeNumber;
            txt_NameCustomer.Text = user.cus_Name;
            txt_AddressCustomer.Text = user.cus_Address;
            txt_CityCustomer.Text = user.cus_City;
            txt_DistrictCustomer.Text = user.cus_Distric;
            txt_MobileCutomer.Text = user.cus_PhoneNumber;
        }

        /// <summary>
        ///   Loads the order to edit panel.
        /// </summary>
        /// <param name = "order">The order.</param>
        private void LoadOrderToEditPanel(TreeNode_Order order)
        {
            txt_OrderQuantity.Text = order.ode_Quantity + String.Empty;
            txt_OrderComment.Text = order.ode_comment;


            if (order.node_order != null)
            {
                txt_OrderId.Text = order.node_order.ode_Id + String.Empty;
            }

            try
            {
                dt_OrderSellDate.Value = order.ode_Date;
            }
            catch (Exception)
            {
            }

            //Load customer Id
            if (cbb_Customer.SelectedValue.ToString() == order.ode_CustomerId.ToString())
            {
                if (ptb_order.Image != null)
                    ptb_order.Image.Dispose();
                ptb_order.Image = null;
                if (
                    File.Exists(string.Format(Resources.Map_Path_Two_Argument,
                        Path.GetDirectoryName(Application.ExecutablePath), cbb_Customer.SelectedValue)))
                    ptb_order.Image =
                        new Bitmap(string.Format(Resources.Map_Path_Two_Argument,
                            Path.GetDirectoryName(Application.ExecutablePath), cbb_Customer.SelectedValue));
            }

            {
                bool loaded = false;
                for (int count = 0; count < CustomerTable.Rows.Count; count++)
                {
                    if (Int32.Parse(CustomerTable.Rows[count][1].ToString()) == order.ode_CustomerId)
                    {
                        cbb_Customer.SelectedIndex = count;
                        loaded = true;
                    }
                }

                if (!loaded)
                {
                    cbb_Customer.SelectedIndex = 0;
                }
            }


            // Load deliver Id
            {
                var DataTable = (DataTable) cbb_OrderDeliverer.DataSource;

                for (int count = 0; count < DataTable.Rows.Count; count++)
                {
                    String deliverId = DataTable.Rows[count][1].ToString();
                    if (order.ode_DelivererId == Int32.Parse(deliverId))
                    {
                        cbb_OrderDeliverer.SelectedIndex = count;
                    }
                }
            }

            // Load Good Id
            {
                if (order.ode_GasId > 0)
                {
                    for (int count = 0; count < cbb_OrderKindGood.Items.Count; count++)
                    {
                        if (cbb_OrderKindGood.Items[count].ToString() == Definitions.COMBOBOX_KINDOF_GAS)
                        {
                            cbb_OrderKindGood.SelectedIndex = count;
                        }
                    }


                    var DataTable = (DataTable) cbb_OrderGoodCode.DataSource;

                    for (int count = 0; count < DataTable.Rows.Count; count++)
                    {
                        String goodId = DataTable.Rows[count][1].ToString();
                        if (order.ode_GasId == Int32.Parse(goodId))
                        {
                            cbb_OrderGoodCode.SelectedIndex = count;
                        }
                    }
                }
                else if (order.ode_ValveId > 0)
                {
                    for (int count = 0; count < cbb_OrderKindGood.Items.Count; count++)
                    {
                        if (cbb_OrderKindGood.Items[count].ToString() == Definitions.COMBOBOX_KINDOF_VALVE)
                        {
                            cbb_OrderKindGood.SelectedIndex = count;
                        }
                    }

                    var DataTable = (DataTable) cbb_OrderGoodCode.DataSource;

                    for (int count = 0; count < DataTable.Rows.Count; count++)
                    {
                        String goodId = DataTable.Rows[count][1].ToString();
                        if (order.ode_ValveId == Int32.Parse(goodId))
                        {
                            cbb_OrderGoodCode.SelectedIndex = count;
                        }
                    }
                }
                else if (order.ode_ShellId > 0)
                {
                    for (int count = 0; count < cbb_OrderKindGood.Items.Count; count++)
                    {
                        if (cbb_OrderKindGood.Items[count].ToString() == Definitions.COMBOBOX_KINDOF_SHELL)
                        {
                            cbb_OrderKindGood.SelectedIndex = count;
                        }
                    }

                    var DataTable = (DataTable) cbb_OrderGoodCode.DataSource;

                    for (int count = 0; count < DataTable.Rows.Count; count++)
                    {
                        String goodId = DataTable.Rows[count][1].ToString();

                        if (order.ode_ShellId == Int32.Parse(goodId))
                        {
                            cbb_OrderGoodCode.SelectedIndex = count;
                        }
                    }
                }
            }


            txt_ReturnShell.Text = order.ode_ReturnShell + String.Empty;
            txt_PaidMoney.Text = order.ode_PaidMoney + String.Empty;

            checkBorrowCustomer();
        }

        /// <summary>
        ///   Checks the borrow customer.
        /// </summary>
        private void checkBorrowCustomer()
        {
            int borrowMoney = 0;
            String borrowShells = "";
            MoneyBorrowTableAdapter _moneyBorrowAdapter = new MoneyBorrowTableAdapter();
            GSS.DataAccessLayer.GSS.MoneyBorrowDataTable moneyBorrows =
                _moneyBorrowAdapter.GetDataByCustomerId(Int32.Parse(cbb_Customer.SelectedValue.ToString()));
            foreach (GSS.DataAccessLayer.GSS.MoneyBorrowRow moneyBorrow in moneyBorrows)
            {
                borrowMoney += moneyBorrow.ode_BorrowMoney;
            }

            Hashtable borrowTable = new Hashtable();
            ShellBorrowByGasTableAdapter _shellByGasAdapter = new ShellBorrowByGasTableAdapter();
            ShellBorrowDirectTableAdapter _shellDirectAdapter = new ShellBorrowDirectTableAdapter();
            GSS.DataAccessLayer.GSS.ShellBorrowDirectDataTable shellBorrows =
                _shellDirectAdapter.GetDataByCustomerId(Int32.Parse(cbb_Customer.SelectedValue.ToString()));
            foreach (GSS.DataAccessLayer.GSS.ShellBorrowDirectRow shellBorrow in shellBorrows)
            {
                if (!borrowTable.ContainsKey(shellBorrow.cus_Id + "|" + shellBorrow.shell_Id))
                {
                    borrowTable.Add(shellBorrow.cus_Id + "|" + shellBorrow.shell_Id, shellBorrow);
                }
                else
                {
                    ((GSS.DataAccessLayer.GSS.ShellBorrowDirectRow)
                     borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Quantity +=
                        (shellBorrow.ode_Quantity - shellBorrow.ode_ReturnShell);
                    ((GSS.DataAccessLayer.GSS.ShellBorrowDirectRow)
                     borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Date = shellBorrow.ode_Date;
                }
            }

            GSS.DataAccessLayer.GSS.ShellBorrowByGasDataTable shellBorrowsByGas =
                _shellByGasAdapter.GetDataByCustomerId(Int32.Parse(cbb_Customer.SelectedValue.ToString()));
            foreach (GSS.DataAccessLayer.GSS.ShellBorrowByGasRow shellBorrow in shellBorrowsByGas)
            {
                if (!borrowTable.ContainsKey(shellBorrow.cus_Id + "|" + shellBorrow.shell_Id))
                {
                    borrowTable.Add(shellBorrow.cus_Id + "|" + shellBorrow.shell_Id, shellBorrow);
                }
                else
                {
                    if (
                        borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id] is
                        GSS.DataAccessLayer.GSS.ShellBorrowByGasRow)
                    {
                        ((GSS.DataAccessLayer.GSS.ShellBorrowByGasRow)
                         borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Quantity +=
                            (shellBorrow.ode_Quantity - shellBorrow.ode_ReturnShell);
                        ((GSS.DataAccessLayer.GSS.ShellBorrowByGasRow)
                         borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Date = shellBorrow.ode_Date;
                    }
                    else if (
                        borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id] is
                        GSS.DataAccessLayer.GSS.ShellBorrowDirectRow)
                    {
                        ((GSS.DataAccessLayer.GSS.ShellBorrowDirectRow)
                         borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Quantity +=
                            (shellBorrow.ode_Quantity - shellBorrow.ode_ReturnShell);
                        ((GSS.DataAccessLayer.GSS.ShellBorrowDirectRow)
                         borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Date =
                            shellBorrow.ode_Date;
                    }
                }
            }

            foreach (object key in borrowTable.Keys)
            {
                if (borrowTable[key] is GSS.DataAccessLayer.GSS.ShellBorrowByGasRow)
                {
                    if (((GSS.DataAccessLayer.GSS.ShellBorrowByGasRow) borrowTable[key]).ode_Quantity -
                        ((GSS.DataAccessLayer.GSS.ShellBorrowByGasRow) borrowTable[key]).ode_ReturnShell != 0)
                    {
                        borrowShells += (((GSS.DataAccessLayer.GSS.ShellBorrowByGasRow) borrowTable[key]).ode_Quantity -
                                         ((GSS.DataAccessLayer.GSS.ShellBorrowByGasRow) borrowTable[key]).
                                             ode_ReturnShell) + " " +
                                        ((GSS.DataAccessLayer.GSS.ShellBorrowByGasRow) borrowTable[key]).shell_Name +
                                        ",";
                    }
                }
                else if (borrowTable[key] is GSS.DataAccessLayer.GSS.ShellBorrowDirectRow)
                {
                    if (((GSS.DataAccessLayer.GSS.ShellBorrowDirectRow) borrowTable[key]).ode_Quantity -
                        ((GSS.DataAccessLayer.GSS.ShellBorrowDirectRow) borrowTable[key]).ode_ReturnShell != 0)
                    {
                        borrowShells +=
                            (((GSS.DataAccessLayer.GSS.ShellBorrowDirectRow) borrowTable[key]).ode_Quantity -
                             ((GSS.DataAccessLayer.GSS.ShellBorrowDirectRow) borrowTable[key]).ode_ReturnShell) + " " +
                            ((GSS.DataAccessLayer.GSS.ShellBorrowDirectRow) borrowTable[key]).shell_Name +
                            ",";
                    }
                }
            }

            if (borrowMoney != 0)
            {
                lbl_borrow.Text = "Khách hàng này nợ " + borrowMoney + ".000 đồng";
            }
            if (borrowShells.Trim().Length > 0)
            {
                if (borrowMoney == 0)
                    lbl_borrow.Text = "Khách hàng này nợ ";
                else
                    lbl_borrow.Text += ",";

                lbl_borrow.Text += borrowShells;
                lbl_borrow.Text.Remove(lbl_borrow.Text.Length - 2);
            }

            if (borrowMoney == 0 && borrowShells.Trim().Length == 0)
            {
                lbl_borrow.Text = "...";
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_AddNewOrder control.
        /// </summary>
        private void btn_AddNewOrder_Click(object sender, EventArgs e)
        {
            var newOrder = new TreeNode_Order(Resources.New_Order);
            editTreeView.Nodes[NODE_ORDER].Nodes.Add(newOrder);
            editTreeView.Nodes[NODE_ORDER].Expand();
            editTreeView.SelectedNode = newOrder;
            editTreeView.Focus();

            try
            {
                cbb_Customer.SelectedIndex = 1;
                cbb_Customer.SelectedIndex = 0;
                cbb_OrderGoodCode.SelectedIndex = 1;
                cbb_OrderGoodCode.SelectedIndex = 0;
            }
            catch
            {
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_OrderSave control.
        /// </summary>
        private void btn_OrderSave_Click(object sender, EventArgs e)
        {
            if (txt_ReturnShell.Text.Trim() == "0" && txt_PaidMoney.Text.Trim() == "0" &&
                txt_OrderQuantity.Text.Trim() == "0")
            {
                MessageBox.Show(Resources.Order_Infor_Require, Resources.Msb_Title_Inform,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int buy_time =
                (int) _orderAdapter.GetOrderNumberByCustomerId(Int32.Parse(cbb_Customer.SelectedValue.ToString()));
            int? revenue = _orderAdapter.GetRevenueByUserId(Int32.Parse(cbb_Customer.SelectedValue.ToString()));

            if (revenue == null)
            {
                revenue = 0;
            }

            if ((Int32.Parse(txt_PaidMoney.Text) < Int32.Parse(txt_OrderPrice.Text) ||
                 Int32.Parse(txt_OrderQuantity.Text) < Int32.Parse(txt_ReturnShell.Text)) &&
                buy_time < Settings.Default.LIMIT_BORROW_BY_ORDER_TIMES &&
                revenue < Settings.Default.LIMIT_BORROW_BY_REVENUE)
            {
                String message = "Khách hàng này mới chỉ mua hàng " + buy_time + " lần và có doanh thu " + revenue +
                                 ".000 đồng nên chưa thể cho nợ tiền và vỏ\n";
                String currentGood = cbb_OrderKindGood.SelectedItem.ToString().Trim();
                if (currentGood == Definitions.COMBOBOX_KINDOF_GAS)
                {
                    message += "Bạn có thể tạo 1 giao dịch mua " + txt_OrderQuantity.Text +
                               " bình gas dùng cho loại gas này trước và điền vào phần trả vỏ khi mua gas là " +
                               txt_OrderQuantity.Text;
                }
                MessageBox.Show(message);
                return;
            }
            GSS.DataAccessLayer.GSS.GSS_OrderRow currentOrder = ((TreeNode_Order) editTreeView.SelectedNode).node_order;
            var order = ((TreeNode_Order) editTreeView.SelectedNode);

            int current_quantity = 0;

            #region Update Order

            if (currentOrder != null)
            {
                String currentGood = cbb_OrderKindGood.SelectedItem.ToString().Trim();

                #region Combobox là Gas

                if (currentGood == Definitions.COMBOBOX_KINDOF_GAS)
                {
                    current_quantity =
                        (int) _gasAdapter.GetGasQuantityById(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                    if (!currentOrder.IsNull(Definitions.ORDER_GAS_ID))
                    {
                        #region chưa đổi sản phẩm

                        current_quantity =
                            (int)
                            _gasAdapter.GetGasQuantityById(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                        if (currentOrder.ode_GasId == Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()))
                        {
                            current_quantity = (int)
                                               _gasAdapter.GetGasQuantityById(
                                                   Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));

                            if (current_quantity + currentOrder.ode_Quantity < Int32.Parse(txt_OrderQuantity.Text))
                            {
                                MessageBox.Show(
                                    string.Format(Resources.Order_Over_Quantity, current_quantity),
                                    Resources.Msb_Title_Error,
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                            #endregion
                            #region đã đổi sản phẩm

                        else
                        {
                            if (current_quantity < Int32.Parse(txt_OrderQuantity.Text))
                            {
                                MessageBox.Show(
                                    string.Format(Resources.Order_Over_Quantity, current_quantity),
                                    Resources.Msb_Title_Error,
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        #endregion
                    }
                    else if (!currentOrder.IsNull(Definitions.ORDER_VALVE_ID))
                    {
                        if (current_quantity < Int32.Parse(txt_OrderQuantity.Text))
                        {
                            MessageBox.Show(
                                string.Format(Resources.Order_Over_Quantity, current_quantity),
                                Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                    else if (!currentOrder.IsNull(Definitions.ORDER_SHELL_ID))
                    {
                        current_quantity =
                            (int)
                            _shellAdapter.GetShellQuantity(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                        if (current_quantity < Int32.Parse(txt_OrderQuantity.Text))
                        {
                            MessageBox.Show(
                                string.Format(Resources.Order_Over_Quantity, current_quantity),
                                Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                }
                    #endregion
                    #region Combobox là Vỏ

                else if (currentGood == Definitions.COMBOBOX_KINDOF_SHELL)
                {
                    current_quantity =
                        (int) _shellAdapter.GetShellQuantity(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                    if (!currentOrder.IsNull(Definitions.ORDER_SHELL_ID))
                    {
                        #region  chưa đổi sản phẩm

                        if (currentOrder.ode_ShellId == Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()))
                        {
                            current_quantity = (int)
                                               _shellAdapter.GetShellQuantity(
                                                   Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));

                            if (current_quantity + currentOrder.ode_Quantity < Int32.Parse(txt_OrderQuantity.Text))
                            {
                                MessageBox.Show(
                                    string.Format(Resources.Order_Over_Quantity_2, current_quantity,
                                        currentOrder.ode_Quantity), Resources.Msb_Title_Inform,
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                            #endregion
                            #region đã đổi sản phẩm

                        else
                        {
                            current_quantity = (int)
                                               _shellAdapter.GetShellQuantity(
                                                   Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                            if (current_quantity < Int32.Parse(txt_OrderQuantity.Text))
                            {
                                MessageBox.Show(
                                    string.Format(Resources.Order_Over_Quantity, current_quantity),
                                    Resources.Msb_Title_Error,
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }
                        #endregion

                    else if (!currentOrder.IsNull(Definitions.ORDER_VALVE_ID))
                    {
                        current_quantity =
                            (int)
                            _valveAdapter.GetValveQuantity(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                        if (current_quantity < Int32.Parse(txt_OrderQuantity.Text))
                        {
                            MessageBox.Show(
                                string.Format(Resources.Order_Over_Quantity, current_quantity),
                                Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                    else if (!currentOrder.IsNull(Definitions.ORDER_GAS_ID))
                    {
                        current_quantity =
                            (int)
                            _gasAdapter.GetGasQuantityById(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                        if (current_quantity < Int32.Parse(txt_OrderQuantity.Text))
                        {
                            MessageBox.Show(
                                string.Format(Resources.Order_Over_Quantity, current_quantity),
                                Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                }
                    #endregion
                    #region Combobox là Van

                else if (currentGood == Definitions.COMBOBOX_KINDOF_VALVE)
                {
                    current_quantity =
                        (int) _valveAdapter.GetValveQuantity(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));

                    if (!currentOrder.IsNull(Definitions.ORDER_VALVE_ID))
                    {
                        // chưa đổi sản phẩm
                        if (currentOrder.ode_ValveId == Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()))
                        {
                            current_quantity =
                                (int)
                                _valveAdapter.GetValveQuantity(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));

                            if (current_quantity + currentOrder.ode_Quantity < Int32.Parse(txt_OrderQuantity.Text))
                            {
                                MessageBox.Show(
                                    string.Format(Resources.Order_Over_Quantity_2, current_quantity,
                                        currentOrder.ode_Quantity), Resources.Msb_Title_Inform,
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                            // đã đổi sản phẩm
                        else
                        {
                            if (current_quantity < Int32.Parse(txt_OrderQuantity.Text))
                            {
                                MessageBox.Show(
                                    string.Format(Resources.Order_Over_Quantity, current_quantity),
                                    Resources.Msb_Title_Error,
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }
                    else if (!currentOrder.IsNull(Definitions.ORDER_SHELL_ID))
                    {
                        if (current_quantity < Int32.Parse(txt_OrderQuantity.Text))
                        {
                            MessageBox.Show(
                                string.Format(Resources.Order_Over_Quantity, current_quantity),
                                Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                    else if (!currentOrder.IsNull(Definitions.ORDER_GAS_ID))
                    {
                        var currentQuantity =
                            (int)
                            _gasAdapter.GetGasQuantityById(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                        if (currentQuantity < Int32.Parse(txt_OrderQuantity.Text))
                        {
                            MessageBox.Show(
                                string.Format(Resources.Order_Over_Quantity, currentQuantity), Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                }

                #endregion

                if (!currentOrder.IsNull(Definitions.ORDER_VALVE_ID))
                {
                    _valveAdapter.UpdateIncreaseQuantity(currentOrder.ode_Quantity, currentOrder.ode_ValveId);
                }
                else if (!currentOrder.IsNull(Definitions.ORDER_SHELL_ID))
                {
                    _shellAdapter.UpdateIncreaseQuantity(currentOrder.ode_Quantity, currentOrder.ode_ShellId);
                }
                else if (!currentOrder.IsNull(Definitions.ORDER_GAS_ID))
                {
                    _gasAdapter.UpdateIncreaseQuantity(currentOrder.ode_Quantity, currentOrder.ode_GasId);
                }


                if (currentGood == Definitions.COMBOBOX_KINDOF_GAS)
                {
                    _orderAdapter.UpdateGasOrder(
                        Int32.Parse(cbb_Customer.SelectedValue.ToString()),
                        Int32.Parse(txt_OrderQuantity.Text),
                        Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()),
                        Int32.Parse(cbb_OrderDeliverer.SelectedValue.ToString()),
                        order.ode_GasValueId,
                        txt_OrderComment.Text,
                        Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim()),
                        Int32.Parse(txt_ReturnShell.Text.Trim()),
                        Int32.Parse(txt_PaidMoney.Text.Trim()),
                        dt_OrderSellDate.Value,
                        currentOrder.ode_Id
                        );
                    _gasAdapter.UpdateIncreaseQuantity(0 - Int32.Parse(txt_OrderQuantity.Text),
                        Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                }
                else if (currentGood == Definitions.COMBOBOX_KINDOF_VALVE)
                {
                    _orderAdapter.UpdateValveOrder(
                        Int32.Parse(cbb_Customer.SelectedValue.ToString()),
                        Int32.Parse(txt_OrderQuantity.Text),
                        Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()),
                        Int32.Parse(cbb_OrderDeliverer.SelectedValue.ToString()),
                        order.ode_ValveValueId,
                        txt_OrderComment.Text,
                        Int32.Parse(txt_PaidMoney.Text.Trim()),
                        Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim()),
                        dt_OrderSellDate.Value,
                        currentOrder.ode_Id
                        );
                    _valveAdapter.UpdateIncreaseQuantity(0 - Int32.Parse(txt_OrderQuantity.Text),
                        Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                }
                else if (currentGood == Definitions.COMBOBOX_KINDOF_SHELL)
                {
                    _orderAdapter.UpdateShellOrder(
                        Int32.Parse(cbb_Customer.SelectedValue.ToString()),
                        Int32.Parse(txt_OrderQuantity.Text),
                        Int32.Parse(cbb_OrderDeliverer.SelectedValue.ToString()),
                        txt_OrderComment.Text,
                        Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()),
                        order.ode_ShellValueId,
                        Int32.Parse(txt_ReturnShell.Text.Trim()),
                        Int32.Parse(txt_PaidMoney.Text.Trim()),
                        Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim()),
                        dt_OrderSellDate.Value,
                        currentOrder.ode_Id
                        );
                    _shellAdapter.UpdateIncreaseQuantity(0 - Int32.Parse(txt_OrderQuantity.Text),
                        Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                }

                txt_OrderId.Text = (currentOrder.ode_Id + String.Empty);
                MessageBox.Show(Resources.Order_Edit_ID + currentOrder.ode_Id, Resources.Msb_Title_Inform,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                UpdateStatus(Resources.Order_Edit_ID + currentOrder.ode_Id);

                GSS.DataAccessLayer.GSS.GSS_OrderDataTable orders =
                    _orderAdapter.GetOrderById(((TreeNode_Order) editTreeView.SelectedNode).node_order.ode_Id);
                foreach (GSS.DataAccessLayer.GSS.GSS_OrderRow order_row in orders)
                {
                    ((TreeNode_Order) editTreeView.SelectedNode).node_order = order_row;
                }
            }
                #endregion
                #region insert new order

            else
            {
                try
                {
                    String currentGood = cbb_OrderKindGood.SelectedItem.ToString().Trim();


                    int importGasPrice = 0;
                    int importValvePrice = 0;
                    if (currentGood == Definitions.COMBOBOX_KINDOF_GAS)
                    {
                        var currentQuantity =
                            (int)
                            _gasAdapter.GetGasQuantityById(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                        if (currentQuantity < Int32.Parse(txt_OrderQuantity.Text))
                        {
                            MessageBox.Show(
                                string.Format(Resources.Order_Over_Quantity, currentQuantity), Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }


                        GSS.DataAccessLayer.GSS.GSS_GasDataTable gasdt =
                            _gasAdapter.GetGasImportPriceById(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                        foreach (GSS.DataAccessLayer.GSS.GSS_GasRow gasr in gasdt)
                        {
                            importGasPrice = gasr.gas_Price;
                        }

                        _orderAdapter.InsertGasOrder(
                            Int32.Parse(cbb_Customer.SelectedValue.ToString()),
                            Int32.Parse(txt_OrderQuantity.Text),
                            dt_OrderSellDate.Value,
                            Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()),
                            Int32.Parse(cbb_OrderDeliverer.SelectedValue.ToString()),
                            order.ode_GasValueId,
                            txt_OrderComment.Text,
                            Int32.Parse(txt_PaidMoney.Text.Trim()),
                            Int32.Parse(txt_ReturnShell.Text.Trim()),
                            Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim()),
                            importGasPrice,
                            _user.user_Id
                            );
                        _gasAdapter.UpdateIncreaseQuantity(0 - Int32.Parse(txt_OrderQuantity.Text),
                            Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                    }
                    else if (currentGood == Definitions.COMBOBOX_KINDOF_VALVE)
                    {
                        var currentQuantity =
                            (int)
                            _valveAdapter.GetValveQuantity(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                        if (currentQuantity < Int32.Parse(txt_OrderQuantity.Text))
                        {
                            MessageBox.Show(
                                string.Format(Resources.Order_Over_Quantity, currentQuantity), Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        GSS.DataAccessLayer.GSS.GSS_ValveDataTable valvedt =
                            _valveAdapter.GetValveImportPriceById(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));

                        foreach (GSS.DataAccessLayer.GSS.GSS_ValveRow val in valvedt)
                        {
                            importValvePrice = val.valve_Price;
                        }

                        _orderAdapter.InsertValveOrder(
                            Int32.Parse(cbb_Customer.SelectedValue.ToString()),
                            Int32.Parse(txt_OrderQuantity.Text),
                            dt_OrderSellDate.Value,
                            Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()),
                            Int32.Parse(cbb_OrderDeliverer.SelectedValue.ToString()),
                            order.ode_ValveValueId,
                            txt_OrderComment.Text,
                            Int32.Parse(txt_PaidMoney.Text.Trim()),
                            Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim()),
                            importValvePrice,
                            _user.user_Id
                            );
                        _valveAdapter.UpdateIncreaseQuantity(0 - Int32.Parse(txt_OrderQuantity.Text),
                            Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                    }
                    else if (currentGood == Definitions.COMBOBOX_KINDOF_SHELL)
                    {
                        var currentQuantity =
                            (int)
                            _shellAdapter.GetShellQuantity(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                        if (currentQuantity < Int32.Parse(txt_OrderQuantity.Text))
                        {
                            MessageBox.Show(
                                string.Format(Resources.Order_Over_Quantity, currentQuantity), Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        int importShellPrice = 0;

                        GSS.DataAccessLayer.GSS.GSS_ShellDataTable shelldt =
                            _shellAdapter.GetImportPriceById(Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));

                        foreach (GSS.DataAccessLayer.GSS.GSS_ShellRow she in shelldt)
                        {
                            importShellPrice = she.shell_Price;
                        }

                        _orderAdapter.InsertShellOrder(
                            Int32.Parse(cbb_Customer.SelectedValue.ToString()),
                            Int32.Parse(txt_OrderQuantity.Text),
                            dt_OrderSellDate.Value,
                            Int32.Parse(cbb_OrderDeliverer.SelectedValue.ToString()),
                            txt_OrderComment.Text,
                            Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()),
                            order.ode_ShellValueId,
                            Int32.Parse(txt_ReturnShell.Text.Trim()),
                            Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim()),
                            Int32.Parse(txt_PaidMoney.Text.Trim()),
                            importShellPrice,
                            _user.user_Id
                            );
                        _shellAdapter.UpdateIncreaseQuantity(0 - Int32.Parse(txt_OrderQuantity.Text),
                            Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString()));
                    }

                    int lastId = Int32.Parse(_orderAdapter.GetLastOrderId().ToString());


                    GSS.DataAccessLayer.GSS.GSS_OrderDataTable orders = _orderAdapter.GetOrderById(lastId);

                    foreach (GSS.DataAccessLayer.GSS.GSS_OrderRow orderInfo in orders)
                    {
                        order.node_order = orderInfo;
                    }

                    txt_OrderId.Text = (order.node_order.ode_Id + String.Empty);
                    MessageBox.Show(Resources.Order_Add_ID + order.node_order.ode_Id, Resources.Msb_Title_Inform,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    UpdateStatus(Resources.Order_Add_ID + order.node_order.ode_Id);
                }
                catch (Exception ext)
                {
                    lbl_ActionStatus.Text = ext.Message;
                    return;
                }
            }

            #endregion

            LoadOrder();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_EditExistingOrder control.
        /// </summary>
        private void btn_EditExistingOrder_Click(object sender, EventArgs e)
        {
            for (int count = 0; count < editTreeView.Nodes[NODE_ORDER].Nodes.Count; count++)
            {
                if (((TreeNode_Order) editTreeView.Nodes[NODE_ORDER].Nodes[count]).node_order != null &&
                    ((TreeNode_Order) editTreeView.Nodes[NODE_ORDER].Nodes[count]).node_order.ode_Id ==
                    ((DataGridViewRow_Order) dtg_Order.SelectedRows[0]).row_order.ode_Id)
                {
                    editTreeView.Nodes[NODE_ORDER].Expand();
                    editTreeView.SelectedNode = editTreeView.Nodes[NODE_ORDER].Nodes[count];
                    editTreeView.Focus();
                    return;
                }
            }

            GSS.DataAccessLayer.GSS.GSS_OrderRow orderRow =
                ((DataGridViewRow_Order) dtg_Order.SelectedRows[0]).row_order;

            var newOrder =
                new TreeNode_Order(
                    (dtg_Order.SelectedRows[0]).Cells[Definitions.COLUMN_NAME_ORDER_CUSNAME].Value.ToString())
                    {node_order = orderRow};

            newOrder.LoadNode();

            editTreeView.Nodes[NODE_ORDER].Nodes.Add(newOrder);

            editTreeView.Nodes[NODE_ORDER].Expand();
            editTreeView.SelectedNode = newOrder;
            editTreeView.Focus();
        }

        /// <summary>
        ///   Handles the Click event of the smi_deliverer control.
        /// </summary>
        private void smi_deliverer_Click(object sender, EventArgs e)
        {
            var formDeliver = new Form_Deliverer(this);
            formDeliver.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the danhSáchNhàCungCấp ToolStrip Menu Item control.
        /// </summary>
        private void danhSáchNhàCungCấpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var formSupplier = new Form_Supplier();
            formSupplier.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the tạoBảnSaoDữLiệu ToolStrip Menu Item control.
        /// </summary>
        private void tạoBảnSaoDữLiệuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sfd_ChooseBackupDBLocation.Filter = Definitions.BACKUP_FILTER;
            sfd_ChooseBackupDBLocation.Title = Resources.Backup;
            if (sfd_ChooseBackupDBLocation.ShowDialog() == DialogResult.OK)
            {
                String backUpPath = sfd_ChooseBackupDBLocation.FileName;

                if (backUpPath.Trim().Length > 0)
                {
                    var cnn = new SqlConnection(Resources.ConnectionString);
                    String databaseName = cnn.Database;

                    var sqlBackup = new Backup();

                    sqlBackup.Action = BackupActionType.Database;
                    sqlBackup.BackupSetDescription = "ArchiveDataBase:" +
                                                     DateTime.Now.ToShortDateString();
                    sqlBackup.BackupSetName = "Archive";

                    sqlBackup.Database = databaseName;

                    var deviceItem = new BackupDeviceItem(backUpPath, DeviceType.File);
                    var connection = new ServerConnection(cnn);
                    var sqlServer = new Server(connection);

         //           Database db = sqlServer.Databases[databaseName];

                    sqlBackup.Initialize = true;
                    sqlBackup.Checksum = true;
                    sqlBackup.ContinueAfterError = true;

                    sqlBackup.Devices.Add(deviceItem);
                    sqlBackup.Incremental = false;

                    sqlBackup.ExpirationDate = DateTime.Now.AddYears(100);
                    sqlBackup.LogTruncation = BackupTruncateLogType.Truncate;

                    sqlBackup.FormatMedia = false;


                    try
                    {
                        sqlBackup.SqlBackup(sqlServer);
                    }
                    catch (Exception)
                    {
                        MessageBox.Show(Resources.Msb_Backup_Fail, Resources.Msb_Title_Inform, MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                        return;
                    }


                    MessageBox.Show(Resources.Msb_Backup_Success, Resources.Msb_Title_Inform, MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
        }

        /// <summary>
        ///   Handles the SearchOrder event of the timer tmr_Tick control.
        /// </summary>
        private void tmr_Tick_SearchOrder(object sender, EventArgs e)
        {
            tmr_SearchOrder.Enabled = false;
            LoadOrder();
        }

        /// <summary>
        ///   Handles the SearchCustomer event of the tik_SearchCustomer control.
        /// </summary>
        private void tịk_SearchCustomer(object sender, EventArgs e)
        {
            tmr_SearchCustomer.Enabled = false;
            LoadCustomers();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_HomephoneDiary control.
        /// </summary>
        private void btn_HomephoneDiary_Click(object sender, EventArgs e)
        {
            if (txt_HomePhoneCustomer.Text.Trim().Length == 0)
                return;
            var formCallDiary = new Form_CallDiary_User(this,txt_HomePhoneCustomer.Text);
            formCallDiary.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_MobileDiary control.
        /// </summary>
        private void btn_MobileDiary_Click(object sender, EventArgs e)
        {
            if (txt_MobileCutomer.Text.Trim().Length == 0)
                return;
            var formCallDiary = new Form_CallDiary_User(this, txt_MobileCutomer.Text);
            formCallDiary.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the phụcHồiTừBảnSao ToolStrip Menu Item control.
        /// </summary>
        private void phụcHồiTừBảnSaoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ofd_ChooseBackupDB.Filter = Definitions.BACKUP_FILTER;
            ofd_ChooseBackupDB.Title = Resources.Restore;
            if (ofd_ChooseBackupDB.ShowDialog() == DialogResult.OK)
            {
                String backupFile = ofd_ChooseBackupDB.FileName;

                if (backupFile.Trim().Length > 0)
                    using (var con = new SqlConnection(Resources.ConnectionString))
                    {
                        con.Open();

                        string UseMaster = "USE master";
                        var UseMasterCommand = new SqlCommand(UseMaster, con);
                        UseMasterCommand.ExecuteNonQuery();

                        string Alter1 = @"ALTER DATABASE [GSS] SET Single_User WITH Rollback Immediate";
                        var Alter1Cmd = new SqlCommand(Alter1, con);
                        Alter1Cmd.ExecuteNonQuery();

                        string Restore = @"RESTORE DATABASE [GSS] FROM DISK = N'" + backupFile +
                                         @"' WITH  FILE = 1,  NOUNLOAD,  STATS = 10";
                        var RestoreCmd = new SqlCommand(Restore, con);
                        RestoreCmd.ExecuteNonQuery();

                        string Alter2 = @"ALTER DATABASE [GSS] SET Multi_User";
                        var Alter2Cmd = new SqlCommand(Alter2, con);
                        Alter2Cmd.ExecuteNonQuery();

                        lbl_ActionStatus.Text = Resources.Finish;
                        MessageBox.Show(Resources.Msb_Restart_Require);
                        Close();
                    }
            }
        }

        /// <summary>
        ///   Handles the TextChanged event of the textbox txt_ReturnShell control.
        /// </summary>
        private void textbox1_TextChanged(object sender, EventArgs e)
        {
            for (int count = 0; count < txt_ReturnShell.Text.Length; count++)
            {
                if ((txt_ReturnShell.Text[count]) != '0'
                    && (txt_ReturnShell.Text[count]) != '1'
                    && (txt_ReturnShell.Text[count]) != '2'
                    && (txt_ReturnShell.Text[count]) != '3'
                    && (txt_ReturnShell.Text[count]) != '4'
                    && (txt_ReturnShell.Text[count]) != '5'
                    && (txt_ReturnShell.Text[count]) != '6'
                    && (txt_ReturnShell.Text[count]) != '7'
                    && (txt_ReturnShell.Text[count]) != '8'
                    && (txt_ReturnShell.Text[count]) != '9'
                    )
                {
                    txt_ReturnShell.Text = txt_ReturnShell.Text.Remove(count, 1);
                    count--;
                }
            }

            if (txt_ReturnShell.Text.Trim().Length == 0 || Int32.Parse(txt_ReturnShell.Text.Trim()) == 0)
            {
                txt_ReturnShell.Text = "0";
                return;
            }

            if (txt_ReturnShell.Text.Trim().Length > 0)
                txt_ReturnShell.Text = Int32.Parse(txt_ReturnShell.Text) + "";

            lbl_BorrowShell.Text = string.Format(Resources.Borrow_Shell_One_Arg,
                (Int32.Parse(txt_OrderQuantity.Text.Trim()) -
                 Int32.Parse(txt_ReturnShell.Text.Trim())));
            txt_ReturnShell.SelectionStart = txt_ReturnShell.Text.Length;
            txt_ReturnShell.ScrollToCaret();
        }

        /// <summary>
        ///   Handles the TextChanged event of the textbox txt_PaidMoney control.
        /// </summary>
        private void textbox2_TextChanged(object sender, EventArgs e)
        {
            for (int count = 0; count < txt_PaidMoney.Text.Length; count++)
            {
                if ((txt_PaidMoney.Text[count]) != '0'
                    && (txt_PaidMoney.Text[count]) != '1'
                    && (txt_PaidMoney.Text[count]) != '2'
                    && (txt_PaidMoney.Text[count]) != '3'
                    && (txt_PaidMoney.Text[count]) != '4'
                    && (txt_PaidMoney.Text[count]) != '5'
                    && (txt_PaidMoney.Text[count]) != '6'
                    && (txt_PaidMoney.Text[count]) != '7'
                    && (txt_PaidMoney.Text[count]) != '8'
                    && (txt_PaidMoney.Text[count]) != '9'
                    )
                {
                    txt_PaidMoney.Text = txt_PaidMoney.Text.Remove(count, 1);
                    count--;
                }
            }
            if (txt_PaidMoney.Text.Trim().Length == 0 || Int32.Parse(txt_PaidMoney.Text.Trim()) == 0)
            {
                txt_PaidMoney.Text = "0";
                lbl_BorrowMoney.Text = string.Format(Resources.Borrow_Money_One_Arg,
                    Int32.Parse(txt_OrderPrice.Text.Trim()));
                return;
            }
            if (txt_PaidMoney.Text.Trim().Length > 0)
                txt_PaidMoney.Text = Int32.Parse(txt_PaidMoney.Text) + "";

            lbl_BorrowMoney.Text = string.Format(Resources.Borrow_Money_One_Arg,
                (Int32.Parse(txt_OrderPrice.Text.Trim()) - Int32.Parse(txt_PaidMoney.Text.Trim())));
            txt_PaidMoney.SelectionStart = txt_PaidMoney.Text.Length;
            txt_PaidMoney.ScrollToCaret();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_OrderClose control.
        /// </summary>
        private void btn_OrderClose_Click(object sender, EventArgs e)
        {
            // giao dịch mới
            if (((TreeNode_Order) editTreeView.SelectedNode).node_order == null
                &&
                (txt_OrderComment.Text.Trim().Length == 0
                 || txt_OrderQuantity.Text.Trim() != "0"
                 || txt_ReturnShell.Text.Trim() != "0"
                 || txt_PaidMoney.Text.Trim() != "0"
                ))
            {
                DialogResult ret = MessageBox.Show(Resources.Order_Save_Require,
                    Resources.Msb_Title_Inform, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (ret == DialogResult.Yes)
                {
                    editTreeView.Nodes[NODE_ORDER].Nodes.Remove(editTreeView.SelectedNode);
                    editTreeView.SelectedNode = editTreeView.Nodes[NODE_ORDER];
                    editTreeView.Focus();
                    return;
                }
                return;
            }
            // sửa giao dịch
            if (((TreeNode_Order) editTreeView.SelectedNode).node_order != null
                &&
                (
                    (txt_OrderComment.Text.Trim() !=
                     ((TreeNode_Order) editTreeView.SelectedNode).node_order.ode_Comment)
                    ||
                    (cbb_Customer.SelectedValue.ToString() !=
                     ((TreeNode_Order) editTreeView.SelectedNode).node_order.ode_CustomerId.ToString())
                    ||
                    (dt_OrderSellDate.Value != ((TreeNode_Order) editTreeView.SelectedNode).node_order.ode_Date)
                    ||
                    (Int32.Parse(txt_OrderQuantity.Text.Trim()) !=
                     (((TreeNode_Order) editTreeView.SelectedNode).node_order.ode_Quantity))
                    ||
                    (Int32.Parse(txt_OrderPrice.Text.Trim()) !=
                     (((TreeNode_Order) editTreeView.SelectedNode).node_order.ode_PaidMoney +
                      ((TreeNode_Order) editTreeView.SelectedNode).node_order.ode_BorrowMoney))
                    ||
                    (Int32.Parse(txt_PaidMoney.Text.Trim()) !=
                     (((TreeNode_Order) editTreeView.SelectedNode).node_order.ode_PaidMoney)))
                )
            {
                DialogResult ret = MessageBox.Show(Resources.Order_Save_Require,
                    Resources.Msb_Title_Inform, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (ret == DialogResult.Yes)
                {
                    editTreeView.Nodes[NODE_ORDER].Nodes.Remove(editTreeView.SelectedNode);
                    editTreeView.SelectedNode = editTreeView.Nodes[NODE_ORDER];
                    editTreeView.Focus();
                    return;
                }
                return;
            }

            editTreeView.Nodes[NODE_ORDER].Nodes.Remove(editTreeView.SelectedNode);
            editTreeView.SelectedNode = editTreeView.Nodes[NODE_ORDER];
            editTreeView.Focus();
        }

        /// <summary>
        ///   Handles the Click event of the danhSáchKháchNợVỏ ToolStrip Menu Item control.
        /// </summary>
        private void danhSáchKháchNợVỏToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var reportBorrowShell = new Report_BorrowShell();
            reportBorrowShell.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the danhSáchKháchNợTiền ToolStrip Menu Item control.
        /// </summary>
        private void danhSáchKháchNợTiềnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var reportBorrowMoney = new Report_BorrowMoney();
            reportBorrowMoney.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the kiểmHàng ToolStrip Menu Item control.
        /// </summary>
        private void kiểmHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var checkProducts = new Check_Products();
            checkProducts.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the doanhThuBánHàng ToolStrip Menu Item control.
        /// </summary>
        private void doanhThuBánHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var reportSell = new Report_Sell();
            reportSell.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the thốngKêBánHàngNhânViên ToolStrip Menu Item control.
        /// </summary>
        private void thốngKêBánHàngNhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var reportSellEmployee = new Report_SellEmployee();
            reportSellEmployee.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the xuấtHàngĐểTiêuDùng ToolStrip Menu Item control.
        /// </summary>
        private void xuấtHàngĐểTiêuDùngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var exportToUse = new ExportToUse();
            exportToUse.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the nhậpHàngTừSảnXuất ToolStrip Menu Item control.
        /// </summary>
        private void nhậpHàngTừSảnXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var importProduct = new ImportProduct();
            importProduct.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the sửXóaMãBìnhVàMãVỏ ToolStrip Menu Item control.
        /// </summary>
        private void sửXóaMãBìnhVàMãVỏToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var editProductWithShell = new EditProduct_WithShell();
            editProductWithShell.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the sửaXóaMãHàngThôngThường ToolStrip Menu Item control.
        /// </summary>
        private void sửaXóaMãHàngThôngThườngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var editProductNormal = new EditProduct_Normal();
            editProductNormal.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the càiĐặtMẫuHóaĐơn ToolStrip Menu Item control.
        /// </summary>
        private void càiĐặtMẫuHóaĐơnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var formBill = new Form_Bill();
            formBill.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the quảnLýTàiKhoản ToolStrip Menu Item control.
        /// </summary>
        private void quảnLýTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var formManagerAccount = new Form_ManagerAccount();
            formManagerAccount.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_addorder control.
        /// </summary>
        private void btn_addorder_Click(object sender, EventArgs e)
        {
            GSS.DataAccessLayer.GSS.GSS_CustomerRow customerRow =
                ((DataGridViewRow_Customer) dtg_Customer.SelectedRows[0]).row_customer;

            var newOrder = new TreeNode_Order(Resources.New_Order);
            editTreeView.Nodes[NODE_ORDER].Nodes.Add(newOrder);
            editTreeView.Nodes[NODE_ORDER].Expand();
            editTreeView.SelectedNode = newOrder;
            editTreeView.Focus();
            cbb_Customer.SelectedValue = customerRow.cus_Id;
            try
            {
                cbb_OrderGoodCode.SelectedIndex = 1;
                cbb_OrderGoodCode.SelectedIndex = 0;
            }
            catch
            {
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_OrderPrint control.
        /// </summary>
        private void btn_OrderPrint_Click(object sender, EventArgs e)
        {
            object objMissing = Missing.Value;

            var objWord = new Microsoft.Office.Interop.Word.Application {Visible = true};

            Document objDoc = objWord.Documents.Add(ref objMissing, ref objMissing, ref objMissing, ref objMissing);

            object oEndOfDoc = "\\endofdoc"; /* \endofdoc is a predefined bookmark */

            //CÔNG TY TNHH GAS THẰNG LONG
            InsertWord(objDoc, "Microsoft Sans Serif", Settings.Default.NAME_STORE,
                WdParagraphAlignment.wdAlignParagraphCenter, 16, 0, 6, 0);


            //Số 123 đường Phạm Hùng
            InsertWord(objDoc, "Microsoft Sans Serif", Settings.Default.ADDRESS_STORE,
                WdParagraphAlignment.wdAlignParagraphCenter, 9, 0, 1, 0);
            //SĐT: 043.2345678
            InsertWord(objDoc, "Microsoft Sans Serif", Settings.Default.PHONES_STORE,
                WdParagraphAlignment.wdAlignParagraphCenter, 9, 0, 1, 0);

            //Website: http://www.thanglonggas.com
            InsertWord(objDoc, "Microsoft Sans Serif", Settings.Default.WEBSITE_STORE,
                WdParagraphAlignment.wdAlignParagraphCenter, 9, 0, 30, 0);

            //HÓA ĐƠN BÁN HÀNG
            InsertWord(objDoc, "Calibri (Body)", "HÓA ĐƠN BÁN HÀNG", WdParagraphAlignment.wdAlignParagraphCenter, 13, 1,
                0, 0);

            //(Giao cho khách hàng)
            InsertWord(objDoc, "Calibri (Body)", "(Giao cho khách hàng)", WdParagraphAlignment.wdAlignParagraphCenter,
                11, 0, 6, 0);


            object oNull = Missing.Value;
            Table tblCustomer = objDoc.Tables.Add(objDoc.Bookmarks.get_Item(ref oEndOfDoc).Range, 5, 2, ref oNull,
                ref oNull);
            tblCustomer.Range.Font.Name = "Calibri (Body)";
            tblCustomer.Range.Font.Size = 10;
            tblCustomer.AllowAutoFit = true;


            tblCustomer.Columns[1].Cells[1].Range.Text = "Mã KH";
            tblCustomer.Columns[1].Cells[2].Range.Text = "Tên";
            tblCustomer.Columns[1].Cells[3].Range.Text = "SĐT";
            tblCustomer.Columns[1].Cells[4].Range.Text = "Địa Chỉ";
            tblCustomer.Columns[1].Cells[5].Range.Text = "Ngày bán";
            tblCustomer.Columns[1].AutoFit();

            tblCustomer.Columns[2].Cells[1].Range.Text = cbb_Customer.SelectedValue.ToString();
            tblCustomer.Columns[2].Cells[2].Range.Text = txt_OrderCustomerName.Text;
            tblCustomer.Columns[2].Cells[3].Range.Text = txt_OrderCustomerMobile.Text + "  " +
                                                         txt_OrderCustomerHomePhone.Text;
            tblCustomer.Columns[2].Cells[4].Range.Text = txt_OrderCustomerAddess.Text + " - quận/huyện " +
                                                         txt_OrderCustomerDistrict.Text + " - tỉnh/thành phố " +
                                                         txt_OrderCustomerCity.Text;
            tblCustomer.Columns[2].Cells[5].Range.Text = dt_OrderSellDate.Value.ToString();

            tblCustomer.Columns[2].Cells[1].Range.Font.Size = 10;
            tblCustomer.Columns[2].Cells[2].Range.Font.Size = 10;
            tblCustomer.Columns[2].Cells[3].Range.Font.Size = 10;
            tblCustomer.Columns[2].Cells[4].Range.Font.Size = 10;
            tblCustomer.Columns[2].Cells[5].Range.Font.Size = 10;

            tblCustomer.Columns[2].Cells[1].Range.Font.Bold = 1;
            tblCustomer.Columns[2].Cells[2].Range.Font.Bold = 1;
            tblCustomer.Columns[2].Cells[3].Range.Font.Bold = 1;
            tblCustomer.Columns[2].Cells[4].Range.Font.Bold = 1;
            tblCustomer.Columns[2].Cells[5].Range.Font.Bold = 1;


            tblCustomer.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
            tblCustomer.Range.ParagraphFormat.SpaceAfter = 0;
            tblCustomer.Range.ParagraphFormat.SpaceBefore = 0;
            tblCustomer.Range.InsertParagraphAfter();


            InsertWord(objDoc, "Calibri (Body)", "   ", WdParagraphAlignment.wdAlignParagraphCenter, 11, 0, 6, 0);


            Table tbl = objDoc.Tables.Add(objDoc.Bookmarks.get_Item(ref oEndOfDoc).Range, 3, 4, ref oNull, ref oNull);
            tbl.Range.Font.Name = "Calibri (Body)";
            tbl.Range.Font.Size = 10;


            for (int count = 1; count < tbl.Rows.Count + 1; count++)
            {
                for (int count2 = 1; count2 < tbl.Columns.Count + 1; count2++)
                {
                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderRight].LineStyle =
                        WdLineStyle.wdLineStyleSingle;
                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderRight].LineStyle =
                        WdLineStyle.wdLineStyleSingle;
                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderRight].LineWidth =
                        WdLineWidth.wdLineWidth050pt;
                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderRight].Color = WdColor.wdColorBlack;

                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderLeft].LineStyle =
                        WdLineStyle.wdLineStyleSingle;
                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderLeft].LineWidth =
                        WdLineWidth.wdLineWidth050pt;
                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderLeft].Color = WdColor.wdColorBlack;

                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderTop].LineStyle =
                        WdLineStyle.wdLineStyleSingle;
                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderTop].LineWidth =
                        WdLineWidth.wdLineWidth050pt;
                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderTop].Color = WdColor.wdColorBlack;

                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderBottom].LineStyle =
                        WdLineStyle.wdLineStyleSingle;
                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderBottom].LineWidth =
                        WdLineWidth.wdLineWidth050pt;
                    tbl.Rows[count].Cells[count2].Range.Borders[WdBorderType.wdBorderBottom].Color =
                        WdColor.wdColorBlack;
                }
            }

            tbl.Rows[1].Cells[1].Range.Text = "STT";
            tbl.Rows[1].Cells[2].Range.Text = "Tên hàng";
            tbl.Rows[1].Cells[3].Range.Text = "Số lượng";
            tbl.Rows[1].Cells[4].Range.Text = "Thành tiền";
            tbl.Rows[1].Range.Font.Size = 8;
            tbl.Rows[1].Range.Font.Bold = 1;

            tbl.Rows[2].Cells[1].Range.Text = "1";

            var productDt = (DataTable) cbb_OrderGoodCode.DataSource;

            tbl.Rows[2].Cells[2].Range.Text = productDt.Rows[cbb_OrderGoodCode.SelectedIndex][0].ToString();
            tbl.Rows[2].Cells[3].Range.Text = txt_OrderQuantity.Text;
            tbl.Rows[2].Cells[4].Range.Text = txt_OrderPrice.Text + ".000 đồng";

            tbl.Range.ParagraphFormat.SpaceAfter = 3;
            tbl.Range.ParagraphFormat.SpaceBefore = 3;


            InsertWord(objDoc, "Calibri (Body)", "Giá tiền: " + txt_OrderPrice.Text + ".000 đồng",
                WdParagraphAlignment.wdAlignParagraphLeft, 12, 0, 2, 30);

            InsertWord(objDoc, "Calibri (Body)", "Khách trả: " + txt_PaidMoney.Text + ".000 đồng",
                WdParagraphAlignment.wdAlignParagraphLeft, 12, 0, 20, 0);

            InsertWord(objDoc, "Calibri (Body)", "Ghi chú: ", WdParagraphAlignment.wdAlignParagraphLeft, 12, 0, 0, 0);

            InsertWord(objDoc, "Calibri (Body)", txt_OrderComment.Text, WdParagraphAlignment.wdAlignParagraphLeft, 12, 1,
                20, 0);

            InsertWord(objDoc, "Calibri (Body)",
                "Khách hàng ký                                                   Giao hàng ký",
                WdParagraphAlignment.wdAlignParagraphCenter, 12, 0, 0, 0);

            if (
                File.Exists(string.Format(Resources.Map_Path_Two_Argument,
                    Path.GetDirectoryName(Application.ExecutablePath), cbb_Customer.SelectedValue)))
                objDoc.Bookmarks.get_Item(oEndOfDoc).Range.InlineShapes.AddPicture(
                    string.Format(Resources.Map_Path_Two_Argument, Path.GetDirectoryName(Application.ExecutablePath),
                        cbb_Customer.SelectedValue),
                    ref objMissing, ref objMissing, ref objMissing);
            ;

            object fileName = Path.GetDirectoryName(Application.ExecutablePath) + "/bill.docx";
            if (File.Exists((String) fileName))
            {
                try
                {
                    File.Delete((String) fileName);
                }
                catch (Exception)
                {
                    MessageBox.Show(Resources.Word_Close_Require, Resources.Msb_Title_Bill_Export_Error,
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            objWord.ActiveDocument.SaveAs(ref fileName, ref objMissing,
                ref objMissing, ref objMissing, ref objMissing,
                ref objMissing, ref objMissing, ref objMissing,
                ref objMissing, ref objMissing, ref objMissing,
                ref objMissing, ref objMissing, ref objMissing,
                ref objMissing, ref objMissing);

            if (prd_Order.ShowDialog() == DialogResult.OK)
            {
                var info = new ProcessStartInfo((string) fileName)
                               {
                                   Arguments = "\"" + prd_Order.PrinterSettings.PrinterName + "\"",
                                   CreateNoWindow = true,
                                   WindowStyle = ProcessWindowStyle.Hidden,
                                   UseShellExecute = true,
                                   Verb = "PrintTo"
                               };
                Process.Start(info);
            }
        }

        /// <summary>
        ///   Handles the DoubleClick event of the label lbl_modemStatus control.
        /// </summary>
        private void lbl_modemStatus_DoubleClick(object sender, EventArgs e)
        {
            CheckModem();
        }

        /// <summary>
        ///   Handles the Click event of the kiểmTraModem ToolStrip Menu Item control.
        /// </summary>
        private void kiểmTraModemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (CheckModem())
            {
                MessageBox.Show(this, Resources.Modem_Connected, Resources.Msb_Title_Inform, MessageBoxButtons.OK,
                    MessageBoxIcon.Asterisk);
            }
            else
            {
                MessageBox.Show(this, Resources.Error_Modem_Connect, Resources.Error_Connect, MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        /// <summary>
        ///   Handles the Tick event of the timer tmr_CheckModem control.
        /// </summary>
        private void tmr_CheckModem_Tick(object sender, EventArgs e)
        {
            CheckModem();
        }

        /// <summary>
        ///   Handles the Click event of the gọiĐiện ToolStrip Menu Item control.
        /// </summary>
        private void gọiĐiệnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ObjFormCall == null)
            {
                if (CheckModem())
                {
                    ObjFormCall = new Form_Call(this, "");
                    ShowForm(ObjFormCall);
                }

                else
                {
                    MessageBox.Show(this, Resources.Error_Modem_Connect, Resources.Error_Connect, MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        ///   Handles the Click event of the gửiTinNhắn ToolStrip Menu Item control.
        /// </summary>
        private void gửiTinNhắnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ObjSendMessage == null)
            {
                if (CheckModem())
                {
                    ObjSendMessage = new Form_SendMessage(this, "");
                    ShowForm(ObjSendMessage);
                }
                else
                {
                    MessageBox.Show(this, Resources.Error_Modem_Connect, Resources.Error_Connect, MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        ///   Handles the Click event of the đăngXuất ToolStrip Menu Item control.
        /// </summary>
        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _parentLogin.Show();
            _parentLogin.Visible = true;
            _parentLogin.Opacity = 100;
            Close();
        }

        /// <summary>
        ///   Handles the Click event of the thoát ToolStrip Menu Item control.
        /// </summary>
        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // stt: 1: answer
        // stt: 2: miss call
        // stt: 3: call
        /// <summary>
        ///   Inserts the missing call.
        /// </summary>
        /// <param name = "number">The number.</param>
        public void InsertMissingCall(String number)
        {
            if (_callAdapter == null)
            {
                _callAdapter = new GSS_CallTableAdapter();
            }
            _callAdapter.InsertCall(number, _user.user_Id, CALL_STATUS_MISSING);
        }

        /// <summary>
        ///   Inserts the answer call.
        /// </summary>
        /// <param name = "number">The number.</param>
        public void InsertAnswerCall(String number)
        {
            if (_callAdapter == null)
            {
                _callAdapter = new GSS_CallTableAdapter();
            }
            _callAdapter.InsertCall(number, _user.user_Id, CALL_STATUS_ANSWER);
        }

        /// <summary>
        ///   Inserts the call.
        /// </summary>
        /// <param name = "number">The number.</param>
        public void InsertCall(String number)
        {
            if (_callAdapter == null)
            {
                _callAdapter = new GSS_CallTableAdapter();
            }
            _callAdapter.InsertCall(number, _user.user_Id, CALL_STATUS_CALL);
        }

        /// <summary>
        ///   Handles the Load event of the MainForm.
        /// </summary>
        private void MainForm_Load(object sender, EventArgs e)
        {
            Rectangle rect = Screen.GetWorkingArea(this);
            Left = 0;
            Top = 0;
            Size = rect.Size;
            MinimumSize = Size;
            MaximumSize = Size;
        }

        /// <summary>
        ///   Handles the Tick event of the timer tmr_UpdateStatus control.
        /// </summary>
        private void tmr_UpdateStatus_Tick(object sender, EventArgs e)
        {
            lbl_ActionStatus.Text = "";
            tmr_UpdateStatus.Stop();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_Hangup control.
        /// </summary>
        private void btn_Hangup_Click(object sender, EventArgs e)
        {
            _modem.HangUpCall();
            Invoke((MethodInvoker) (() => PnlVisible(false)));
        }

        /// <summary>
        ///   Handles the Tick event of the timer tmr_Call control.
        /// </summary>
        private void tmr_Call_Tick(object sender, EventArgs e)
        {
            TimeSpan span = DateTime.Now.Subtract(_da);

            lbl_Timer.Text = string.Format(Resources.Time_Counter_Format, span.Hours, span.Minutes, span.Seconds);
        }

        #region Toolbar click event

        /// <summary>
        ///   Handles the Click event of the button btn_map control.
        /// </summary>
        private void btn_map_Click(object sender, EventArgs e)
        {
            if (txt_IdCustomer.Text.Trim().Length == 0)
            {
                MessageBox.Show(Resources.Map_Save_Customer_Require, Resources.Msb_Title_Error, MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            if (!File.Exists(Path.GetDirectoryName(Application.ExecutablePath) + Resources.Map_Index))
            {
                MessageBox.Show(
                    Resources.Msb_File_Not_Found + Path.GetDirectoryName(Application.ExecutablePath) +
                    Resources.Map_Index, Resources.Msb_Title_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (ptb_map.Image != null)
                    ptb_map.Image.Dispose();

                var formMap = new FormMap(Int32.Parse(txt_IdCustomer.Text.Trim()),
                    txt_AddressCustomer.Text + " " + txt_DistrictCustomer.Text + " " + txt_CityCustomer.Text);
                formMap.ShowDialog();

                if (
                    File.Exists(string.Format(Resources.Map_Path_Two_Argument,
                        Path.GetDirectoryName(Application.ExecutablePath), txt_IdCustomer.Text.Trim())))
                {
                    ptb_map.Image =
                        new Bitmap(string.Format(Resources.Map_Path_Two_Argument,
                            Path.GetDirectoryName(Application.ExecutablePath), txt_IdCustomer.Text.Trim()));
                }
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_diary control.
        /// </summary>
        private void btn_diary_Click(object sender, EventArgs e)
        {
            var formCallDiary = new Form_CallDiary();
            formCallDiary.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_duecustomer control.
        /// </summary>
        private void btn_duecustomer_Click(object sender, EventArgs e)
        {
            var formGoodCustomer = new Form_GoodCustomer();
            formGoodCustomer.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_chart control.
        /// </summary>
        private void btn_chart_Click(object sender, EventArgs e)
        {
            var formChart = new Form_Chart(this);
            formChart.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_salary control.
        /// </summary>
        private void btn_salary_Click(object sender, EventArgs e)
        {
            var reportSell = new Report_Sell();
            reportSell.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_exportexcel control.
        /// </summary>
        private void btn_exportexcel_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tpn_customer)
            {
                var excellApp = new CreateExcelDoc();

                excellApp.CreateHeaders(2, 2, "Mã", "B2", "B2", 1, "WHITE", true, 15, "n");
                excellApp.CreateHeaders(2, 3, "Tên", "C2", "C2", 1, "WHITE", true, 15, "n");
                excellApp.CreateHeaders(2, 4, "Địa chỉ", "F2", "F2", 1, "WHITE", true, 15, "n");
                excellApp.CreateHeaders(2, 5, "Quận/Huyện", "E2", "E2", 1, "WHITE", true, 15, "n");
                excellApp.CreateHeaders(2, 6, "Thành phố", "D2", "D2", 1, "WHITE", true, 15, "n");
                excellApp.CreateHeaders(2, 7, "Máy bàn", "G2", "G2", 1, "WHITE", true, 15, "n");
                excellApp.CreateHeaders(2, 8, "Di động", "H2", "H2", 1, "WHITE", true, 15, "n");

                int currRow = 3;

                foreach (DataGridViewRow customer in dtg_Customer.Rows)
                {
                    excellApp.AddData(currRow, 2, customer.Cells[Definitions.COLUMN_NAME_CUSTOMER_ID].Value.ToString(),
                        "B2", "B2", "#,##0");
                    excellApp.AddData(currRow, 3,
                        customer.Cells[Definitions.COLUMN_NAME_CUSTOMER_NAME].Value.ToString(), "C2", "C2", "#,##0");
                    excellApp.AddData(currRow, 4,
                        customer.Cells[Definitions.COLUMN_NAME_CUSTOMER_ADDRESS].Value.ToString(), "D2", "D2", "#,##0");
                    excellApp.AddData(currRow, 5,
                        customer.Cells[Definitions.COLUMN_NAME_CUSTOMER_DISTRICT].Value.ToString(), "E2", "E2", "#,##0");
                    excellApp.AddData(currRow, 6,
                        customer.Cells[Definitions.COLUMN_NAME_CUSTOMER_CITY].Value.ToString(), "F2", "F2", "#,##0");
                    excellApp.AddData(currRow, 7,
                        customer.Cells[Definitions.COLUMN_NAME_CUSTOMER_HOMEPHONE].Value.ToString(), "G2", "G2", "#,##0");
                    excellApp.AddData(currRow, 8,
                        customer.Cells[Definitions.COLUMN_NAME_CUSTOMER_MOBILE].Value.ToString(), "H2", "H2", "#,##0");
                    currRow++;
                }
            }
            else
            {
                var excell_app = new CreateExcelDoc();

                excell_app.CreateHeaders(2, 2, "Mã", "B2", "B2", 1, "WHITE", true, 15, "n");
                excell_app.CreateHeaders(2, 3, "Họ Tên", "C2", "C2", 1, "WHITE", true, 15, "n");
                excell_app.CreateHeaders(2, 4, "Điện thoại", "D2", "D2", 1, "WHITE", true, 15, "n");
                excell_app.CreateHeaders(2, 5, "Địa chỉ", "E2", "E2", 1, "WHITE", true, 15, "n");
                excell_app.CreateHeaders(2, 6, "Loại", "F2", "F2", 1, "WHITE", true, 15, "n");
                excell_app.CreateHeaders(2, 7, "Số lượng", "G2", "G2", 1, "WHITE", true, 15, "n");
                excell_app.CreateHeaders(2, 8, "Giá", "H2", "H2", 1, "WHITE", true, 15, "n");
                excell_app.CreateHeaders(2, 9, "Giao hàng", "I2", "I2", 1, "WHITE", true, 15, "n");
                excell_app.CreateHeaders(2, 10, "Ngày bán", "J2", "J2", 1, "WHITE", true, 15, "n");


                int currRow = 3;

                foreach (DataGridViewRow order in dtg_Order.Rows)
                {
                    excell_app.AddData(currRow, 2, order.Cells[Definitions.COLUMN_NAME_ORDER_SELLCODE].Value.ToString(),
                        "B2", "B2", "#,##0");
                    excell_app.AddData(currRow, 3, order.Cells[Definitions.COLUMN_NAME_ORDER_CUSNAME].Value.ToString(),
                        "C2", "C2", "#,##0");
                    excell_app.AddData(currRow, 4, order.Cells[Definitions.COLUMN_NAME_ORDER_CUSTEL].Value.ToString(),
                        "D2", "D2", "#,##0");
                    excell_app.AddData(currRow, 5, order.Cells[Definitions.COLUMN_NAME_ORDER_CUSADD].Value.ToString(),
                        "E2", "E2", "#,##0");
                    excell_app.AddData(currRow, 6, order.Cells[Definitions.COLUMN_NAME_ORDER_GOODKIND].Value.ToString(),
                        "F2", "F2", "#,##0");
                    excell_app.AddData(currRow, 7, order.Cells[Definitions.COLUMN_NAME_ORDER_QUANTITY].Value.ToString(),
                        "G2", "G2", "#,##0");
                    excell_app.AddData(currRow, 8, order.Cells[Definitions.COLUMN_NAME_ORDER_PRICE].Value.ToString(),
                        "H2", "H2", "#,##0");
                    excell_app.AddData(currRow, 9, order.Cells[Definitions.COLUMN_NAME_ORDER_DELIVERER].Value.ToString(),
                        "H2", "H2", "#,##0");
                    excell_app.AddData(currRow, 10, order.Cells[Definitions.COLUMN_NAME_ORDER_SELLDATE].Value.ToString(),
                        "H2", "H2", "#,##0");
                    currRow++;
                }
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_addCustomerOrder control.
        /// </summary>
        private void btn_addCustomerOrder_Click(object sender, EventArgs e)
        {
            if (((TreeNode_User) editTreeView.SelectedNode).node_customer == null)
            {
                MessageBox.Show(Resources.Msb_Customer_Save_Require, Resources.Msb_Title_Inform,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            GSS.DataAccessLayer.GSS.GSS_CustomerRow customerRow =
                ((TreeNode_User) editTreeView.SelectedNode).node_customer;

            var newOrder = new TreeNode_Order(customerRow.cus_Name);
            editTreeView.Nodes[NODE_ORDER].Nodes.Add(newOrder);
            editTreeView.Nodes[NODE_ORDER].Expand();
            editTreeView.SelectedNode = newOrder;
            editTreeView.Focus();

            if (cbb_Customer.SelectedValue.ToString() == customerRow.cus_Id.ToString())
            {
                if (ptb_order.Image != null)
                    ptb_order.Image.Dispose();
                ptb_order.Image = null;
                if (
                    File.Exists(string.Format(Resources.Map_Path_Two_Argument,
                        Path.GetDirectoryName(Application.ExecutablePath), cbb_Customer.SelectedValue)))
                    ptb_order.Image =
                        new Bitmap(string.Format(Resources.Map_Path_Two_Argument,
                            Path.GetDirectoryName(Application.ExecutablePath), cbb_Customer.SelectedValue));
            }
            else
            {
                cbb_Customer.SelectedValue = customerRow.cus_Id;
            }


            try
            {
                cbb_OrderGoodCode.SelectedIndex = 1;
                cbb_OrderGoodCode.SelectedIndex = 0;
            }
            catch
            {
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_SendMessage control.
        /// </summary>
        private void btn_SendMessage_Click(object sender, EventArgs e)
        {
            if (ObjSendMessage == null)
            {
                if (CheckModem())
                {
                    string cusPhone = string.Empty;
                    if (tabControl1.SelectedTab == tpn_customer)
                    {
                        if (!dtg_Customer.SelectedRows[0].Cells[6].FormattedValue.ToString().Trim().Equals(string.Empty))
                        {
                            cusPhone = dtg_Customer.SelectedRows[0].Cells[6].FormattedValue.ToString().Trim();
                        }
                    }
                    ObjSendMessage = new Form_SendMessage(this, cusPhone);
                    ShowForm(ObjSendMessage);
                }

                else
                {
                    MessageBox.Show(this, Resources.Error_Modem_Connect, Resources.Error_Connect, MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_Call control.
        /// </summary>
        private void btn_Call_Click(object sender, EventArgs e)
        {
            if (ObjFormCall == null)
            {
                if (CheckModem())
                {
                    string cusPhone = string.Empty;
                    if (tabControl1.SelectedTab == tpn_customer)
                    {
                        if (!dtg_Customer.SelectedRows[0].Cells[6].FormattedValue.ToString().Trim().Equals(string.Empty))
                        {
                            cusPhone = dtg_Customer.SelectedRows[0].Cells[6].FormattedValue.ToString().Trim();
                        }
                        else if (
                            !dtg_Customer.SelectedRows[0].Cells[5].FormattedValue.ToString().Trim().Equals(
                                string.Empty))
                        {
                            cusPhone = dtg_Customer.SelectedRows[0].Cells[5].FormattedValue.ToString().Trim();
                        }
                    }

                    ObjFormCall = new Form_Call(this, cusPhone);
                    ShowForm(ObjFormCall);
                }
                else
                {
                    MessageBox.Show(this, Resources.Error_Modem_Connect, Resources.Error_Connect, MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        #endregion

        #region Cell formatting

        /// <summary>
        ///   Handles the CellFormatting event of the DataGridView dtg_customer control.
        /// </summary>
        private void dtg_customer_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == dtg_Customer.Columns[Definitions.COLUMN_NAME_CUSTOMER_REMOVE].Index)
            {
                e.FormattingApplied = true;
            }
        }

        /// <summary>
        ///   Handles the CellPainting event of the DataGridView dtg_customer control.
        /// </summary>
        private void dtg_customer_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex >= 0 &&
                dtg_Customer[Definitions.COLUMN_NAME_CUSTOMER_REMOVE, e.RowIndex] is DataGridViewButtonCell)
            {
                if (e.ColumnIndex == dtg_Customer.Columns[Definitions.COLUMN_NAME_CUSTOMER_REMOVE].Index &&
                    e.RowIndex >= 0)
                {
                    e.Paint(e.CellBounds, DataGridViewPaintParts.All);
                    var bc =
                        dtg_Customer[Definitions.COLUMN_NAME_CUSTOMER_REMOVE, e.RowIndex] as DataGridViewButtonCell;
                    e.Graphics.DrawImage(imageList1.Images[10], e.CellBounds.Left, e.CellBounds.Top);

                    e.Handled = true;
                }
            }
        }

        /// <summary>
        ///   Handles the CellFormatting event of the DataGridView dtg_Order control.
        /// </summary>
        private void dtg_Order_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == dtg_Order.Columns[Definitions.COLUMN_NAME_ORDER_REMOVE].Index)
            {
                e.FormattingApplied = true;
            }
        }

        /// <summary>
        ///   Handles the CellPainting event of the DataGridView dtg_Order control.
        /// </summary>
        private void dtg_Order_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex >= 0 && dtg_Order[Definitions.COLUMN_NAME_ORDER_REMOVE, e.RowIndex] is DataGridViewButtonCell)
                if (e.ColumnIndex == dtg_Order.Columns[Definitions.COLUMN_NAME_ORDER_REMOVE].Index && e.RowIndex >= 0)
                {
                    e.Paint(e.CellBounds, DataGridViewPaintParts.All);
                    var bc =
                        dtg_Order[Definitions.COLUMN_NAME_ORDER_REMOVE, e.RowIndex] as DataGridViewButtonCell;
                    e.Graphics.DrawImage(imageList1.Images[11], e.CellBounds.Left, e.CellBounds.Top);

                    e.Handled = true;
                }
        }

        #endregion

        #region pnl_EditOrder

        /// <summary>
        ///   Loads delivers.
        /// </summary>
        public void LoadDeliver()
        {
            GSS.DataAccessLayer.GSS.GSS_DelivererDataTable deliverers = _deliverAdapter.GetDeliverers();

            String currentValue = String.Empty;
            if (cbb_OrderDeliverer.SelectedValue != null)
                currentValue = cbb_OrderDeliverer.SelectedValue.ToString();

            _delivererTable.Clear();
            foreach (GSS.DataAccessLayer.GSS.GSS_DelivererRow deliverer in deliverers)
            {
                DataRow dataRow = _delivererTable.NewRow();
                dataRow[0] = deliverer.del_Name;
                dataRow[1] = deliverer.del_Id;
                _delivererTable.Rows.Add(dataRow);
            }

            if (cbb_OrderDeliverer.SelectedValue != null)
                for (int count = 0; count < _delivererTable.Rows.Count; count++)
                {
                    if (_delivererTable.Rows[count][1].ToString() == currentValue)
                    {
                        cbb_OrderDeliverer.SelectedIndex = count;
                        break;
                    }
                }
        }

        #endregion

        #region Edit Panel

        /// <summary>
        ///   Handles the TextChanged event of the textbox txt_NameCustomer control.
        /// </summary>
        private void txt_NameCustomer_TextChanged(object sender, EventArgs e)
        {
            if ((editTreeView.SelectedNode.Parent.Index == NODE_EDIT ||
                 editTreeView.SelectedNode.Parent.Index == NODE_CALL) && editTreeView.SelectedNode.Level > 0)
            {
                editTreeView.SelectedNode.Text = txt_NameCustomer.Text;
            }
        }


        /// <summary>
        ///   Handles the Click event of the button btn_SaveCustomer control.
        /// </summary>
        private void btn_SaveCustomer_Click(object sender, EventArgs e)
        {
            if (txt_NameCustomer.Text.Trim().Length == 0
                || (txt_HomePhoneCustomer.Text.Trim().Length == 0
                    && txt_MobileCutomer.Text.Trim().Length == 0)
                || txt_AddressCustomer.Text.Trim().Length == 0
                || txt_CityCustomer.Text.Trim().Length == 0
                || txt_DistrictCustomer.Text.Trim().Length == 0
                )
            {
                MessageBox.Show(Resources.Msb_Phone_Require, Resources.Msb_Title_Customer_Add,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if ((txt_HomePhoneCustomer.Text.Trim().Length > 0 && txt_HomePhoneCustomer.Text.Trim().Length < 10)
                || (txt_MobileCutomer.Text.Trim().Length > 0 && txt_MobileCutomer.Text.Trim().Length < 10))
            {
                MessageBox.Show(Resources.Msb_PhoneNo_Digit, Resources.Msb_Title_Customer_Add, MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            var user = (TreeNode_User) editTreeView.SelectedNode;


            // Nếu node_custmer vẫn là null chứng tỏ đây là thêm người, không phải edit người cũ
            if (user.node_customer == null || txt_IdCustomer.Text.Trim().Length == 0)
            {
                try
                {
                    _customerAdapter.InsertCustomer(txt_NameCustomer.Text,
                        txt_CityCustomer.Text,
                        txt_DistrictCustomer.Text,
                        txt_AddressCustomer.Text,
                        txt_HomePhoneCustomer.Text,
                        txt_MobileCutomer.Text,
                        null,
                        String.Empty,
                        null,
                        null
                        );

                    GSS.DataAccessLayer.GSS.GSS_CustomerDataTable customers = _customerAdapter.GetLastCustomer();
                    foreach (GSS.DataAccessLayer.GSS.GSS_CustomerRow customer in customers)
                    {
                        user.node_customer = customer;
                    }
                }
                catch (Exception ext)
                {
                    lbl_ActionStatus.Text = ext.Message;
                    return;
                }

                txt_IdCustomer.Text = (user.node_customer.cus_Id + String.Empty);
                MessageBox.Show(Resources.Customer_Add_ID + user.node_customer.cus_Id, Resources.Msb_Title_Inform,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                UpdateStatus(Resources.Customer_Add_ID + user.node_customer.cus_Id);
            }

                // Nếu node_customer không null chứng tỏ đây là edit người cũ
            else
            {
                try
                {
                    _customerAdapter.UpdateCustomer(txt_NameCustomer.Text,
                        txt_CityCustomer.Text,
                        txt_DistrictCustomer.Text,
                        txt_AddressCustomer.Text,
                        txt_HomePhoneCustomer.Text,
                        txt_MobileCutomer.Text,
                        null,
                        // Gas ID cuối cùng. Nếu mà thêm giao dịch thì sử thành ngày vừa bán còn không thì giữ nguyên
                        String.Empty, // avatar
                        null,
                        // Van ID cuối cùng. Nếu mà thêm giao dịch thì sử thành ngày vừa bán còn không thì giữ nguyên
                        null,
                        // Ngày bán cuối cùng. Nếu mà thêm giao dịch thì sử thành ngày vừa bán còn không thì giữ nguyên
                        user.node_customer.cus_Id
                        );


                    GSS.DataAccessLayer.GSS.GSS_CustomerDataTable customers =
                        _customerAdapter.GetCustomerById(user.node_customer.cus_Id);
                    foreach (GSS.DataAccessLayer.GSS.GSS_CustomerRow customer in customers)
                    {
                        user.node_customer = customer;
                    }

                    MessageBox.Show(Resources.Customer_Edit_ID + user.node_customer.cus_Id, Resources.Msb_Title_Inform,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    UpdateStatus(Resources.Customer_Edit_ID + user.node_customer.cus_Id);
                }
                catch (Exception ext)
                {
                    lbl_ActionStatus.Text = ext.Message;
                    return;
                }
            }

            LoadCustomers();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_CloseEditting control.
        /// </summary>
        private void btn_CloseEditting_Click(object sender, EventArgs e)
        {
            var user = (TreeNode_User) editTreeView.SelectedNode;
            if (user.node_customer == null
                && (txt_AddressCustomer.Text.Trim().Length +
                    txt_NameCustomer.Text.Trim().Length +
                    txt_CityCustomer.Text.Trim().Length +
                    txt_DistrictCustomer.Text.Trim().Length +
                    txt_HomePhoneCustomer.Text.Trim().Length +
                    txt_MobileCutomer.Text.Trim().Length) > 0)
            {
                DialogResult ret = MessageBox.Show(Resources.Customer_Close_Confirm,
                    Resources.Msb_Title_Inform, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (ret == DialogResult.Yes)
                {
                    user.Remove();
                    editTreeView.SelectedNode = editTreeView.Nodes[NODE_EDIT];
                    return;
                }
                return;
            }
            if (user.node_customer != null
                &&
                (
                    txt_AddressCustomer.Text.Trim() != user.node_customer.cus_Address ||
                    txt_NameCustomer.Text.Trim() != user.node_customer.cus_Name ||
                    txt_CityCustomer.Text.Trim() != user.node_customer.cus_City ||
                    txt_DistrictCustomer.Text.Trim() != user.node_customer.cus_Distric ||
                    txt_HomePhoneCustomer.Text.Trim() !=
                    (user.node_customer.IsNull(Definitions.CUSTOMER_HOMENUMBER)
                         ? String.Empty
                         : user.node_customer.cus_HomeNumber) ||
                    txt_MobileCutomer.Text.Trim() !=
                    (user.node_customer.IsNull(Definitions.CUSTOMER_PHONENUMBER)
                         ? String.Empty
                         : user.node_customer.cus_PhoneNumber))
                )
            {
                DialogResult ret = MessageBox.Show(Resources.Customer_Close_Confirm,
                    Resources.Msb_Title_Inform, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (ret == DialogResult.Yes)
                {
                    user.Remove();
                    editTreeView.SelectedNode = editTreeView.Nodes[NODE_EDIT];
                    return;
                }
                return;
            }

            user.Remove();
            editTreeView.SelectedNode = editTreeView.Nodes[NODE_EDIT];
        }

        #endregion

        #region Tree View

        /// <summary>
        ///   Handles the AfterSelect event of the TreeView editTreeView control.
        /// </summary>
        private void editTreeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (editTreeView.SelectedNode != null)
            {
                if (editTreeView.SelectedNode.Index == NODE_ALL)
                    editTreeView.ExpandAll();
                if (editTreeView.SelectedNode.Parent != null &&
                    (editTreeView.SelectedNode.Parent.Index == NODE_EDIT ||
                     editTreeView.SelectedNode.Parent.Index == NODE_CALL) && editTreeView.SelectedNode.Level == 1)
                {
                    editPanel.Visible = true;
                    listPanel.Visible = false;
                    pnl_EditOrder.Visible = false;
                    var user = (TreeNode_User) editTreeView.SelectedNode;

                    LoadUserToEditPanel(user);
                    IncreaseNode(user, editTreeView, 0 - user.call, true, true);
                }
                else if (editTreeView.SelectedNode.Parent != null &&
                         (editTreeView.SelectedNode.Parent.Index == NODE_ORDER) && editTreeView.SelectedNode.Level == 1)
                {
                    editPanel.Visible = false;
                    listPanel.Visible = false;
                    pnl_EditOrder.Visible = true;

                    LoadOrderToEditPanel((TreeNode_Order) editTreeView.SelectedNode);
                }
                else
                {
                    editPanel.Visible = false;
                    pnl_EditOrder.Visible = false;
                    listPanel.Visible = true;

                    if (editTreeView.SelectedNode.Index == NODE_EDIT || editTreeView.SelectedNode.Index == NODE_CALL)
                        tabControl1.SelectedTab = tpn_customer;
                    else
                    {
                        tabControl1.SelectedTab = tpn_order;
                    }
                }
            }

            if (!dtg_Order.Visible && !dtg_Customer.Visible)
            {
                btn_exportexcel.Enabled = false;
            }
            else
            {
                btn_exportexcel.Enabled = true;
            }
        }

        /// <summary>
        ///   Handles the BeforeSelect event of the TreeView editTreeView control.
        /// </summary>
        private void editTreeView_BeforeSelect(object sender, TreeViewCancelEventArgs e)
        {
            if (editTreeView.SelectedNode != null && editTreeView.SelectedNode.Parent != null &&
                (editTreeView.SelectedNode.Parent.Index == NODE_EDIT ||
                 editTreeView.SelectedNode.Parent.Index == NODE_CALL) && editTreeView.SelectedNode.Level == 1)
            {
                var user = (TreeNode_User) editTreeView.SelectedNode;
                user.cus_Address = txt_AddressCustomer.Text;
                user.cus_City = txt_CityCustomer.Text;
                user.cus_Distric = txt_DistrictCustomer.Text;
                user.cus_HomeNumber = txt_HomePhoneCustomer.Text;
                user.cus_PhoneNumber = txt_MobileCutomer.Text;
                user.cus_Name = txt_NameCustomer.Text;
            }
            else if (editTreeView.SelectedNode != null && editTreeView.SelectedNode.Parent != null &&
                     (editTreeView.SelectedNode.Parent.Index == NODE_ORDER) && editTreeView.SelectedNode.Level == 1)
            {
                var order = (TreeNode_Order) editTreeView.SelectedNode;
                order.ode_comment = txt_OrderComment.Text;
                order.ode_Quantity = Int32.Parse(txt_OrderQuantity.Text);
                order.ode_Date = dt_OrderSellDate.Value;
                order.ode_ReturnShell = Int32.Parse(txt_ReturnShell.Text);
                order.ode_PaidMoney = Int32.Parse(txt_PaidMoney.Text);

                try
                {
                    order.ode_CustomerId = Int32.Parse(cbb_Customer.SelectedValue.ToString().Trim());
                }
                catch (Exception)
                {
                    order.ode_CustomerId = -1;
                }

                order.ode_DelivererId = Int32.Parse(cbb_OrderDeliverer.SelectedValue.ToString().Trim());

                if (cbb_OrderKindGood.SelectedItem != null)
                {
                    String currentGood = cbb_OrderKindGood.SelectedItem.ToString().Trim();

                    if (currentGood == Definitions.COMBOBOX_KINDOF_GAS)
                    {
                        order.ode_GasId = Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString().Trim());
                        order.ode_ValveId = -1;
                        order.ode_ShellId = -1;
                    }
                    else if (currentGood == Definitions.COMBOBOX_KINDOF_VALVE)
                    {
                        order.ode_ValveId = Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString().Trim());
                        order.ode_GasId = -1;
                        order.ode_ShellId = -1;
                    }
                    else if (currentGood == Definitions.COMBOBOX_KINDOF_SHELL)
                    {
                        order.ode_ShellId = Int32.Parse(cbb_OrderGoodCode.SelectedValue.ToString().Trim());
                        order.ode_GasId = -1;
                        order.ode_ValveId = -1;
                    }
                }
            }
        }

        #endregion

        #region dtg_Customer

        /// <summary>
        ///   Loads customers.
        /// </summary>
        private void LoadCustomers()
        {
            try
            {
                cbb_Customer.SelectedValueChanged -= cbb_CustomerId_SelectedValueChanged;
                dtg_Customer.Rows.Clear();
                CustomerTable.Clear();
                _userHashTable.Clear();

                _customers = _customerAdapter.GetCustomers();
                foreach (GSS.DataAccessLayer.GSS.GSS_CustomerRow customer in _customers)
                {
                    DataRow dataRow = CustomerTable.NewRow();
                    dataRow[0] = customer.cus_Name;
                    dataRow[1] = customer.cus_Id;
                    CustomerTable.Rows.Add(dataRow);

                    _userHashTable.Add(customer.cus_Id.ToString(), customer);


                    String search = txt_SearchCustomer.Text.Trim();
                    String address = (customer.cus_Address ?? String.Empty) +
                                     (customer.cus_Distric ?? String.Empty) +
                                     (customer.cus_City ?? String.Empty);

                    if (search.Length == 0)
                    {
                        var dtw = new DataGridViewRow_Customer();
                        dtg_Customer.Rows.Add(dtw);
                        ((DataGridViewRow_Customer) dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).row_customer =
                            customer;
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_ID].
                            Value = customer.cus_Id.ToString();
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_NAME].
                            Value = customer.cus_Name;
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_ADDRESS]
                            .Value = (customer.cus_Address ?? String.Empty);
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_DISTRICT
                            ].Value = (customer.cus_Distric ?? String.Empty);
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_CITY].
                            Value = (customer.cus_City ?? String.Empty);
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_REMOVE].
                            Value = String.Empty;


                        if (_user.user_roleId != 1)
                        {
                            var txtcell = new DataGridViewTextBoxCell();
                            dtg_Customer.Columns[Definitions.COLUMN_NAME_CUSTOMER_REMOVE].Width = 0;
                            (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[
                                Definitions.COLUMN_NAME_CUSTOMER_REMOVE] = txtcell;
                            (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[
                                Definitions.COLUMN_NAME_CUSTOMER_REMOVE].Value = String.Empty;
                        }

                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_MOBILE].
                            Value = (customer.IsNull(Definitions.CUSTOMER_PHONENUMBER)
                                         ? String.Empty
                                         : customer.cus_PhoneNumber);
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[
                            Definitions.COLUMN_NAME_CUSTOMER_HOMEPHONE].Value =
                            (customer.IsNull(Definitions.CUSTOMER_HOMENUMBER)
                                 ? String.Empty
                                 : customer.cus_HomeNumber);
                    }
                    else if (
                        customer.cus_Name.Contains(search)
                        || address.Contains(search))
                    {
                        var dtw = new DataGridViewRow_Customer();
                        dtg_Customer.Rows.Add(dtw);
                        ((DataGridViewRow_Customer) dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).row_customer =
                            customer;
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_ID].
                            Value = customer.cus_Id.ToString();
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_NAME].
                            Value = customer.cus_Name;
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_ADDRESS]
                            .Value = (customer.cus_Address ?? String.Empty);
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_DISTRICT
                            ].Value = (customer.cus_Distric ?? String.Empty);
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_CITY].
                            Value = (customer.cus_City ?? String.Empty);
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_REMOVE].
                            Value = String.Empty;


                        if (_user.user_roleId != 1)
                        {
                            var txtcell = new DataGridViewTextBoxCell();
                            dtg_Customer.Columns[Definitions.COLUMN_NAME_CUSTOMER_REMOVE].Width = 0;
                            (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[
                                Definitions.COLUMN_NAME_CUSTOMER_REMOVE] = txtcell;
                            (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[
                                Definitions.COLUMN_NAME_CUSTOMER_REMOVE].Value = String.Empty;
                        }

                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_CUSTOMER_MOBILE].
                            Value = (customer.IsNull(Definitions.CUSTOMER_PHONENUMBER)
                                         ? String.Empty
                                         : customer.cus_PhoneNumber);
                        (dtg_Customer.Rows[dtg_Customer.Rows.Count - 1]).Cells[
                            Definitions.COLUMN_NAME_CUSTOMER_HOMEPHONE].Value =
                            (customer.IsNull(Definitions.CUSTOMER_HOMENUMBER)
                                 ? String.Empty
                                 : customer.cus_HomeNumber);
                    }
                }
                cbb_Customer.SelectedValueChanged += cbb_CustomerId_SelectedValueChanged;
            }
            catch (Exception ext)
            {
                lbl_ActionStatus.Text = ext.Message;
            }
        }


        /// <summary>
        ///   Handles the Click event of the button btn_EditUser control.
        /// </summary>
        private void btn_EditUser_Click(object sender, EventArgs e)
        {
            for (int count = 0; count < editTreeView.Nodes[NODE_EDIT].Nodes.Count; count++)
            {
                if (((TreeNode_User) editTreeView.Nodes[NODE_EDIT].Nodes[count]).node_customer != null &&
                    ((TreeNode_User) editTreeView.Nodes[NODE_EDIT].Nodes[count]).node_customer.cus_Id ==
                    ((DataGridViewRow_Customer) dtg_Customer.SelectedRows[0]).row_customer.cus_Id)
                {
                    editTreeView.Nodes[NODE_EDIT].Expand();
                    editTreeView.SelectedNode = editTreeView.Nodes[NODE_EDIT].Nodes[count];
                    editTreeView.Focus();
                    return;
                }
            }

            GSS.DataAccessLayer.GSS.GSS_CustomerRow customerRow =
                ((DataGridViewRow_Customer) dtg_Customer.SelectedRows[0]).row_customer;

            var newUser = new TreeNode_User(customerRow.cus_Name) {node_customer = customerRow};

            newUser.loadNode();

            editTreeView.Nodes[NODE_EDIT].Nodes.Add(newUser);


            editTreeView.Nodes[NODE_EDIT].Expand();
            editTreeView.SelectedNode = newUser;
            editTreeView.Focus();

            //LoadUserToEditPanel(newUser);
        }

        /// <summary>
        ///   Handles the Click event of the button btn_AddNewUser control.
        /// </summary>
        private void btn_AddNewUser_Click(object sender, EventArgs e)
        {
            var newUser = new TreeNode_User(Resources.User_New);
            editTreeView.Nodes[NODE_EDIT].Nodes.Add(newUser);
            editTreeView.Nodes[NODE_EDIT].Expand();
            editTreeView.SelectedNode = newUser;
            editTreeView.Focus();
        }


        /// <summary>
        ///   Handles the SelectionChanged event of the DataGridView dtg_Customer control.
        /// </summary>
        private void dtg_Customer_SelectionChanged(object sender, EventArgs e)
        {
            if (dtg_Customer.SelectedRows.Count == 1)
            {
                btn_EditUser.Enabled = true;
                btn_addorder.Enabled = true;
            }
            else
            {
                btn_EditUser.Enabled = false;
                btn_addorder.Enabled = true;
            }
        }

        #endregion

        #region dgt_Order

        /// <summary>
        ///   Loads orders.
        /// </summary>
        private void LoadOrder()
        {
            dtg_Order.Rows.Clear();

            // Load Gas Valve item------------------------------------------------------------------
            GSS.DataAccessLayer.GSS.GSS_GasDataTable gases = _gasAdapter.GetGass();

            DataRow dataRow;


            GasTable.Clear();
            foreach (GSS.DataAccessLayer.GSS.GSS_GasRow gas in gases)
            {
                dataRow = GasTable.NewRow();
                dataRow[0] = gas.gas_Name;
                dataRow[1] = gas.gas_Id;
                GasTable.Rows.Add(dataRow);
            }

            GSS.DataAccessLayer.GSS.GSS_ValveDataTable valves = _valveAdapter.GetValves();

            ValveTable.Clear();


            foreach (GSS.DataAccessLayer.GSS.GSS_ValveRow valve in valves)
            {
                dataRow = ValveTable.NewRow();
                dataRow[0] = valve.valve_Name;
                dataRow[1] = valve.valve_Id;
                ValveTable.Rows.Add(dataRow);
            }


            GSS.DataAccessLayer.GSS.GSS_ShellDataTable shelles = _shellAdapter.GetShells();


            ShellTable.Clear();
            foreach (GSS.DataAccessLayer.GSS.GSS_ShellRow shell in shelles)
            {
                dataRow = ShellTable.NewRow();
                dataRow[0] = shell.shell_Name;
                dataRow[1] = shell.shell_Id;
                ShellTable.Rows.Add(dataRow);
            }


            // -------------------------------------------------------------------------------


            if (!ckb_CustomerRecordFilter.Checked ||
                (ckb_CustomerRecordFilter.Checked && txt_CustomerRecordFilter.Text.Trim().Length == 0))
            {
                if (ckb_CustomerDateFilter.Checked && dtp_FromDate.Enabled && dtp_ToDate.Enabled)
                {
                    _orders = _orderAdapter.GetOrdersByDates(dtp_FromDate.Value, dtp_ToDate.Value.AddDays(1));
                }
                else
                {
                    _orders = _orderAdapter.GetOrders();
                }
            }
            else
            {
                if (ckb_CustomerDateFilter.Checked && dtp_FromDate.Enabled && dtp_ToDate.Enabled)
                {
                    _orders = _orderAdapter.GetOrderByDateLimit(Int32.Parse(txt_CustomerRecordFilter.Text.Trim()),
                        dtp_FromDate.Value, dtp_ToDate.Value.AddDays(1));
                }
                else
                {
                    _orders = _orderAdapter.GetOrderLimit(Int32.Parse(txt_CustomerRecordFilter.Text.Trim()));
                }
            }

            GSS.DataAccessLayer.GSS.GSS_OrderRow order;
            GSS.DataAccessLayer.GSS.GSS_CustomerRow customer;
            foreach (GSS.DataAccessLayer.GSS.GSS_OrderRow t in _orders)
            {
                order = t;

                try
                {
                    // Find Customer-----------------------------------------------------
                    customer = (GSS.DataAccessLayer.GSS.GSS_CustomerRow) _userHashTable[order.ode_CustomerId.ToString()];
                    //------------------------------------------------------------------
                }
                catch (Exception)
                {
                    continue;
                }


                // Find Deliver-----------------------------------------------------
                String deliverName = String.Empty;
                var deliverDataTable = (DataTable) cbb_OrderDeliverer.DataSource;
                for (int count = 0; count < deliverDataTable.Rows.Count; count++)
                {
                    if (Int32.Parse(deliverDataTable.Rows[count][1].ToString()) == order.ode_DelivererId)
                    {
                        deliverName = deliverDataTable.Rows[count][0].ToString();
                        break;
                    }
                }
                //------------------------------------------------------------------


                // Find Good -------------------------------------------------------
                String goodName = String.Empty;

                if (!order.IsNull(Definitions.ORDER_GAS_ID))
                {
                    for (int count = 0; count < GasTable.Rows.Count; count++)
                    {
                        if (Int32.Parse(GasTable.Rows[count][1].ToString()) == order.ode_GasId)
                        {
                            goodName = GasTable.Rows[count][0].ToString();
                            break;
                        }
                    }
                }
                else if (!order.IsNull(Definitions.ORDER_VALVE_ID))
                {
                    for (int count = 0; count < ValveTable.Rows.Count; count++)
                    {
                        if (Int32.Parse(ValveTable.Rows[count][1].ToString()) == order.ode_ValveId)
                        {
                            goodName = ValveTable.Rows[count][0].ToString();
                            break;
                        }
                    }
                }
                else if (!order.IsNull(Definitions.ORDER_SHELL_ID))
                {
                    for (int count = 0; count < ShellTable.Rows.Count; count++)
                    {
                        if (Int32.Parse(ShellTable.Rows[count][1].ToString()) == order.ode_ShellId)
                        {
                            goodName = ShellTable.Rows[count][0].ToString();
                            break;
                        }
                    }
                }
                //------------------------------------------------------------------

                // Find Price ------------------------------------------------------
                String price = String.Empty;
                if (!order.IsNull(Definitions.ORDER_GAS_ID))
                {
                    GSS.DataAccessLayer.GSS.GSS_ValueDataTable values = _valueAdapter.GetValueById(order.ode_GasValueId);
                    foreach (GSS.DataAccessLayer.GSS.GSS_ValueRow value in values)
                    {
                        price = value.val_Price + String.Empty;
                    }
                }
                else if (!order.IsNull(Definitions.ORDER_VALVE_ID))
                {
                    GSS.DataAccessLayer.GSS.GSS_ValueDataTable values =
                        _valueAdapter.GetValueById(order.ode_ValveValueId);
                    foreach (GSS.DataAccessLayer.GSS.GSS_ValueRow value in values)
                    {
                        price = value.val_Price + String.Empty;
                    }
                }
                else if (!order.IsNull(Definitions.ORDER_SHELL_ID))
                {
                    GSS.DataAccessLayer.GSS.GSS_ValueDataTable values =
                        _valueAdapter.GetValueById(order.ode_ShellValueId);
                    foreach (GSS.DataAccessLayer.GSS.GSS_ValueRow value in values)
                    {
                        price = value.val_Price + String.Empty;
                    }
                }
                //------------------------------------------------------------------

                String search = txt_searchOrder.Text.Trim();
                String homeNumber = customer.IsNull(Definitions.CUSTOMER_HOMENUMBER)
                                        ? String.Empty
                                        : customer.cus_HomeNumber;
                String phoneNumber = customer.IsNull(Definitions.CUSTOMER_PHONENUMBER)
                                         ? String.Empty
                                         : customer.cus_PhoneNumber;
                String telephone = homeNumber + ":" + phoneNumber;
                if (String.IsNullOrEmpty(homeNumber) || String.IsNullOrEmpty(phoneNumber))
                    telephone = telephone.Replace(":", "");

                if (txt_searchOrder.Text.Trim().Length == 0)
                {
                    var dtw = new DataGridViewRow_Order();
                    dtg_Order.Rows.Add(dtw);
                    ((DataGridViewRow_Order) dtg_Order.Rows[dtg_Order.Rows.Count - 1]).row_order = order;
                    (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_SELLCODE].Value =
                        order.ode_Id.ToString();
                    (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_CUSNAME].Value =
                        customer.cus_Name;
                    (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_CUSTEL].Value =
                        telephone;
                    (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_CUSADD].Value =
                        customer.cus_Address + " Quận " + customer.cus_Distric + " " + customer.cus_City;
                    (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_GOODKIND].Value =
                        goodName;
                    (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_QUANTITY].Value =
                        order.ode_Quantity.ToString();
                    (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_PRICE].Value = price;
                    (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_DELIVERER].Value =
                        deliverName;
                    (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_SELLDATE].Value =
                        order.ode_Date.ToString();
                    (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_REMOVE].Value =
                        String.Empty;


                    if (_user.user_roleId != 1)
                    {
                        var txtcell = new DataGridViewTextBoxCell();
                        dtg_Order.Columns[Definitions.COLUMN_NAME_ORDER_REMOVE].Width = 0;
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_REMOVE] = txtcell;
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_REMOVE].Value =
                            String.Empty;
                    }
                }
                else
                {
                    if (
                        customer.cus_Name.Contains(search)
                        || telephone.Contains(search)
                        || goodName.Contains(search)
                        || deliverName.Contains(search)
                        || customer.cus_Address.Contains(search)
                        || customer.cus_Distric.Contains(search)
                        || customer.cus_City.Contains(search)
                        )
                    {
                        var dtw = new DataGridViewRow_Order();
                        dtg_Order.Rows.Add(dtw);
                        ((DataGridViewRow_Order) dtg_Order.Rows[dtg_Order.Rows.Count - 1]).row_order = order;
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_SELLCODE].Value =
                            order.ode_Id.ToString();
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_CUSNAME].Value =
                            customer.cus_Name;
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_CUSTEL].Value =
                            telephone;
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_CUSADD].Value =
                            customer.cus_Address + " Quận " + customer.cus_Distric + " " + customer.cus_City;
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_GOODKIND].Value =
                            goodName;
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_QUANTITY].Value =
                            order.ode_Quantity.ToString();
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_PRICE].Value =
                            price;
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_DELIVERER].Value
                            = deliverName;
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_SELLDATE].Value =
                            order.ode_Date.ToString();
                        (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_REMOVE].Value =
                            String.Empty;


                        if (_user.user_roleId != 1)
                        {
                            var txtcell = new DataGridViewTextBoxCell();
                            dtg_Order.Columns[Definitions.COLUMN_NAME_ORDER_REMOVE].Width = 0;
                            (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_REMOVE] =
                                txtcell;
                            (dtg_Order.Rows[dtg_Order.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_ORDER_REMOVE].Value
                                = String.Empty;
                        }
                    }
                    else
                    {
                        t.Delete();
                        continue;
                    }
                }
            }
        }

        #endregion

        #region Based override method

        /// <summary>
        ///   Raises the FormClosed event.
        /// </summary>
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            
            if (ObjSendMessage != null)
                ObjSendMessage.Close();
            if (ObjReceiveCall != null)
                ObjReceiveCall.Close_Form();
            if (ObjFormCall != null)
                ObjFormCall.Close();
            if (_modem != null)
                _modem.ClosePort();
            base.OnFormClosed(e);
            _parentLogin.txt_status.Text = string.Empty;
            _parentLogin.txt_password.Text = String.Empty;
            _parentLogin.txt_username.Text = String.Empty;
            _parentLogin.Show();
            _parentLogin.txt_username.Select();
            _parentLogin.Visible = true;
            _parentLogin.Opacity = 100;
        }

        /// <summary>
        ///   Raises the On Form Closed event.
        /// </summary>
        protected override void OnClosed(EventArgs e)
        {
        }

        #endregion

        #region Helper Method

        /// <summary>
        ///   Users the pemission.
        /// </summary>
        private void UserPemission(int roleId)
        {
            if (roleId == 1)
                return;

            quảnLýTàiKhoảnToolStripMenuItem.Enabled = false;
            danhSáchHàngHóaToolStripMenuItem.Enabled = Settings.Default.cbx_productist;
            smi_deliverer.Enabled = Settings.Default.cbx_employeetist;
            danhSáchNhàCungCấpToolStripMenuItem.Enabled = Settings.Default.cbx_suppliertist;
            càiĐặtModemToolStripMenuItem.Enabled = false;
            càiĐặtMẫuHóaĐơnToolStripMenuItem.Enabled = Settings.Default.cbx_billsetup;
            tạoBảnSaoDữLiệuToolStripMenuItem.Enabled = Settings.Default.cbx_backup;
            phụcHồiTừBảnSaoToolStripMenuItem.Enabled = Settings.Default.cbx_restore;


            nhậpHàngTừSảnXuấtToolStripMenuItem.Enabled = Settings.Default.cbx_importproduct;
            xuấtHàngĐểTiêuDùngToolStripMenuItem.Enabled = Settings.Default.cbx_exporttouse;
            kiểmHàngToolStripMenuItem.Enabled = Settings.Default.cbx_checkproduct;
            doanhThuBánHàngToolStripMenuItem.Enabled = Settings.Default.cbx_goodsold;
            thốngKêBánHàngNhânViênToolStripMenuItem.Enabled = Settings.Default.cbx_deliversell;

            danhSáchKháchNợVỏToolStripMenuItem.Enabled = Settings.Default.cbx_shellborrow;
            danhSáchKháchNợTiềnToolStripMenuItem.Enabled = Settings.Default.cbx_borrowmoneylist;
        }

        /// <summary>
        ///   Increases the node.
        /// </summary>
        /// <param name = "user">The user.</param>
        /// <param name = "tree">The tree.</param>
        /// <param name = "add">The add.</param>
        /// <param name = "isAnswered">if set to <c>true</c> [is answered].</param>
        /// <param name = "isFocus">if set to <c>true</c> [is focus].</param>
        public void IncreaseNode(TreeNode_User user, TreeView tree, int add, bool isAnswered, bool isFocus)
        {
            if (tree.InvokeRequired)
            {
                IncreaseNodeCallback d = IncreaseNode;
                Invoke(d, new object[] {user, tree, add, isAnswered, isFocus});
            }
            else
            {
                if (isFocus)
                {
                    tree.SelectedNode = user;
                    tree.Focus();
                }
                user.isAnswered = isAnswered;
                user.call += add;
                if (user.call == 0)
                {
                    user.ImageIndex = 0;
                    user.SelectedImageIndex = 0;
                }
                else if (user.call > 5)
                {
                    user.ImageIndex = 9;
                    user.SelectedImageIndex = 9;
                }
                else
                {
                    user.ImageIndex = user.call + 3;
                    user.SelectedImageIndex = user.call + 3;
                }
            }
        }

        /// <summary>
        ///   Inserts the word.
        /// </summary>
        /// <param name = "objDoc">The obj doc.</param>
        /// <param name = "fontName">Name of the font.</param>
        /// <param name = "text">The text.</param>
        /// <param name = "align">The align.</param>
        /// <param name = "size">The size.</param>
        /// <param name = "boldSize">Size of the bold.</param>
        /// <param name = "spaceAfter">The space after.</param>
        /// <param name = "spaceBefore">The space before.</param>
        private static void InsertWord(Document objDoc, String fontName, String text, WdParagraphAlignment align,
                                       int size,
                                       int boldSize, int spaceAfter, int spaceBefore)
        {
            object oEndOfDoc = "\\endofdoc"; /* \endofdoc is a predefined bookmark */
            object oRngTitle = objDoc.Bookmarks.get_Item(oEndOfDoc).Range;
            Paragraph oParaTitleWeb = objDoc.Content.Paragraphs.Add(ref oRngTitle);
            oParaTitleWeb.Range.Font.Name = fontName;
            oParaTitleWeb.Range.Text = text;
            oParaTitleWeb.Format.Alignment = align;
            oParaTitleWeb.Range.Font.Bold = boldSize;
            oParaTitleWeb.Range.Font.Size = size;
            oParaTitleWeb.Format.SpaceAfter = spaceAfter; //24 pt spacing after paragraph.
            oParaTitleWeb.Format.SpaceBefore = spaceBefore; //24 pt spacing after paragraph.
            oParaTitleWeb.Range.InsertParagraphAfter();
        }

        /// <summary>
        ///   Adds the node.
        /// </summary>
        /// <param name = "user">The user.</param>
        /// <param name = "tree">The tree.</param>
        /// <param name = "parentNode">The parent_node.</param>
        /// <param name = "selected">if set to <c>true</c> [selected].</param>
        public void AddNode(TreeNode_User user, TreeView tree, int parentNode, bool selected)
        {
            if (tree.InvokeRequired)
            {
                AddNodeCallback d = AddNode;
                Invoke(d, new object[] {user, tree, parentNode, selected});
            }
            else
            {
                tree.Nodes[parentNode].Nodes.Add(user);
                tree.Nodes[parentNode].Expand();
                if (selected)
                    tree.SelectedNode = user;
                tree.Focus();
            }
        }

        /// <summary>
        ///   Checks the modem.
        /// </summary>
        /// <returns>return state of modem </returns>
        public bool CheckModem()
        {
            try
            {
                if (_modem == null)
                {
                    _modem = new Modem_Control
                                 {
                                     CallReceiveDelegate = CallReceiveResponse,
                                     CallFormDelegate = CallToResponse
                                 };
                }
                if (!_modem.IsConnected())
                {
                    _modem.OpenPort();
                    if (!_modem.IsConnected())
                    {
                        lbl_modemStatus.Text = Resources.Error_Modem_Connect;
                        lbl_modemStatus.ForeColor = Color.Red;
                        return false;
                    }
                    lbl_modemStatus.Text = Resources.Modem_Connected;
                    lbl_modemStatus.ForeColor = Color.Blue;
                    return true;
                }
            }
            catch (Exception)
            {
                lbl_modemStatus.Text = Resources.Error_Modem_Connect;
                lbl_modemStatus.ForeColor = Color.Red;
                return false;
            }
            lbl_modemStatus.Text = Resources.Modem_Connected;
            lbl_modemStatus.ForeColor = Color.Blue;
            return true;
        }

        #endregion

        #region Delegate method

        /// <summary>
        ///   Set visible of panel Receive Call
        /// </summary>
        /// <param name = "isAnswer">if set to <c>true</c> [is answer].</param>
        public void PnlVisible(bool isAnswer)
        {
            if (InvokeRequired)
            {
                PanelCallBack d = PnlVisible;
                Invoke(d, new object[] {isAnswer});
            }
            else
            {
                if (isAnswer)
                    _da = DateTime.Now;
                tmr_Call.Enabled = isAnswer;
                lbl_PhoneNo.Text = phone;
                pnl_Call.Visible = isAnswer;
            }
        }

        /// <summary>
        ///   Updates the status.
        /// </summary>
        /// <param name = "text">The text.</param>
        public void UpdateStatus(string text)
        {
            if (lbl_ActionStatus.InvokeRequired)
            {
                UpdateStatusCallback d = UpdateStatus;
                Invoke(d, new object[] {text});
            }
            else
            {
                lbl_ActionStatus.Text = text;
                tmr_UpdateStatus.Start();
            }
        }

        /// <summary>
        ///   Response of receiving call.
        /// </summary>
        /// <param name = "status">The status.</param>
        /// <param name = "phoneNo">The phone no.</param>
        private void CallReceiveResponse(string status, string phoneNo)
        {
            if (!status.Equals(String.Empty))
                UpdateStatus(status);
            if (phoneNo.Equals(Resources.Call_Finished_Signal))
            {
                if (status.Equals(Resources.Call_Missed))
                    UnAnswer(phone);
                UpdateStatus(status);
                phone = String.Empty;
                PnlVisible(false);
            }
            else if (!phoneNo.Equals(String.Empty))
            {
                if (!phoneNo.Equals(phone))
                {
                    _status = status;
                    phone = phoneNo;
                    var thread = new Thread(ReceiveCallThread);
                    thread.Start();

                    UpdateStatus(status);
                }
            }

        }

        /// <summary>
        ///   Response of the call.
        /// </summary>
        /// <param name = "status">The status.</param>
        /// <param name = "phoneNo">The phone no.</param>
        private static void CallToResponse(string status, string phoneNo)
        {
        }

        #endregion
    }
}