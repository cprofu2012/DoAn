﻿namespace GSS.View.Menu_Report
{
    partial class Report_BorrowShell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Report_BorrowShell));
            this.dtg_BorowShell = new System.Windows.Forms.DataGridView();
            this.COLUMN_NAME_BORROWSHELL_CUSID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_BORROWSHELL_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_BORROWSHELL_PHONE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_BORROWSHELL_BORROWNUMBER = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_BORROWSHELL_KINDSHELL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_BorowShell)).BeginInit();
            this.SuspendLayout();
            // 
            // dtg_BorowShell
            // 
            this.dtg_BorowShell.AllowUserToAddRows = false;
            this.dtg_BorowShell.AllowUserToDeleteRows = false;
            this.dtg_BorowShell.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_BorowShell.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_BorowShell.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_BorowShell.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.COLUMN_NAME_BORROWSHELL_CUSID,
            this.COLUMN_NAME_BORROWSHELL_NAME,
            this.COLUMN_NAME_BORROWSHELL_PHONE,
            this.COLUMN_NAME_BORROWSHELL_BORROWNUMBER,
            this.COLUMN_NAME_BORROWSHELL_KINDSHELL,
            this.Column1});
            this.dtg_BorowShell.Location = new System.Drawing.Point(13, 12);
            this.dtg_BorowShell.Name = "dtg_BorowShell";
            this.dtg_BorowShell.ReadOnly = true;
            this.dtg_BorowShell.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_BorowShell.Size = new System.Drawing.Size(747, 413);
            this.dtg_BorowShell.TabIndex = 5;
            // 
            // COLUMN_NAME_BORROWSHELL_CUSID
            // 
            this.COLUMN_NAME_BORROWSHELL_CUSID.HeaderText = "Mã KH";
            this.COLUMN_NAME_BORROWSHELL_CUSID.Name = "COLUMN_NAME_BORROWSHELL_CUSID";
            this.COLUMN_NAME_BORROWSHELL_CUSID.ReadOnly = true;
            // 
            // COLUMN_NAME_BORROWSHELL_NAME
            // 
            this.COLUMN_NAME_BORROWSHELL_NAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.COLUMN_NAME_BORROWSHELL_NAME.HeaderText = "Tên";
            this.COLUMN_NAME_BORROWSHELL_NAME.Name = "COLUMN_NAME_BORROWSHELL_NAME";
            this.COLUMN_NAME_BORROWSHELL_NAME.ReadOnly = true;
            // 
            // COLUMN_NAME_BORROWSHELL_PHONE
            // 
            this.COLUMN_NAME_BORROWSHELL_PHONE.HeaderText = "Số điện thoại";
            this.COLUMN_NAME_BORROWSHELL_PHONE.Name = "COLUMN_NAME_BORROWSHELL_PHONE";
            this.COLUMN_NAME_BORROWSHELL_PHONE.ReadOnly = true;
            this.COLUMN_NAME_BORROWSHELL_PHONE.Width = 130;
            // 
            // COLUMN_NAME_BORROWSHELL_BORROWNUMBER
            // 
            this.COLUMN_NAME_BORROWSHELL_BORROWNUMBER.HeaderText = "Tổng nợ (Vỏ)";
            this.COLUMN_NAME_BORROWSHELL_BORROWNUMBER.Name = "COLUMN_NAME_BORROWSHELL_BORROWNUMBER";
            this.COLUMN_NAME_BORROWSHELL_BORROWNUMBER.ReadOnly = true;
            // 
            // COLUMN_NAME_BORROWSHELL_KINDSHELL
            // 
            this.COLUMN_NAME_BORROWSHELL_KINDSHELL.HeaderText = "Loại vỏ";
            this.COLUMN_NAME_BORROWSHELL_KINDSHELL.Name = "COLUMN_NAME_BORROWSHELL_KINDSHELL";
            this.COLUMN_NAME_BORROWSHELL_KINDSHELL.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Ngày";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Report_BorrowShell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 437);
            this.Controls.Add(this.dtg_BorowShell);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Report_BorrowShell";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách nợ vỏ";
            ((System.ComponentModel.ISupportInitialize)(this.dtg_BorowShell)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtg_BorowShell;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_BORROWSHELL_CUSID;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_BORROWSHELL_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_BORROWSHELL_PHONE;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_BORROWSHELL_BORROWNUMBER;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_BORROWSHELL_KINDSHELL;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
    }
}