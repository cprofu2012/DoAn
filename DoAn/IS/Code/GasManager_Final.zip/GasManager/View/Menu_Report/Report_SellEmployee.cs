﻿using System;
using System.Data;
using System.Windows.Forms;
using GSS.Control.Excel_Object;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;

namespace GSS.View.Menu_Report
{
    /// <summary>
    ///   Report revenue by employee
    /// </summary>
    public partial class Report_SellEmployee : Form
    {
        private readonly GSS_DelivererTableAdapter _deliverAdapter = new GSS_DelivererTableAdapter();
        private readonly DataTable _delivererTable = new DataTable();
        private readonly GasOrdersTableAdapter _gasorderAdapter = new GasOrdersTableAdapter();
        private readonly ShellOrdersTableAdapter _shellorderAdapter = new ShellOrdersTableAdapter();
        private readonly ValveOrdersTableAdapter _valveorderAdapter = new ValveOrdersTableAdapter();

        /// <summary>
        ///   Initializes a new instance of the "Report_SellEmployee" form.
        /// </summary>
        public Report_SellEmployee()
        {
            InitializeComponent();

            _delivererTable.Columns.Add(Definitions.FIELD_TEXT);
            _delivererTable.Columns.Add(Definitions.FIELD_VALUE);
            cbb_deliver.DataSource = _delivererTable;
            cbb_deliver.DisplayMember = Definitions.FIELD_TEXT;
            cbb_deliver.ValueMember = Definitions.FIELD_VALUE;

            LoadDeliver();
        }

        /// <summary>
        ///   Loads delivers.
        /// </summary>
        public void LoadDeliver()
        {
            var deliverers = _deliverAdapter.GetDeliverers();

            _delivererTable.Clear();
            foreach (var deliverer in deliverers)
            {
                var dataRow = _delivererTable.NewRow();
                dataRow[0] = deliverer.del_Name;
                dataRow[1] = deliverer.del_Id;
                _delivererTable.Rows.Add(dataRow);
            }
            if (deliverers.Rows.Count > 0)
            {
                cbb_deliver.SelectedIndex = 0;
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_Select.
        /// </summary>
        private void btn_Select_Click(object sender, EventArgs e)
        {
            if (cbb_deliver.SelectedValue == null)
            {
                return;
            }
            dtg_report.Rows.Clear();
            var from =
                dtp_from.Value.AddHours(0 - dtp_from.Value.Hour).
                    AddMinutes(0 - dtp_from.Value.Minute).
                    AddSeconds(0 - dtp_from.Value.Second);
            var to =
                dtp_to.Value.AddHours(0 - dtp_to.Value.Hour).
                    AddMinutes(0 - dtp_to.Value.Minute).
                    AddSeconds(0 - dtp_to.Value.Second)
                    .AddDays(1);

            var gasses =
                _gasorderAdapter.GetDataByDeliver(Int32.Parse(cbb_deliver.SelectedValue.ToString()), from, to);
            var valves =
                _valveorderAdapter.GetDataByDeliver(Int32.Parse(cbb_deliver.SelectedValue.ToString()), from, to);
            var shelles =
                _shellorderAdapter.GetDataByDeliver(Int32.Parse(cbb_deliver.SelectedValue.ToString()), from, to);

            foreach (var gas in gasses)
            {
                dtg_report.Rows.Add(new object[]
                                        {
                                            gas.ode_Date, gas.gas_Name, gas.ode_Quantity, gas.ode_ImportPrice,
                                            gas.ode_PaidMoney + gas.ode_BorrowMoney,
                                            gas.ode_PaidMoney + gas.ode_BorrowMoney - gas.ode_ImportPrice
                                        });
            }
            foreach (var valve in valves)
            {
                dtg_report.Rows.Add(new object[]
                                        {
                                            valve.ode_Date, valve.valve_Name, valve.ode_Quantity, valve.ode_ImportPrice,
                                            valve.ode_PaidMoney + valve.ode_BorrowMoney,
                                            valve.ode_PaidMoney + valve.ode_BorrowMoney - valve.ode_ImportPrice
                                        });
            }
            foreach (var shell in shelles)
            {
                dtg_report.Rows.Add(new object[]
                                        {
                                            shell.ode_Date, shell.shell_Name, shell.ode_Quantity, shell.ode_ImportPrice,
                                            shell.ode_PaidMoney + shell.ode_BorrowMoney,
                                            shell.ode_PaidMoney + shell.ode_BorrowMoney - shell.ode_ImportPrice
                                        });
            }
        }

        /// <summary>
        ///   Handles the Click event of the button export to excel.
        /// </summary>
        private void button2_Click(object sender, EventArgs e)
        {
            if (cbb_deliver.SelectedValue == null)
            {
                return;
            }
            var excellApp = new CreateExcelDoc();

            excellApp.CreateHeaders(2, 2, "Ngày", "B2", "B2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(2, 3, "Tên hàng", "C2", "C2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(2, 4, "Số lượng", "D2", "D2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(2, 5, "Giá nhập", "E2", "E2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(2, 6, "Doanh thu", "F2", "F2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(2, 7, "Lãi", "G2", "G2", 1, "WHITE", true, 15, "n");

            var currRow = 3;

            foreach (DataGridViewRow row in dtg_report.Rows)
            {
                excellApp.AddData(currRow, 2, row.Cells[0].Value.ToString(), "B2", "B2", "#,##0");
                excellApp.AddData(currRow, 3, row.Cells[1].Value.ToString(), "C2", "C2", "#,##0");
                excellApp.AddData(currRow, 4, row.Cells[2].Value.ToString(), "D2", "D2", "#,##0");
                excellApp.AddData(currRow, 5, row.Cells[3].Value.ToString(), "E2", "E2", "#,##0");
                excellApp.AddData(currRow, 6, row.Cells[4].Value.ToString(), "F2", "F2", "#,##0");
                excellApp.AddData(currRow, 7, row.Cells[5].Value.ToString(), "G2", "G2", "#,##0");
                currRow++;
            }
        }

        /// <summary>
        ///   Handles the Deliver event of the Change control.
        /// </summary>
        private void Change_Deliver(object sender, EventArgs e)
        {
        }

        /// <summary>
        ///   Handles the Changed event of the DateTimePicker dtp_to.
        /// </summary>
        private void dtp_to_Changed(object sender, EventArgs e)
        {
            if (dtp_to.Value.CompareTo(dtp_from.Value) < 0)
            {
                dtp_to.Value = dtp_from.Value;
            }
        }

        /// <summary>
        ///   Handles the Changed event of the DateTimePicker dtp_from.
        /// </summary>
        private void dtp_from_Changed(object sender, EventArgs e)
        {
            if (dtp_to.Value.CompareTo(dtp_from.Value) < 0)
            {
                dtp_to.Value = dtp_from.Value;
            }
        }
    }
}