﻿namespace GSS.View.Menu_Report
{
    partial class Form_GoodCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_GoodCustomer));
            this.btn_view_due = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.dtg_due_due = new System.Windows.Forms.DataGridView();
            this.CustomerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_CALL_NUMBER = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_biggerNumber_due = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_due_due)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_view_due
            // 
            this.btn_view_due.Location = new System.Drawing.Point(264, 5);
            this.btn_view_due.Name = "btn_view_due";
            this.btn_view_due.Size = new System.Drawing.Size(84, 23);
            this.btn_view_due.TabIndex = 1;
            this.btn_view_due.Text = "Xem";
            this.btn_view_due.UseVisualStyleBackColor = true;
            this.btn_view_due.Click += new System.EventHandler(this.btn_view_due_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(206, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Ngày ";
            // 
            // dtg_due_due
            // 
            this.dtg_due_due.AllowUserToAddRows = false;
            this.dtg_due_due.AllowUserToDeleteRows = false;
            this.dtg_due_due.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_due_due.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_due_due.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_due_due.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CustomerID,
            this.dataGridViewTextBoxColumn2,
            this.COLUMN_NAME_CALL_NUMBER,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.dtg_due_due.Location = new System.Drawing.Point(12, 33);
            this.dtg_due_due.Name = "dtg_due_due";
            this.dtg_due_due.ReadOnly = true;
            this.dtg_due_due.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_due_due.Size = new System.Drawing.Size(761, 480);
            this.dtg_due_due.TabIndex = 12;
            // 
            // CustomerID
            // 
            this.CustomerID.HeaderText = "Mã KH";
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Tên";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 130;
            // 
            // COLUMN_NAME_CALL_NUMBER
            // 
            this.COLUMN_NAME_CALL_NUMBER.HeaderText = "Điện thoại";
            this.COLUMN_NAME_CALL_NUMBER.Name = "COLUMN_NAME_CALL_NUMBER";
            this.COLUMN_NAME_CALL_NUMBER.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.HeaderText = "Địa chỉ";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Mặt hàng";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Tới hạn còn (ngày)";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // txt_biggerNumber_due
            // 
            this.txt_biggerNumber_due.Location = new System.Drawing.Point(78, 7);
            this.txt_biggerNumber_due.Name = "txt_biggerNumber_due";
            this.txt_biggerNumber_due.Size = new System.Drawing.Size(122, 20);
            this.txt_biggerNumber_due.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Tới hạn sau";
            // 
            // Form_GoodCustomer
            // 
            this.AcceptButton = this.btn_view_due;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 525);
            this.Controls.Add(this.btn_view_due);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dtg_due_due);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_biggerNumber_due);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_GoodCustomer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Khách hàng tiềm năng";
            ((System.ComponentModel.ISupportInitialize)(this.dtg_due_due)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_view_due;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dtg_due_due;
        private System.Windows.Forms.TextBox txt_biggerNumber_due;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_CALL_NUMBER;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}