﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GSS.Control.Objects;

namespace GSS.View.Menu_Report
{
    public partial class Report_ExpriedDate : Form
    {
        GSS.DataAccessLayer.GSSTableAdapters.DueExpiredCustomerTableAdapter dueDateAdapter = null;
        public Report_ExpriedDate()
        {
            InitializeComponent();
            dueDateAdapter = new GSS.DataAccessLayer.GSSTableAdapters.DueExpiredCustomerTableAdapter();
            txt_biggerNumber.TextChanged += new EventHandler(txt_biggerNumber_TextChanged);
            txt_smallerNumber.TextChanged += new EventHandler(txt_smallerNumber_TextChanged);
        }
        void txt_smallerNumber_TextChanged(object sender, EventArgs e)
        {
            for (int count = 0; count < txt_smallerNumber.Text.Length; count++)
            {
                if (((int)txt_smallerNumber.Text[count]) != '0'
                    && ((int)txt_smallerNumber.Text[count]) != '1'
                    && ((int)txt_smallerNumber.Text[count]) != '2'
                    && ((int)txt_smallerNumber.Text[count]) != '3'
                    && ((int)txt_smallerNumber.Text[count]) != '4'
                    && ((int)txt_smallerNumber.Text[count]) != '5'
                    && ((int)txt_smallerNumber.Text[count]) != '6'
                    && ((int)txt_smallerNumber.Text[count]) != '7'
                    && ((int)txt_smallerNumber.Text[count]) != '8'
                    && ((int)txt_smallerNumber.Text[count]) != '9'

                    )
                {
                    txt_smallerNumber.Text = txt_smallerNumber.Text.Remove(count, 1);
                    count--;
                }

            }

            if (txt_smallerNumber.Text.Trim().Length == 0 || Int32.Parse(txt_smallerNumber.Text.Trim()) == 0)
            {
                txt_smallerNumber.Text = "0";
                return;
            }
        }

        void txt_biggerNumber_TextChanged(object sender, EventArgs e)
        {
            for (int count = 0; count < txt_biggerNumber.Text.Length; count++)
            {
                if (((int)txt_biggerNumber.Text[count]) != '0'
                    && ((int)txt_biggerNumber.Text[count]) != '1'
                    && ((int)txt_biggerNumber.Text[count]) != '2'
                    && ((int)txt_biggerNumber.Text[count]) != '3'
                    && ((int)txt_biggerNumber.Text[count]) != '4'
                    && ((int)txt_biggerNumber.Text[count]) != '5'
                    && ((int)txt_biggerNumber.Text[count]) != '6'
                    && ((int)txt_biggerNumber.Text[count]) != '7'
                    && ((int)txt_biggerNumber.Text[count]) != '8'
                    && ((int)txt_biggerNumber.Text[count]) != '9'

                    )
                {
                    txt_biggerNumber.Text = txt_biggerNumber.Text.Remove(count, 1);
                    count--;
                }

            }

            if (txt_biggerNumber.Text.Trim().Length == 0 || Int32.Parse(txt_biggerNumber.Text.Trim()) == 0)
            {
                txt_biggerNumber.Text = "0";
                return;
            }
        }

        private void btn_view_due_Click(object sender, EventArgs e)
        {
            dtg_due.Rows.Clear();
            DataAccessLayer.GSS.DueExpiredCustomerDataTable dueDates = dueDateAdapter.GetDueExpiredCustomer(
                Definations.EXPIRED_DAY_GAS, -Int32.Parse(txt_smallerNumber.Text), -Int32.Parse(txt_biggerNumber.Text),
                Definations.EXPIRED_DAY_SHELL, -Int32.Parse(txt_smallerNumber.Text), -Int32.Parse(txt_biggerNumber.Text),
                Definations.EXPIRED_DAY_VALVE, -Int32.Parse(txt_smallerNumber.Text), -Int32.Parse(txt_biggerNumber.Text));

            foreach (DataAccessLayer.GSS.DueExpiredCustomerRow dueDate in dueDates)
            {
                object[] row = new object[] { dueDate.cus_Id, dueDate.cus_Name, dueDate.cus_PhoneNumber + ":" + dueDate.cus_HomeNumber, dueDate.cus_Address + " Quận " + dueDate.cus_Distric + " Thành phố " + dueDate.cus_City, dueDate.name, (DateTime.Now - dueDate.date).Days };
                dtg_due.Rows.Add(row);
            }
        }
    }
}
