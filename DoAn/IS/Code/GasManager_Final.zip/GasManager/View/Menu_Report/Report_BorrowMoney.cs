﻿using System.Windows.Forms;
using GSS.DataAccessLayer.GSSTableAdapters;
using System.Collections;

namespace GSS.View.Menu_Report
{
    /// <summary>
    /// Report Borrow Money's form
    /// </summary>
    public partial class Report_BorrowMoney : Form
    {
        private readonly MoneyBorrowTableAdapter _moneyBorrowAdapter = new MoneyBorrowTableAdapter();
        private readonly Hashtable _customerTable = new Hashtable();

        /// <summary>
        /// Initializes a new instance of the "Report_BorrowMoney" form.
        /// </summary>
        public Report_BorrowMoney()
        {
            InitializeComponent();

            DataAccessLayer.GSS.MoneyBorrowDataTable moneyBorrows = _moneyBorrowAdapter.GetBorrowMoney();

            foreach (DataAccessLayer.GSS.MoneyBorrowRow moneyBorrow in moneyBorrows)
            {
                if (_customerTable.Contains(moneyBorrow.cus_Id))
                {
                    ((DataAccessLayer.GSS.MoneyBorrowRow) _customerTable[moneyBorrow.cus_Id]).ode_BorrowMoney +=
                        moneyBorrow.ode_BorrowMoney;
                    ((DataAccessLayer.GSS.MoneyBorrowRow) _customerTable[moneyBorrow.cus_Id]).ode_Date =
                        moneyBorrow.ode_Date;
                }
                else
                {
                    _customerTable.Add(moneyBorrow.cus_Id, moneyBorrow);
                }
            }

            foreach (object key in _customerTable.Keys)
            {
                if (((DataAccessLayer.GSS.MoneyBorrowRow) _customerTable[key]).ode_BorrowMoney != 0)
                {
                    

                    var row = new object[]
                                  {
                                      ((DataAccessLayer.GSS.MoneyBorrowRow) _customerTable[key]).cus_Id,
                                      ((DataAccessLayer.GSS.MoneyBorrowRow) _customerTable[key]).cus_Name,
                                      ((DataAccessLayer.GSS.MoneyBorrowRow) _customerTable[key]).cus_PhoneNumber + ":" +
                                      ((DataAccessLayer.GSS.MoneyBorrowRow) _customerTable[key]).cus_HomeNumber,
                                      ((DataAccessLayer.GSS.MoneyBorrowRow) _customerTable[key]).ode_BorrowMoney,
                                      ((DataAccessLayer.GSS.MoneyBorrowRow) _customerTable[key]).ode_Date
                                  };

                    if (((DataAccessLayer.GSS.MoneyBorrowRow)_customerTable[key]).ode_BorrowMoney > 0)
                        dtg_BorrowMoney.Rows.Add(row);
                    else
                        dtg_BorrowMoney_store.Rows.Add(row);
                }
            }

        }
    }
}