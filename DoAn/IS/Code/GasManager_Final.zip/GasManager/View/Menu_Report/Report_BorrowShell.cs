﻿using System.Windows.Forms;
using GSS.DataAccessLayer.GSSTableAdapters;
using System.Collections;

namespace GSS.View.Menu_Report
{
    /// <summary>
    /// Report Borrow Shell's form
    /// </summary>
    
    public partial class Report_BorrowShell : Form
    {
        private readonly ShellBorrowByGasTableAdapter _shellByGasAdapter = new ShellBorrowByGasTableAdapter();
        private readonly ShellBorrowDirectTableAdapter _shellDirectAdapter = new ShellBorrowDirectTableAdapter();
        private readonly Hashtable _borrowTable = new Hashtable();

        /// <summary>
        /// Initializes a new instance of the "Report_BorrowShell" form.
        /// </summary>
        
        public Report_BorrowShell()
        {
            InitializeComponent();

            DataAccessLayer.GSS.ShellBorrowDirectDataTable shellBorrows = _shellDirectAdapter.GetShellBorrowDirect();

            foreach (DataAccessLayer.GSS.ShellBorrowDirectRow shellBorrow in shellBorrows)
            {
                if (!_borrowTable.ContainsKey(shellBorrow.cus_Id + "|" + shellBorrow.shell_Id))
                {
                    _borrowTable.Add(shellBorrow.cus_Id + "|" + shellBorrow.shell_Id, shellBorrow);
                }
                else
                {
                    ((DataAccessLayer.GSS.ShellBorrowDirectRow)
                     _borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Quantity +=
                        (shellBorrow.ode_Quantity - shellBorrow.ode_ReturnShell);
                    ((DataAccessLayer.GSS.ShellBorrowDirectRow)
                     _borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Date = shellBorrow.ode_Date;
                }
            }

            DataAccessLayer.GSS.ShellBorrowByGasDataTable shellBorrowsByGas = _shellByGasAdapter.GetShellBorrowByGas();

            foreach (DataAccessLayer.GSS.ShellBorrowByGasRow shellBorrow in shellBorrowsByGas)
            {
                if (!_borrowTable.ContainsKey(shellBorrow.cus_Id + "|" + shellBorrow.shell_Id))
                {
                    _borrowTable.Add(shellBorrow.cus_Id + "|" + shellBorrow.shell_Id, shellBorrow);
                }
                else
                {
                    if (
                        _borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id] is
                        DataAccessLayer.GSS.ShellBorrowByGasRow)
                    {
                        ((DataAccessLayer.GSS.ShellBorrowByGasRow)
                         _borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Quantity +=
                            (shellBorrow.ode_Quantity - shellBorrow.ode_ReturnShell);
                        ((DataAccessLayer.GSS.ShellBorrowByGasRow)
                         _borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Date = shellBorrow.ode_Date;
                    }
                    else if (
                        _borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id] is
                        DataAccessLayer.GSS.ShellBorrowDirectRow)
                    {
                        ((DataAccessLayer.GSS.ShellBorrowDirectRow)
                         _borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Quantity +=
                            (shellBorrow.ode_Quantity - shellBorrow.ode_ReturnShell);
                        ((DataAccessLayer.GSS.ShellBorrowDirectRow)
                         _borrowTable[shellBorrow.cus_Id + "|" + shellBorrow.shell_Id]).ode_Date =
                            shellBorrow.ode_Date;
                    }
                }
            }
            foreach (object key in _borrowTable.Keys)
            {
                if (_borrowTable[key] is DataAccessLayer.GSS.ShellBorrowByGasRow)
                {
                    var row = new object[]
                                  {
                                      ((DataAccessLayer.GSS.ShellBorrowByGasRow) _borrowTable[key]).cus_Id,
                                      ((DataAccessLayer.GSS.ShellBorrowByGasRow) _borrowTable[key]).cus_Name,
                                      ((DataAccessLayer.GSS.ShellBorrowByGasRow) _borrowTable[key]).cus_PhoneNumber + ":" +
                                      ((DataAccessLayer.GSS.ShellBorrowByGasRow) _borrowTable[key]).cus_HomeNumber,
                                      ((DataAccessLayer.GSS.ShellBorrowByGasRow) _borrowTable[key]).ode_Quantity -
                                      ((DataAccessLayer.GSS.ShellBorrowByGasRow) _borrowTable[key]).ode_ReturnShell,
                                      ((DataAccessLayer.GSS.ShellBorrowByGasRow) _borrowTable[key]).shell_Name,
                                      ((DataAccessLayer.GSS.ShellBorrowByGasRow) _borrowTable[key]).ode_Date
                                  };
                    if (((DataAccessLayer.GSS.ShellBorrowByGasRow) _borrowTable[key]).ode_Quantity -
                        ((DataAccessLayer.GSS.ShellBorrowByGasRow) _borrowTable[key]).ode_ReturnShell != 0)
                        dtg_BorowShell.Rows.Add(row);
                }
                else if (_borrowTable[key] is DataAccessLayer.GSS.ShellBorrowDirectRow)
                {
                    if (((DataAccessLayer.GSS.ShellBorrowDirectRow) _borrowTable[key]).ode_Quantity -
                        ((DataAccessLayer.GSS.ShellBorrowDirectRow) _borrowTable[key]).ode_ReturnShell != 0)
                    {
                        var row = new object[]
                                      {
                                          ((DataAccessLayer.GSS.ShellBorrowDirectRow) _borrowTable[key]).cus_Id,
                                          ((DataAccessLayer.GSS.ShellBorrowDirectRow) _borrowTable[key]).cus_Name,
                                          ((DataAccessLayer.GSS.ShellBorrowDirectRow) _borrowTable[key]).cus_PhoneNumber +
                                          ":" +
                                          ((DataAccessLayer.GSS.ShellBorrowDirectRow) _borrowTable[key]).cus_HomeNumber,
                                          ((DataAccessLayer.GSS.ShellBorrowDirectRow) _borrowTable[key]).ode_Quantity -
                                          ((DataAccessLayer.GSS.ShellBorrowDirectRow) _borrowTable[key]).ode_ReturnShell,
                                          ((DataAccessLayer.GSS.ShellBorrowDirectRow) _borrowTable[key]).shell_Name,
                                          ((DataAccessLayer.GSS.ShellBorrowDirectRow) _borrowTable[key]).ode_Date
                                      };

                        dtg_BorowShell.Rows.Add(row);
                    }
                }
            }
        }
    }
}