﻿using System;
using System.Windows.Forms;
using GasManager;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;
using GSS.View.Menu_Tool;

namespace GSS.View.Menu_Report
{
    /// <summary>
    ///   Potential customer's form
    /// </summary>
    public partial class Form_GoodCustomer : Form
    {
        private readonly DueExpiredCustomerTableAdapter _dueDateAdapter = new DueExpiredCustomerTableAdapter();

        /// <summary>
        ///   Initializes a new instance of the "Form_GoodCustomer" form.
        /// </summary>
        public Form_GoodCustomer()
        {
            InitializeComponent();
            txt_biggerNumber_due.TextChanged += txt_biggerNumber_due_TextChanged;
            dtg_due_due.CellDoubleClick += dtg_due_due_CellDoubleClick;
        }

        /// <summary>
        ///   Handles the CellDoubleClick event of the DataGridView dtg_due_due.
        /// </summary>
        private void dtg_due_due_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string phoneNumber =
                dtg_due_due.SelectedRows[0].Cells[Definitions.COLUMN_NAME_CALL_NUMBER].Value.ToString().Split(':')[0];
            if (!String.IsNullOrWhiteSpace(phoneNumber))
            {
                var mainForm = (MainForm) Form_CallDiary.GetMainForm(typeof (MainForm));
                if (mainForm != null)
                {
                    if (mainForm.ObjSendMessage == null)
                    {
                        if (mainForm.CheckModem())
                        {
                            mainForm.ObjSendMessage = new Form_SendMessage(mainForm, phoneNumber);
                            mainForm.ShowForm(mainForm.ObjSendMessage);
                        }
                        else
                        {
                            MessageBox.Show(this, Resources.Error_Modem_Connect, Resources.Error_Connect,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        mainForm.UpdateMessagePhone(phoneNumber);
                    }
                }
            }
            else
            {
                MessageBox.Show(Resources.Error_Customer_Miss_Mobile_To_Send_Message, Resources.Error_Send_Message,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        /// <summary>
        ///   Handles the TextChanged event of the textbox txt_biggerNumber_due.
        /// </summary>
        private void txt_biggerNumber_due_TextChanged(object sender, EventArgs e)
        {
            for (int count = 0; count < txt_biggerNumber_due.Text.Length; count++)
            {
                if ((txt_biggerNumber_due.Text[count]) != '0'
                    && (txt_biggerNumber_due.Text[count]) != '1'
                    && (txt_biggerNumber_due.Text[count]) != '2'
                    && (txt_biggerNumber_due.Text[count]) != '3'
                    && (txt_biggerNumber_due.Text[count]) != '4'
                    && (txt_biggerNumber_due.Text[count]) != '5'
                    && (txt_biggerNumber_due.Text[count]) != '6'
                    && (txt_biggerNumber_due.Text[count]) != '7'
                    && (txt_biggerNumber_due.Text[count]) != '8'
                    && (txt_biggerNumber_due.Text[count]) != '9'
                    )
                {
                    txt_biggerNumber_due.Text = txt_biggerNumber_due.Text.Remove(count, 1);
                    count--;
                }
            }

            if (txt_biggerNumber_due.Text.Trim().Length == 0 || Int32.Parse(txt_biggerNumber_due.Text.Trim()) == 0)
            {
                txt_biggerNumber_due.Text = "0";
                return;
            }
        }


        /// <summary>
        ///   Handles the Click event of the button btn_view_due.
        /// </summary>
        private void btn_view_due_Click(object sender, EventArgs e)
        {
            if (txt_biggerNumber_due.Text.Trim().Equals(string.Empty))
            {
                MessageBox.Show(Resources.Msb_Due_Date_Missing, Resources.Msb_Title_Error, MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            dtg_due_due.Rows.Clear();
            var dueDates = _dueDateAdapter.GetDueExpiredCustomer(
                Definitions.EXPIRED_DAY_GAS, Int32.Parse(txt_biggerNumber_due.Text), 0,
                Definitions.EXPIRED_DAY_SHELL, Int32.Parse(txt_biggerNumber_due.Text), 0,
                Definitions.EXPIRED_DAY_VALVE, Int32.Parse(txt_biggerNumber_due.Text), 0);

            foreach (var dueDate in dueDates)
            {
                var row = new object[]
                              {
                                  dueDate.cus_Id, dueDate.cus_Name,
                                  dueDate.cus_HomeNumber + ":" + dueDate.cus_PhoneNumber,
                                  dueDate.cus_Address + " - " + dueDate.cus_Distric + " - " + dueDate.cus_City,
                                  dueDate.name, (dueDate.date - DateTime.Now).Days
                              };
                String homeNumber = String.IsNullOrEmpty(dueDate.cus_PhoneNumber)
                                        ? String.Empty
                                        : dueDate.cus_PhoneNumber;
                String phoneNumber = String.IsNullOrEmpty(dueDate.cus_HomeNumber)
                                         ? String.Empty
                                         : dueDate.cus_HomeNumber;
                String telephone = homeNumber + ":" + phoneNumber;
                if (String.IsNullOrEmpty(homeNumber) || String.IsNullOrEmpty(phoneNumber))
                    row[2] = telephone.Replace(":", "");
                
                dtg_due_due.Rows.Add(row);
            }
        }
    }
}