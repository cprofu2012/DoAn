﻿using System;
using System.Windows.Forms;
using GSS.Control.Excel_Object;
using GSS.DataAccessLayer.GSSTableAdapters;

namespace GSS.View.Menu_Report
{
    /// <summary>
    /// Report sell's form
    /// </summary>
    public partial class Report_Sell : Form
    {
        private readonly GasOrdersTableAdapter _gasorderAdapter = new GasOrdersTableAdapter();
        private readonly ShellOrdersTableAdapter _shellorderAdapter = new ShellOrdersTableAdapter();
        private readonly ValveOrdersTableAdapter _valveorderAdapter = new ValveOrdersTableAdapter();

        /// <summary>
        ///   Initializes a new instance of the "Report_Sell" form.
        /// </summary>
        public Report_Sell()
        {
            InitializeComponent();
            GetReport();
        }

        /// <summary>
        ///   Gets reports.
        /// </summary>
        private void GetReport()
        {
            dtg_report.Rows.Clear();
            var gasses = _gasorderAdapter.GetGasOrders();
            var valves = _valveorderAdapter.GetValveOrders();
            var shelles = _shellorderAdapter.GetShellOrders();

            foreach (var gas in gasses)
            {
                dtg_report.Rows.Add(new object[]
                                        {
                                            gas.ode_Date, gas.gas_Name, gas.ode_Quantity, gas.ode_ImportPrice,
                                            gas.ode_PaidMoney + gas.ode_BorrowMoney,
                                            gas.ode_PaidMoney + gas.ode_BorrowMoney - gas.ode_ImportPrice
                                        });
            }
            foreach (var valve in valves)
            {
                dtg_report.Rows.Add(new object[]
                                        {
                                            valve.ode_Date, valve.valve_Name, valve.ode_Quantity, valve.ode_ImportPrice,
                                            valve.ode_PaidMoney + valve.ode_BorrowMoney,
                                            valve.ode_PaidMoney + valve.ode_BorrowMoney - valve.ode_ImportPrice
                                        });
            }
            foreach (var shell in shelles)
            {
                dtg_report.Rows.Add(new object[]
                                        {
                                            shell.ode_Date, shell.shell_Name, shell.ode_Quantity, shell.ode_ImportPrice,
                                            shell.ode_PaidMoney + shell.ode_BorrowMoney,
                                            shell.ode_PaidMoney + shell.ode_BorrowMoney - shell.ode_ImportPrice
                                        });
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_Select.
        /// </summary>
        private void btn_Select_Click(object sender, EventArgs e)
        {
            dtg_report.Rows.Clear();
            var from =
                dtp_From.Value.AddHours(0 - dtp_From.Value.Hour).
                    AddMinutes(0 - dtp_From.Value.Minute).
                    AddSeconds(0 - dtp_From.Value.Second);
            var to =
                dtp_To.Value.AddHours(0 - dtp_To.Value.Hour).
                    AddMinutes(0 - dtp_To.Value.Minute).
                    AddSeconds(0 - dtp_To.Value.Second).
                    AddDays(1);

            var gasses = _gasorderAdapter.GetDataByTwoDate(from, to);
            var valves = _valveorderAdapter.GetDataByTwoDate(from, to);
            var shelles = _shellorderAdapter.GetDataByTwoDate(from, to);

            foreach (var gas in gasses)
            {
                dtg_report.Rows.Add(new object[]
                                        {
                                            gas.ode_Date, gas.gas_Name, gas.ode_Quantity, gas.ode_ImportPrice,
                                            gas.ode_PaidMoney + gas.ode_BorrowMoney,
                                            gas.ode_PaidMoney + gas.ode_BorrowMoney - gas.ode_ImportPrice
                                        });
            }
            foreach (var valve in valves)
            {
                dtg_report.Rows.Add(new object[]
                                        {
                                            valve.ode_Date, valve.valve_Name, valve.ode_Quantity, valve.ode_ImportPrice,
                                            valve.ode_PaidMoney + valve.ode_BorrowMoney,
                                            valve.ode_PaidMoney + valve.ode_BorrowMoney - valve.ode_ImportPrice
                                        });
            }
            foreach (var shell in shelles)
            {
                dtg_report.Rows.Add(new object[]
                                        {
                                            shell.ode_Date, shell.shell_Name, shell.ode_Quantity, shell.ode_ImportPrice,
                                            shell.ode_PaidMoney + shell.ode_BorrowMoney,
                                            shell.ode_PaidMoney + shell.ode_BorrowMoney - shell.ode_ImportPrice
                                        });
            }
        }

        /// <summary>
        ///   Handles the Click event of the button export to excel.
        /// </summary>
        private void button2_Click(object sender, EventArgs e)
        {
            var excellApp = new CreateExcelDoc();

            excellApp.CreateHeaders(2, 2, "Ngày", "B2", "B2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(2, 3, "Tên hàng", "C2", "C2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(2, 4, "Số lượng", "D2", "D2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(2, 5, "Giá nhập", "E2", "E2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(2, 6, "Doanh thu", "F2", "F2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(2, 7, "Lãi", "G2", "G2", 1, "WHITE", true, 15, "n");

            int currRow = 3;
            Int64 importSum = 0;
            Int64 revenueSum = 0;
            Int64 profitSum = 0;

            foreach (DataGridViewRow row in dtg_report.Rows)
            {
                excellApp.AddData(currRow, 2, row.Cells[0].Value.ToString(), "B2", "B2", "#,##0");
                excellApp.AddData(currRow, 3, row.Cells[1].Value.ToString(), "C2", "C2", "#,##0");
                excellApp.AddData(currRow, 4, row.Cells[2].Value.ToString(), "D2", "D2", "#,##0");
                excellApp.AddData(currRow, 5, row.Cells[3].Value.ToString(), "E2", "E2", "#,##0");
                excellApp.AddData(currRow, 6, row.Cells[4].Value.ToString(), "F2", "F2", "#,##0");
                excellApp.AddData(currRow, 7, row.Cells[5].Value.ToString(), "G2", "G2", "#,##0");
                importSum += Int32.Parse(row.Cells[3].Value.ToString());
                revenueSum += Int32.Parse(row.Cells[4].Value.ToString());
                profitSum += Int32.Parse(row.Cells[5].Value.ToString());
                currRow++;
            }
            currRow++;


            excellApp.CreateHeaders(currRow, 2, "Tổng", "B2", "B2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(currRow, 5, importSum.ToString(), "E2", "E2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(currRow, 6, revenueSum.ToString(), "F2", "F2", 1, "WHITE", true, 15, "n");
            excellApp.CreateHeaders(currRow, 7, profitSum.ToString(), "G2", "G2", 1, "WHITE", true, 15, "n");
        }

        /// <summary>
        ///   Handles the changed event of the DateTimePicker dtp_from.
        /// </summary>
        private void dtp_from_changed(object sender, EventArgs e)
        {
            if (dtp_To.Value.CompareTo(dtp_From.Value) < 0)
            {
                dtp_To.Value = dtp_From.Value;
            }
        }

        /// <summary>
        ///   Handles the changed event of the DateTimePicker dtp_to.
        /// </summary>
        private void dtp_to_changed(object sender, EventArgs e)
        {
            if (dtp_To.Value.CompareTo(dtp_From.Value) < 0)
            {
                dtp_To.Value = dtp_From.Value;
            }
        }
    }
}