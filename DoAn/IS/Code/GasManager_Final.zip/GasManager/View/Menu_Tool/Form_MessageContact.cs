﻿using System;
using System.Drawing;
using System.Windows.Forms;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;

namespace GSS.View.Menu_Tool
{
    /// <summary>
    /// Get contacts to send message
    /// </summary>
    public partial class Form_MessageContact : Form
    {
        #region Delegates

        public delegate void SelectContactDelegate(string contacts);

        #endregion

        private readonly GSS_CustomerTableAdapter _customerAdapter = new GSS_CustomerTableAdapter();

        public SelectContactDelegate SelectContacts;

        /// <summary>
        /// Initializes a new instance of the "Form_MessageContact" form.
        /// </summary>
        public Form_MessageContact()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Load event of the MessageContact form.
        /// </summary>
        private void MessageContact_Load(object sender, EventArgs e)
        {
            var rect = dtg_Contact.GetCellDisplayRectangle(0, -1, true);
            rect.X = rect.Location.X + (rect.Width/4);

            var checkboxHeader = new CheckBox
                                     {
                                         Name = Definitions.COLUMN_NAME_CHECKBOX,
                                         Size = new Size(18, 18),
                                         Location = rect.Location
                                     };
            checkboxHeader.CheckedChanged += checkboxHeader_CheckedChanged;

            dtg_Contact.Controls.Add(checkboxHeader);

            var customers = _customerAdapter.GetCustomers();


            foreach (var customer in customers)
            {
                if (!customer.cus_PhoneNumber.Trim().Equals(string.Empty))
                {
                    var row = new object[] {false, customer.cus_Name, customer.cus_PhoneNumber};
                    dtg_Contact.Rows.Add(row);
                }
            }
            foreach (DataGridViewColumn column in dtg_Contact.Columns)
            {
                column.HeaderCell.Style.WrapMode = DataGridViewTriState.True;
            }
        }

        /// <summary>
        /// Handles the CheckedChanged event of the checkboxHeader column.
        /// </summary>
        private void checkboxHeader_CheckedChanged(object sender, EventArgs e)
        {
            for (var i = 0; i < dtg_Contact.RowCount; i++)
            {
                dtg_Contact[0, i].Value =
                    ((CheckBox) dtg_Contact.Controls.Find(Definitions.COLUMN_NAME_CHECKBOX, true)[0]).Checked;
            }
            dtg_Contact.EndEdit();
        }

        /// <summary>
        /// Handles the Click event of the button Select.
        /// </summary>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            var phone = string.Empty;
            for (var i = 0; i < dtg_Contact.RowCount; i++)
            {
                if ((bool) dtg_Contact[0, i].Value)
                {
                    if (!phone.Equals(string.Empty))
                        phone += ";";
                    phone += dtg_Contact[2, i].FormattedValue;
                }
            }
            if (!phone.Equals(string.Empty))
            {
                SelectContacts(phone);
            }
        }

        /// <summary>
        /// Handles the CellClick event of the datagridview Contact.
        /// </summary>
        private void dtg_Contact_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                dtg_Contact[0, e.RowIndex].Value = !(bool) dtg_Contact[0, e.RowIndex].Value;
                dtg_Contact.EndEdit();
            }
        }
    }
}