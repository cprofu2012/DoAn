﻿using System;
using System.Windows.Forms;
using GasManager;
using GSS.Properties;

namespace GSS.View.Menu_Tool
{
    /// <summary>
    /// Send message to customers
    /// </summary>
    public partial class Form_SendMessage : Popup_Form
    {
        /// <summary>
        /// Initializes a new instance of the "Form_SendMessage"/> form.
        /// </summary>
        /// <param name="parent">The parent.</param>
        /// <param name="phone">The phone.</param>
        public Form_SendMessage(MainForm parent, string phone)
        {
            InitializeComponent();
            _parent = parent;
            _parent._modem.SMSDelegate += SMSResponse;
            _parent.UpdateMessagePhone += UpdatePhoneNo;
            UpdatePhoneNo(phone);
        }

        /// <summary>
        /// Handles the TextChanged event of the textbox Content.
        /// </summary>
        private void txt_Content_TextChanged(object sender, EventArgs e)
        {
            int remain = 160 - txt_Content.TextLength;
            lblStatus.Text = string.Format(Resources.SendMessage_Remain_char, remain);
        }

        /// <summary>
        /// Handles the Click event of the button Send.
        /// </summary>
        private void btSend_Click(object sender, EventArgs e)
        {
            if (txt_PhoneNo.Text.Trim().Length == 0)
                lblStatus.Text = Resources.Error_Missing_Phone_No;
            else if (txt_Content.Text.Trim().Length == 0)
                lblStatus.Text = Resources.Error_Missing_Content;
            else
            {
                _parent._modem.SendMultiSMS(txt_Content.Text, txt_PhoneNo.Text);
            }
        }

        /// <summary>
        /// Handles the FormClosed event of the SendMessage form.
        /// </summary>
        private void SendMessage_FormClosed(object sender, FormClosedEventArgs e)
        {
            _parent._modem.SMSDelegate -= SMSResponse;
            _parent.UpdateMessagePhone -= UpdatePhoneNo;
            _parent.ObjSendMessage = null;
        }

        /// <summary>
        /// SMSs the response.
        /// </summary>
        /// <param name="responseMessage">The response message.</param>
        private void SMSResponse(string responseMessage)
        {
            SetText(responseMessage);
        }

        /// <summary>
        /// Delegate update text for the lblStatus label
        /// </summary>
        /// <param name="message">The message.</param>
        private delegate void SetTextCallback(string message);

        /// <summary>
        /// Sets text for the lblStatus label.
        /// </summary>
        /// <param name="message">The message.</param>
        private void SetText(string message)
        {
            if (lblStatus.InvokeRequired)
            {
                SetTextCallback d = SetText;
                Invoke(d, new object[] {message});
            }
            else
            {
                lblStatus.Text = message;
            }
        }

        
        /// <summary>
        /// Updates the phone number.
        /// </summary>
        /// <param name="phoneNo">The message.</param>
        private void UpdatePhoneNo(string phoneNo)
        {
            if (lblStatus.InvokeRequired)
            {
                SetTextCallback d = UpdatePhoneNo;
                Invoke(d, new object[] { phoneNo });
            }
            else
            {
                txt_PhoneNo.Text = phoneNo;
            }
        }

        /// <summary>
        /// Handles the Click event of the button Contact.
        /// </summary>
        private void btnContact_Click(object sender, EventArgs e)
        {
            var contact = new Form_MessageContact {SelectContacts = UpdatePhoneNo, Left = this.Right,Top = this.Top};
            contact.ShowDialog();
        }
    }
}