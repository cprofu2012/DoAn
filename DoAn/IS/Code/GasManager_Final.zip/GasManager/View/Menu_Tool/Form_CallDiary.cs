﻿using System;
using System.Collections;
using System.Windows.Forms;
using GasManager;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_Tool
{
    /// <summary>
    ///   Call Diary form
    /// </summary>
    public partial class Form_CallDiary : Form
    {
        private readonly Hashtable _usersHash = new Hashtable();

        /// <summary>
        ///   Initializes a new instance of the "Form_CallDiary" form.
        /// </summary>
        public Form_CallDiary()
        {
            InitializeComponent();
            GetUsers();

            var callAdapter = new GSS_CallTableAdapter();
            var calls = callAdapter.GetTop100Call();
            dtg_calldiary.SelectionChanged += dtg_calldiary_SelectionChanged;


            foreach (var call in calls)
            {
                var row = new object[]
                              {call.call_Number, call.call_Time.ToString(), _usersHash[call.user_Id].ToString(), ""};
                dtg_calldiary.Rows.Add(row);

                if (call.call_status == MainForm.CALL_STATUS_ANSWER)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[0];
                else if (call.call_status == MainForm.CALL_STATUS_MISSING)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[1];
                else if (call.call_status == MainForm.CALL_STATUS_CALL)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[2];
            }
        }

        /// <summary>
        ///   Initializes a new instance of the "Form_CallDiary" form.
        /// </summary>
        /// <param name = "number">The number to get call diary.</param>
        public Form_CallDiary(String number)
        {
            InitializeComponent();
            dtg_calldiary.SelectionChanged += dtg_calldiary_SelectionChanged;
            GetUsers();

            var callAdapter = new GSS_CallTableAdapter();
            var calls = callAdapter.GetCallByNumber(number);


            foreach (var call in calls)
            {
                var row = new object[]
                              {call.call_Number, call.call_Time.ToString(), _usersHash[call.user_Id].ToString(), ""};
                dtg_calldiary.Rows.Add(row);

                if (call.call_status == MainForm.CALL_STATUS_ANSWER)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[0];
                else if (call.call_status == MainForm.CALL_STATUS_MISSING)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[1];
                else if (call.call_status == MainForm.CALL_STATUS_CALL)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[2];
            }
        }

        /// <summary>
        ///   Handles the SelectionChanged event of the datagridview dtg_calldiary.
        /// </summary>
        private void dtg_calldiary_SelectionChanged(object sender, EventArgs e)
        {
            if (dtg_calldiary.SelectedRows.Count == 1)
            {
                btn_call.Enabled = true;
                btn_message.Enabled = true;
            }
            else
            {
                btn_call.Enabled = false;
                btn_message.Enabled = false;
            }
        }

        /// <summary>
        ///   Gets the users.
        /// </summary>
        private void GetUsers()
        {
            var userAdapter = new GSS_UserTableAdapter();
            var users = userAdapter.GetUsers();


            foreach (var user in users)
            {
                _usersHash.Add(user.user_Id, user.user_name);
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_call.
        /// </summary>
        private void btn_call_Click(object sender, EventArgs e)
        {
            var phoneNumber =
                dtg_calldiary.SelectedRows[0].Cells[Definitions.COLUMN_NAME_CALL_NUMBER].Value.
                    ToString().Trim();
            MainForm mainForm = (MainForm) GetMainForm(typeof (MainForm));
            if (mainForm != null)
            {
                if (mainForm.ObjFormCall == null)
                {
                    if (mainForm.CheckModem())
                    {
                        mainForm.ObjFormCall = new Form_Call(mainForm, phoneNumber);
                        mainForm.ShowForm(mainForm.ObjFormCall);
                    }
                    else
                    {
                        MessageBox.Show(this, Resources.Error_Modem_Connect, Resources.Error_Connect,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
                else mainForm.UpdateCallNo(phoneNumber);
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_message.
        /// </summary>
        private void btn_message_Click(object sender, EventArgs e)
        {
            var phoneNumber =
                dtg_calldiary.SelectedRows[0].Cells[Definitions.COLUMN_NAME_CALL_NUMBER].Value.
                    ToString().Trim();
            MainForm mainForm = (MainForm) GetMainForm(typeof (MainForm));
            if (mainForm != null)
            {
                if (mainForm.ObjSendMessage == null)
                {
                    if (mainForm.CheckModem())
                    {
                        mainForm.ObjSendMessage = new Form_SendMessage(mainForm, phoneNumber);
                        mainForm.ShowForm(mainForm.ObjSendMessage);
                    }
                    else
                    {
                        MessageBox.Show(this, Resources.Error_Modem_Connect, Resources.Error_Connect,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
                else
                {
                    mainForm.UpdateMessagePhone(phoneNumber);
                }
            }
        }

        /// <summary>
        ///   Gets the opening main form.
        /// </summary>
        /// <param name = "formType">Type of the form.</param>
        /// <returns></returns>
        public static Form GetMainForm(Type formType)
        {
            foreach (Form openForm in Application.OpenForms)
            {
                if (openForm.GetType() == formType)
                    return openForm;
            }

            return null;
        }
    }
}