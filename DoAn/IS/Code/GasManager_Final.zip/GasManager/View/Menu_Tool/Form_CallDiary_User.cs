﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GasManager;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_Tool
{
    public partial class Form_CallDiary_User : Form
    {
        private readonly Hashtable _usersHash = new Hashtable();
        MainForm parent = null;
        public Form_CallDiary_User()
        {
            InitializeComponent();
            GetUsers();

            var callAdapter = new GSS_CallTableAdapter();
            var calls = callAdapter.GetTop100Call();
            dtg_calldiary.SelectionChanged += dtg_calldiary_SelectionChanged;


            foreach (var call in calls)
            {
                var row = new object[] { call.call_Number, call.call_Time.ToString(), ((GSS.DataAccessLayer.GSS.GSS_UserRow)_usersHash[call.user_Id]).user_name.ToString(), "" };
                dtg_calldiary.Rows.Add(row);

                if (call.call_status == MainForm.CALL_STATUS_ANSWER)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[0];
                else if (call.call_status == MainForm.CALL_STATUS_MISSING)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[1];
                else if (call.call_status == MainForm.CALL_STATUS_CALL)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[2];
            }
        }

        
        /// <summary>
        ///   Initializes a new instance of the "Form_CallDiary" form.
        /// </summary>
        /// <param name = "number">The number to get call diary.</param>
        public Form_CallDiary_User(MainForm _parent, String number)
        {
            InitializeComponent();
            parent = _parent;
            dtg_calldiary.SelectionChanged += dtg_calldiary_SelectionChanged;
            GetUsers();

            var callAdapter = new GSS_CallTableAdapter();
            var calls = callAdapter.GetCallByNumber(number);
            int user_Id = -1;

            foreach (var call in calls)
            {
                var row = new object[] { call.call_Number, call.call_Time.ToString(), ((GSS.DataAccessLayer.GSS.GSS_UserRow)_usersHash[call.user_Id]).user_name.ToString(), "" };
                dtg_calldiary.Rows.Add(row);

                if (call.call_status == MainForm.CALL_STATUS_ANSWER)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[0];
                else if (call.call_status == MainForm.CALL_STATUS_MISSING)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[1];
                else if (call.call_status == MainForm.CALL_STATUS_CALL)
                    (dtg_calldiary.Rows[dtg_calldiary.Rows.Count - 1].Cells[
                        Definitions.COLUMN_NAME_CALL_STATUS]).Value =
                        imageList1.Images[2];
                user_Id = call.user_Id;
            }

            foreach (var key in parent._userHashTable.Keys )
            {
                 if(!((GSS.DataAccessLayer.GSS.GSS_CustomerRow)parent._userHashTable[key]).IsNull("cus_HomeNumber") && ((GSS.DataAccessLayer.GSS.GSS_CustomerRow)parent._userHashTable[key]).cus_HomeNumber == number)
                     LoadOrder(((GSS.DataAccessLayer.GSS.GSS_CustomerRow)parent._userHashTable[key]).cus_Id);
                 else if (!((GSS.DataAccessLayer.GSS.GSS_CustomerRow)parent._userHashTable[key]).IsNull("cus_PhoneNumber") && ((GSS.DataAccessLayer.GSS.GSS_CustomerRow)parent._userHashTable[key]).cus_PhoneNumber == number)
                 {
                     LoadOrder(((GSS.DataAccessLayer.GSS.GSS_CustomerRow)parent._userHashTable[key]).cus_Id);
                 }
            }

            

        }

        /// <summary>
        ///   Handles the SelectionChanged event of the datagridview dtg_calldiary.
        /// </summary>
        private void dtg_calldiary_SelectionChanged(object sender, EventArgs e)
        {
            if (dtg_calldiary.SelectedRows.Count == 1)
            {
                btn_call.Enabled = true;
                btn_message.Enabled = true;
            }
            else
            {
                btn_call.Enabled = false;
                btn_message.Enabled = false;
            }
        }

        /// <summary>
        ///   Gets the users.
        /// </summary>
        private void GetUsers()
        {
            var userAdapter = new GSS_UserTableAdapter();
            var users = userAdapter.GetUsers();


            foreach (GSS.DataAccessLayer.GSS.GSS_UserRow user in users)
            {
                if (!_usersHash.ContainsKey(user.user_Id))
                    _usersHash.Add(user.user_Id, user);
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_call.
        /// </summary>
        private void btn_call_Click(object sender, EventArgs e)
        {
            var phoneNumber =
                dtg_calldiary.SelectedRows[0].Cells[Definitions.COLUMN_NAME_CALL_NUMBER].Value.
                    ToString().Trim();
            MainForm mainForm = (MainForm) GetMainForm(typeof (MainForm));
            if (mainForm != null)
            {
                if (mainForm.ObjFormCall == null)
                {
                    if (mainForm.CheckModem())
                    {
                        mainForm.ObjFormCall = new Form_Call(mainForm, phoneNumber);
                        mainForm.ShowForm(mainForm.ObjFormCall);
                    }
                    else
                    {
                        MessageBox.Show(this, Resources.Error_Modem_Connect, Resources.Error_Connect,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
                else mainForm.UpdateCallNo(phoneNumber);
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_message.
        /// </summary>
        private void btn_message_Click(object sender, EventArgs e)
        {
            var phoneNumber =
                dtg_calldiary.SelectedRows[0].Cells[Definitions.COLUMN_NAME_CALL_NUMBER].Value.
                    ToString().Trim();
            MainForm mainForm = (MainForm) GetMainForm(typeof (MainForm));
            if (mainForm != null)
            {
                if (mainForm.ObjSendMessage == null)
                {
                    if (mainForm.CheckModem())
                    {
                        mainForm.ObjSendMessage = new Form_SendMessage(mainForm, phoneNumber);
                        mainForm.ShowForm(mainForm.ObjSendMessage);
                    }
                    else
                    {
                        MessageBox.Show(this, Resources.Error_Modem_Connect, Resources.Error_Connect,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
                else
                {
                    mainForm.UpdateMessagePhone(phoneNumber);
                }
            }
        }

        /// <summary>
        ///   Gets the opening main form.
        /// </summary>
        /// <param name = "formType">Type of the form.</param>
        /// <returns></returns>
        public static Form GetMainForm(Type formType)
        {
            foreach (Form openForm in Application.OpenForms)
            {
                if (openForm.GetType() == formType)
                    return openForm;
            }

            return null;
        }

        private void LoadOrder(int CustomerId)
        {
        //    label1.Text += CustomerId;
            //dtg_Order.Rows.Clear();
            //MessageBox.Show("LoadOrder : " + CustomerId + "");
            // Load Gas Valve item------------------------------------------------------------------
            GSS.DataAccessLayer.GSS.GSS_GasDataTable gases = parent._gasAdapter.GetGass();
            GSS.DataAccessLayer.GSS.GSS_OrderDataTable _orders = parent._orderAdapter.GetOrderByCustomerId(CustomerId);
            // -------------------------------------------------------------------------------
            MessageBox.Show(_orders.Count + "");

            GSS.DataAccessLayer.GSS.GSS_CustomerRow customer;
            foreach (GSS.DataAccessLayer.GSS.GSS_OrderRow order in _orders)
            {

                try
                {
                    // Find Customer-----------------------------------------------------
                    customer = (GSS.DataAccessLayer.GSS.GSS_CustomerRow)parent._userHashTable[order.ode_CustomerId.ToString()];
                    //------------------------------------------------------------------
                }
                catch (Exception)
                {
                    continue;
                }



                // Find Good -------------------------------------------------------
                String goodName = String.Empty;

                if (!order.IsNull(Definitions.ORDER_GAS_ID))
                {
                    for (int count = 0; count < parent.GasTable.Rows.Count; count++)
                    {
                        if (Int32.Parse(parent.GasTable.Rows[count][1].ToString()) == order.ode_GasId)
                        {
                            goodName = parent.GasTable.Rows[count][0].ToString();
                            break;
                        }
                    }
                }
                else if (!order.IsNull(Definitions.ORDER_VALVE_ID))
                {
                    for (int count = 0; count < parent.ValveTable.Rows.Count; count++)
                    {
                        if (Int32.Parse(parent.ValveTable.Rows[count][1].ToString()) == order.ode_ValveId)
                        {
                            goodName = parent.ValveTable.Rows[count][0].ToString();
                            break;
                        }
                    }
                }
                else if (!order.IsNull(Definitions.ORDER_SHELL_ID))
                {
                    for (int count = 0; count < parent.ShellTable.Rows.Count; count++)
                    {
                        if (Int32.Parse(parent.ShellTable.Rows[count][1].ToString()) == order.ode_ShellId)
                        {
                            goodName = parent.ShellTable.Rows[count][0].ToString();
                            break;
                        }
                    }
                }
                //------------------------------------------------------------------


                var row = new object[] { customer.cus_Name, goodName, order.ode_Quantity, order.ode_Date, order.ode_PaidMoney };
                dtg_Order.Rows.Add(row);

            }
        }
    }
}
