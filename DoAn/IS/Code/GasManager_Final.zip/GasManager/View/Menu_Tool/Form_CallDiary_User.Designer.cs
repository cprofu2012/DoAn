﻿namespace GSS.View.Menu_Tool
{
    partial class Form_CallDiary_User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_CallDiary_User));
            this.btn_call = new System.Windows.Forms.Button();
            this.btn_message = new System.Windows.Forms.Button();
            this.dtg_calldiary = new System.Windows.Forms.DataGridView();
            this.COLUMN_NAME_CALL_NUMBER = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_CALL_TIME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_CALL_USER = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_CALL_STATUS = new System.Windows.Forms.DataGridViewImageColumn();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dtg_Order = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_calldiary)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Order)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_call
            // 
            this.btn_call.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_call.Enabled = false;
            this.btn_call.Image = ((System.Drawing.Image)(resources.GetObject("btn_call.Image")));
            this.btn_call.Location = new System.Drawing.Point(551, 284);
            this.btn_call.Name = "btn_call";
            this.btn_call.Size = new System.Drawing.Size(40, 40);
            this.btn_call.TabIndex = 5;
            this.btn_call.Text = " ";
            this.btn_call.UseVisualStyleBackColor = true;
            this.btn_call.Click += new System.EventHandler(this.btn_call_Click);
            // 
            // btn_message
            // 
            this.btn_message.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_message.Enabled = false;
            this.btn_message.Image = ((System.Drawing.Image)(resources.GetObject("btn_message.Image")));
            this.btn_message.Location = new System.Drawing.Point(597, 284);
            this.btn_message.Name = "btn_message";
            this.btn_message.Size = new System.Drawing.Size(40, 40);
            this.btn_message.TabIndex = 4;
            this.btn_message.Text = " ";
            this.btn_message.UseVisualStyleBackColor = true;
            this.btn_message.Click += new System.EventHandler(this.btn_message_Click);
            // 
            // dtg_calldiary
            // 
            this.dtg_calldiary.AllowUserToAddRows = false;
            this.dtg_calldiary.AllowUserToDeleteRows = false;
            this.dtg_calldiary.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_calldiary.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_calldiary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_calldiary.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.COLUMN_NAME_CALL_NUMBER,
            this.COLUMN_NAME_CALL_TIME,
            this.COLUMN_NAME_CALL_USER,
            this.COLUMN_NAME_CALL_STATUS});
            this.dtg_calldiary.Location = new System.Drawing.Point(0, 0);
            this.dtg_calldiary.Name = "dtg_calldiary";
            this.dtg_calldiary.ReadOnly = true;
            this.dtg_calldiary.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_calldiary.Size = new System.Drawing.Size(637, 278);
            this.dtg_calldiary.TabIndex = 3;
            // 
            // COLUMN_NAME_CALL_NUMBER
            // 
            this.COLUMN_NAME_CALL_NUMBER.HeaderText = "Số điện thoại";
            this.COLUMN_NAME_CALL_NUMBER.Name = "COLUMN_NAME_CALL_NUMBER";
            this.COLUMN_NAME_CALL_NUMBER.ReadOnly = true;
            this.COLUMN_NAME_CALL_NUMBER.Width = 150;
            // 
            // COLUMN_NAME_CALL_TIME
            // 
            this.COLUMN_NAME_CALL_TIME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.COLUMN_NAME_CALL_TIME.HeaderText = "Thời điểm";
            this.COLUMN_NAME_CALL_TIME.MinimumWidth = 150;
            this.COLUMN_NAME_CALL_TIME.Name = "COLUMN_NAME_CALL_TIME";
            this.COLUMN_NAME_CALL_TIME.ReadOnly = true;
            this.COLUMN_NAME_CALL_TIME.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // COLUMN_NAME_CALL_USER
            // 
            this.COLUMN_NAME_CALL_USER.HeaderText = "Nhân viên";
            this.COLUMN_NAME_CALL_USER.Name = "COLUMN_NAME_CALL_USER";
            this.COLUMN_NAME_CALL_USER.ReadOnly = true;
            this.COLUMN_NAME_CALL_USER.Width = 200;
            // 
            // COLUMN_NAME_CALL_STATUS
            // 
            this.COLUMN_NAME_CALL_STATUS.HeaderText = "Trạng thái";
            this.COLUMN_NAME_CALL_STATUS.Name = "COLUMN_NAME_CALL_STATUS";
            this.COLUMN_NAME_CALL_STATUS.ReadOnly = true;
            this.COLUMN_NAME_CALL_STATUS.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.COLUMN_NAME_CALL_STATUS.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.COLUMN_NAME_CALL_STATUS.Width = 90;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "3456.png");
            this.imageList1.Images.SetKeyName(1, "1234.png");
            this.imageList1.Images.SetKeyName(2, "2345.png");
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(645, 350);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dtg_Order);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(637, 324);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Giao dịch";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dtg_Order
            // 
            this.dtg_Order.AllowUserToAddRows = false;
            this.dtg_Order.AllowUserToDeleteRows = false;
            this.dtg_Order.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_Order.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_Order.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_Order.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.dtg_Order.Location = new System.Drawing.Point(0, 0);
            this.dtg_Order.Name = "dtg_Order";
            this.dtg_Order.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_Order.Size = new System.Drawing.Size(637, 324);
            this.dtg_Order.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "Tên";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Hàng hóa";
            this.Column2.Name = "Column2";
            this.Column2.Width = 150;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Số lượng";
            this.Column3.Name = "Column3";
            this.Column3.Width = 80;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Ngày";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Tiền trả";
            this.Column5.Name = "Column5";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dtg_calldiary);
            this.tabPage1.Controls.Add(this.btn_call);
            this.tabPage1.Controls.Add(this.btn_message);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(637, 324);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Điện thoại";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // Form_CallDiary_User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 374);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_CallDiary_User";
            this.Text = "Nhật ký";
            ((System.ComponentModel.ISupportInitialize)(this.dtg_calldiary)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Order)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_call;
        private System.Windows.Forms.Button btn_message;
        private System.Windows.Forms.DataGridView dtg_calldiary;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_CALL_NUMBER;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_CALL_TIME;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_CALL_USER;
        private System.Windows.Forms.DataGridViewImageColumn COLUMN_NAME_CALL_STATUS;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dtg_Order;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
    }
}