﻿using System;
using System.Windows.Forms;
using GasManager;
using GSS.Properties;

namespace GSS.View.Menu_Tool
{
    /// <summary>
    ///   Using this form to make a call to customer
    /// </summary>
    public partial class Form_Call : Popup_Form
    {
        private DateTime _da;
        private string _phone = "";

        /// <summary>
        ///   Initializes a new instance of the "Form_Call" class.
        /// </summary>
        /// <param name = "parent">The main form</param>
        /// <param name = "phoneNo">The phone number to call (if exist).</param>
        public Form_Call(MainForm parent, string phoneNo)
        {
            InitializeComponent();
            _parent = parent;
            _parent._modem.CallFormDelegate += CallState;
            _parent.UpdateCallNo += UpdatePhoneNo;
            UpdatePhoneNo(phoneNo);
        }

        /// <summary>
        ///   Handles the Click event of the button btn_Call.
        /// </summary>
        private void btn_Call_Click(object sender, EventArgs e)
        {
            if (txt_PhoneNo.Text.Trim().Length == 0)
            {
                SetText(Resources.Error_Missing_Phone_No, "");
            }
            else
            {
                _phone = txt_PhoneNo.Text;
                _parent._modem.MakeCall(_phone);
                timerCall.Start();
                _parent.InsertCall(_phone);
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btFinish.
        /// </summary>
        private void btFinish_Click(object sender, EventArgs e)
        {
            try
            {
                _parent._modem.HangUpCall();
            }
            catch (Exception ex)
            {
                lblStatus.Text = ex.Message;
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btnContact.
        /// </summary>
        private void btnContact_Click(object sender, EventArgs e)
        {
            var contact = new Form_CallContact {SelectContacts = UpdatePhoneNo, Left = Right, Top = Top};
            contact.ShowDialog();
        }

        /// <summary>
        ///   State of the call: update status, end call.
        /// </summary>
        /// <param name = "status">The status.</param>
        /// <param name = "phoneNo">The phone no.</param>
        private void CallState(string status, string phoneNo)
        {
            if (status.Equals(Resources.Call_Calling))
            {
                SetText(status, _phone);
                _da = DateTime.Now;
            }
            else
            {
                SetText(status, phoneNo);
            }
            if (phoneNo.Equals(Resources.Call_Finished_Signal))
            {
                timerCall.Stop();
            }
        }

        /// <summary>
        ///   Handles the Tick event of the timerCall control.
        /// </summary>
        private void timerCall_Tick(object sender, EventArgs e)
        {
            TimeSpan span = DateTime.Now.Subtract(_da);

            lblTimer.Text = string.Format(Resources.Time_Counter_Format, span.Hours, span.Minutes, span.Seconds);
        }

        /// <summary>
        ///   Handles the FormClosed event of the Form_Call control.
        /// </summary>
        private void Form_Call_FormClosed(object sender, FormClosedEventArgs e)
        {
            _parent._modem.CallFormDelegate -= CallState;
            _parent.UpdateCallNo -= UpdatePhoneNo;
            _parent.ObjFormCall = null;
        }

        /// <summary>
        ///   Update status label's text.
        /// </summary>
        /// <param name = "status">The status.</param>
        /// <param name = "phoneNo">The phone no.</param>
        private void SetText(string status, string phoneNo)
        {
            if (lblStatus.InvokeRequired)
            {
                SetTextCallback d = SetText;
                Invoke(d, new object[] {status, phoneNo});
            }
            else
            {
                if (phoneNo.Equals(Resources.Call_Finished_Signal))
                    phoneNo = "";
                lblStatus.Text = status + phoneNo;
            }
        }

        /// <summary>
        ///   Updates the phone number.
        /// </summary>
        /// <param name = "phoneNo">The phone number.</param>
        private void UpdatePhoneNo(string phoneNo)
        {
            if (lblStatus.InvokeRequired)
            {
                ContactPhoneNo d = UpdatePhoneNo;
                Invoke(d, new object[] {phoneNo});
            }
            else
            {
                txt_PhoneNo.Text = phoneNo;
            }
        }

        #region Nested type: ContactPhoneNo

        private delegate void ContactPhoneNo(string phoneNo);

        #endregion

        #region Nested type: SetTextCallback

        private delegate void SetTextCallback(string text, string phoneNo);

        #endregion
    }
}