﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using GSS.DataAccessLayer.GSSTableAdapters;

namespace GSS.View.Menu_Tool
{
    /// <summary>
    /// Getting contact to make a call
    /// </summary>
    public partial class Form_CallContact : Form
    {
        #region Delegates

        /// <summary>
        /// Update phone number of the textbox on Form Call
        /// </summary>
        /// <param name="contacts">The contacts.</param>
        public delegate void SelectContactDelegate(string contacts);

        #endregion

        private readonly GSS_CustomerTableAdapter _customerAdapter = new GSS_CustomerTableAdapter();

        public SelectContactDelegate SelectContacts;

        /// <summary>
        /// Initializes a new instance of the "Form_CallContact" form.
        /// </summary>
        public Form_CallContact()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Load event of the CallContact form.
        /// </summary>
        private void CallContact_Load(object sender, EventArgs e)
        {
            var customerDataTable = _customerAdapter.GetCustomers();


            foreach (var customer in customerDataTable)
            {
                var row = new object[] {customer.cus_Name, customer.cus_PhoneNumber, customer.cus_HomeNumber};
                dtg_Contact.Rows.Add(row);
            }
        }

        /// <summary>
        /// Handles the CellClick event of the datagridview Contact.
        /// </summary>
        private void dtg_Contact_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            if (e.ColumnIndex == 2)
            {
                SelectContacts(!dtg_Contact[2, e.RowIndex].Value.ToString().Trim().Equals(string.Empty)
                                   ? dtg_Contact[2, e.RowIndex].Value.ToString()
                                   : dtg_Contact[1, e.RowIndex].Value.ToString());
            }
            else
            {
                SelectContacts(!dtg_Contact[1, e.RowIndex].Value.ToString().Trim().Equals(string.Empty)
                                   ? dtg_Contact[1, e.RowIndex].Value.ToString()
                                   : dtg_Contact[2, e.RowIndex].Value.ToString());
            }
        }
    }
}