﻿using System.Windows.Forms;
using GasManager;

namespace GSS.View.Menu_Tool
{
    public class Popup_Form : Form
    {
        protected MainForm _parent;
    }
}