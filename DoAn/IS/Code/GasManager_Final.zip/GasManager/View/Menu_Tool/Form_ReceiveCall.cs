﻿using System;
using System.Windows.Forms;
using GasManager;
using GSS.Objects;

namespace GSS.View.Menu_Tool
{
    /// <summary>
    /// The form is appeared when modem receive a call
    /// </summary>
    public partial class Form_ReceiveCall : Popup_Form
    {
        private new readonly MainForm _parent;
        private String _address = "";
        private DataAccessLayer.GSS.GSS_CustomerDataTable _customers;
        private String _name = "";
        private int _orderNumber;
        private Int32 _revenue;
        public String phone = "";

        private bool willclose = false;

        /// <summary>
        /// Initializes a new instance of the "Form_ReceiveCall" form.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="phone">The phone.</param>
        /// <param name="address">The address.</param>
        /// <param name="orderNumber">The order number.</param>
        /// <param name="revenue">The revenue.</param>
        /// <param name="parent">The parent.</param>
        /// <param name="customers">The customers.</param>
        public Form_ReceiveCall(String name, String phone, String address, int orderNumber, Int32 revenue,
                                MainForm parent, DataAccessLayer.GSS.GSS_CustomerDataTable customers)
        {
            InitializeComponent();
            _parent = parent;

            _name = name;
            this.phone = phone;
            _address = address;
            _orderNumber = orderNumber;
            _revenue = revenue;
            _customers = customers;

            SetText(_name, lbl_name);
            SetText(address, lbl_address);
            SetText(string.Format("Doanh thu: {0} đồng", _revenue), lbl_money);
            SetText(string.Format("Đã đặt hàng {0} lần", _orderNumber), lbl_statistic);
            SetText(phone, lbl_telephone);
            IHaveNoIdeaWhatThisIs();
        }

        /// <summary>
        /// If the form is opening, change status of the label, not open new instance
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="strPhone">The phone.</param>
        /// <param name="strAddress">The address.</param>
        /// <param name="orderNumber">The order number.</param>
        /// <param name="revenue">The revenue.</param>
        /// <param name="tableCustomers">The table customers.</param>
        
        public void SetCall(String name, String strPhone, String strAddress, int orderNumber, Int32 revenue,
                            DataAccessLayer.GSS.GSS_CustomerDataTable tableCustomers)
        {
            _name = name;
            phone = strPhone;
            _address = strAddress;
            _orderNumber = orderNumber;
            _revenue = revenue;
            _customers = tableCustomers;

            SetText(_name, lbl_name);
            SetText(_address, lbl_address);
            SetText("Doanh thu: " + _revenue + " đồng", lbl_money);
            SetText("Đã đặt hàng " + _orderNumber + " lần", lbl_statistic);
            SetText(phone, lbl_telephone);

            IHaveNoIdeaWhatThisIs();
        }

        /// <summary>
        /// A helper method.
        /// </summary>
        private void IHaveNoIdeaWhatThisIs()
        {
            for (var count = 0; count < _parent.editTreeView.Nodes[MainForm.NODE_CALL].Nodes.Count; count++)
            {
                if (
                    ((TreeNode_User) _parent.editTreeView.Nodes[MainForm.NODE_CALL].Nodes[count]).cus_HomeNumber ==
                    phone
                    ||
                    ((TreeNode_User) _parent.editTreeView.Nodes[MainForm.NODE_CALL].Nodes[count]).cus_PhoneNumber ==
                    phone
                    )
                {
                    return;
                }
            }

            if (_customers.Rows.Count == 0)
            {
                var newUser = new TreeNode_User(phone)
                                  {
                                      cus_HomeNumber = phone,
                                      cus_Name = phone,
                                      cus_PhoneNumber = phone
                                  };
                _parent.AddNode(newUser, _parent.editTreeView, MainForm.NODE_CALL, false);
            }
            else
            {
                var customerRow = _customers[0];
                var newUser = new TreeNode_User(customerRow.cus_Name) {node_customer = customerRow};
                newUser.loadNode();

                _parent.AddNode(newUser, _parent.editTreeView, MainForm.NODE_CALL, false);
            }
        }

        /// <summary>
        /// Remove object of main form.
        /// </summary>
        protected override void  OnFormClosing(FormClosingEventArgs e)
    {
        if (willclose)
        {
            base.OnClosing(e);
        }else
        {
            _parent.Decline(phone);
            Hide_Form();
            e.Cancel = true;
        }

    }



        /// <summary>
        /// Handles the Click event of the button btn_close.
        /// </summary>
        public void btn_close_Click(object sender, EventArgs e)
        {
            _parent.phone = String.Empty;
            _parent.Decline(phone);
        }

        /// <summary>
        /// Handles the Click event of the button btn_answer.
        /// </summary>
        private void btn_answer_Click(object sender, EventArgs e)
        {
            _parent.Answer(phone);
        }

        /// <summary>
        /// Delegate close the form from outside.
        /// </summary>
        public void Close_Form()
        {
            willclose = true;
            if (this.InvokeRequired)
            {
                Close_FormCallBack d = Close_Form;
                Invoke(d, new object[] {});
            }
            else
            {
                Close();
                //_parent.phone = String.Empty;
            }
        }

        /// <summary>
        /// Sets text for a label.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <param name="label">The label.</param>
        /// 
        /// 


        private delegate void SetOpacityCallBack(int opacity);
        public void SetOpacity(int opacity)
        {
            if (this.InvokeRequired)
            {
                SetOpacityCallBack d = SetOpacity;
                Invoke(d, new object[] { opacity });
            }
            else
            {
                this.Opacity = opacity;
            }
        }


        private delegate void Hide_FormCallBack();
        public void Hide_Form()
        {
            if (InvokeRequired)
            {
                Hide_FormCallBack d = Hide_Form;
                Invoke(d, new object[] { });
            }
            else
            {
                Hide();
            }
        }



        private delegate void Show_FormCallBack();
        public void Show_Form()
        {
            if (InvokeRequired)
            {
                Show_FormCallBack d = Show_Form;
                Invoke(d, new object[] { });
            }
            else
            {
                Show();
            }
        }

        private void SetText(string text, Label label)
        {
            if (label.InvokeRequired)
            {
                SetTextCallback d = SetText;
                Invoke(d, new object[] {text, label});
            }
            else
            {
                label.Text = text;
            }
        }

        #region Nested type: Close_FormCallBack

        /// <summary>
        /// Delegate close form CallBack
        /// </summary>
        private delegate void Close_FormCallBack();

        #endregion

        #region Nested type: SetTextCallback

        /// <summary>
        /// Delegate Set value for label CallBack
        /// </summary>
        /// <param name="text">The text.</param>
        /// <param name="label">The label.</param>
        private delegate void SetTextCallback(string text, Label label);

        #endregion
    }
}