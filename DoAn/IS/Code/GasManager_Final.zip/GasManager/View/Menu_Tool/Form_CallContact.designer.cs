﻿namespace GSS.View.Menu_Tool
{
    partial class Form_CallContact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_CallContact));
            this.dtg_Contact = new System.Windows.Forms.DataGridView();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPhone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Contact)).BeginInit();
            this.SuspendLayout();
            // 
            // dtg_Contact
            // 
            this.dtg_Contact.AllowUserToAddRows = false;
            this.dtg_Contact.AllowUserToDeleteRows = false;
            this.dtg_Contact.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_Contact.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_Contact.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtg_Contact.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colName,
            this.colMobile,
            this.colPhone});
            this.dtg_Contact.Location = new System.Drawing.Point(12, 12);
            this.dtg_Contact.Name = "dtg_Contact";
            this.dtg_Contact.ReadOnly = true;
            this.dtg_Contact.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dtg_Contact.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_Contact.ShowEditingIcon = false;
            this.dtg_Contact.Size = new System.Drawing.Size(434, 269);
            this.dtg_Contact.TabIndex = 0;
            this.dtg_Contact.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtg_Contact_CellClick);
            // 
            // colName
            // 
            this.colName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colName.DefaultCellStyle = dataGridViewCellStyle1;
            this.colName.HeaderText = "Họ và tên";
            this.colName.MinimumWidth = 150;
            this.colName.Name = "colName";
            this.colName.ReadOnly = true;
            this.colName.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colName.Width = 150;
            // 
            // colMobile
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.colMobile.DefaultCellStyle = dataGridViewCellStyle2;
            this.colMobile.FillWeight = 500F;
            this.colMobile.HeaderText = "Di động";
            this.colMobile.MinimumWidth = 100;
            this.colMobile.Name = "colMobile";
            this.colMobile.ReadOnly = true;
            this.colMobile.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colMobile.Width = 120;
            // 
            // colPhone
            // 
            this.colPhone.HeaderText = "Máy bàn";
            this.colPhone.Name = "colPhone";
            this.colPhone.ReadOnly = true;
            this.colPhone.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colPhone.Width = 120;
            // 
            // Form_CallContact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 293);
            this.Controls.Add(this.dtg_Contact);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(473, 600);
            this.MinimumSize = new System.Drawing.Size(473, 331);
            this.Name = "Form_CallContact";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Chọn danh bạ";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.CallContact_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Contact)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtg_Contact;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPhone;
    }
}