﻿namespace GSS.View.Menu_Tool
{
    partial class Form_Call
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Call));
            this.label1 = new System.Windows.Forms.Label();
            this.txt_PhoneNo = new System.Windows.Forms.TextBox();
            this.btn_Call = new System.Windows.Forms.Button();
            this.btn_Finish = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.timerCall = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.btn_Contact = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Số điện thoại";
            // 
            // txt_PhoneNo
            // 
            this.txt_PhoneNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PhoneNo.Location = new System.Drawing.Point(102, 28);
            this.txt_PhoneNo.Name = "txt_PhoneNo";
            this.txt_PhoneNo.Size = new System.Drawing.Size(186, 24);
            this.txt_PhoneNo.TabIndex = 0;
            // 
            // btn_Call
            // 
            this.btn_Call.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Call.BackgroundImage")));
            this.btn_Call.Location = new System.Drawing.Point(106, 68);
            this.btn_Call.Name = "btn_Call";
            this.btn_Call.Size = new System.Drawing.Size(75, 57);
            this.btn_Call.TabIndex = 2;
            this.toolTip1.SetToolTip(this.btn_Call, "Gọi đi");
            this.btn_Call.UseVisualStyleBackColor = true;
            this.btn_Call.Click += new System.EventHandler(this.btn_Call_Click);
            // 
            // btn_Finish
            // 
            this.btn_Finish.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Finish.BackgroundImage")));
            this.btn_Finish.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Finish.Location = new System.Drawing.Point(208, 68);
            this.btn_Finish.Name = "btn_Finish";
            this.btn_Finish.Size = new System.Drawing.Size(75, 57);
            this.btn_Finish.TabIndex = 3;
            this.toolTip1.SetToolTip(this.btn_Finish, "Kết thúc");
            this.btn_Finish.UseVisualStyleBackColor = true;
            this.btn_Finish.Click += new System.EventHandler(this.btFinish_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(12, 132);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 13);
            this.lblStatus.TabIndex = 3;
            // 
            // timerCall
            // 
            this.timerCall.Interval = 1000;
            this.timerCall.Tick += new System.EventHandler(this.timerCall_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(236, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Thời gian gọi:";
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Location = new System.Drawing.Point(313, 137);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(49, 13);
            this.lblTimer.TabIndex = 5;
            this.lblTimer.Text = "00:00:00";
            // 
            // btn_Contact
            // 
            this.btn_Contact.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Contact.BackgroundImage")));
            this.btn_Contact.Location = new System.Drawing.Point(303, 13);
            this.btn_Contact.Name = "btn_Contact";
            this.btn_Contact.Size = new System.Drawing.Size(54, 55);
            this.btn_Contact.TabIndex = 1;
            this.toolTip1.SetToolTip(this.btn_Contact, "Danh bạ");
            this.btn_Contact.UseVisualStyleBackColor = true;
            this.btn_Contact.Click += new System.EventHandler(this.btnContact_Click);
            // 
            // Form_Call
            // 
            this.AcceptButton = this.btn_Call;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_Finish;
            this.ClientSize = new System.Drawing.Size(372, 159);
            this.Controls.Add(this.btn_Contact);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btn_Finish);
            this.Controls.Add(this.btn_Call);
            this.Controls.Add(this.txt_PhoneNo);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(388, 197);
            this.MinimumSize = new System.Drawing.Size(388, 197);
            this.Name = "Form_Call";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gọi điện thoại";
            this.TopMost = true;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_Call_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_PhoneNo;
        private System.Windows.Forms.Button btn_Call;
        private System.Windows.Forms.Button btn_Finish;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Timer timerCall;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Button btn_Contact;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}