﻿using System;
using System.Collections;
using System.Windows.Forms;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_System
{
    /// <summary>
    ///   Edit product without shell's form
    /// </summary>
    public partial class EditProduct_Normal : Form
    {
        private readonly Hashtable _price = new Hashtable();
        private readonly Hashtable _products = new Hashtable();


        private readonly GSS_ValueTableAdapter _valueAdapter = new GSS_ValueTableAdapter();
        private readonly GSS_ValveTableAdapter _valveAdapter = new GSS_ValveTableAdapter();

        /// <summary>
        ///   Initializes a new instance of the "EditProduct_Normal" form.
        /// </summary>
        public EditProduct_Normal()
        {
            InitializeComponent();
            ShowProduct();
        }

        /// <summary>
        ///   Shows products.
        /// </summary>
        public void ShowProduct()
        {
            dtg_Product.Rows.Clear();
            _price.Clear();
            _products.Clear();


            var valuedt = _valueAdapter.GetValues();
            foreach (var valueRow in valuedt)
            {
                _price.Add(valueRow.val_Id, valueRow.val_Price);
            }

            var productDt = _valveAdapter.GetValves();
            foreach (var productRow in productDt)
            {
                _products.Add(productRow.valve_Id, productRow);
                var newRow = new DataGridViewRow_NomalProduct();
                dtg_Product.Rows.Add(newRow);
                ((DataGridViewRow_NomalProduct) dtg_Product.Rows[dtg_Product.Rows.Count - 1]).productId =
                    productRow.valve_Id;
                dtg_Product.Rows[dtg_Product.Rows.Count - 1].Cells[Definitions.EDIT_PRODUCT_NORMAL_NAME].Value =
                    productRow.valve_Name;
                dtg_Product.Rows[dtg_Product.Rows.Count - 1].Cells[Definitions.EDIT_PRODUCT_NORMAL_IMPORTPRICE].Value =
                    productRow.valve_Price;
                dtg_Product.Rows[dtg_Product.Rows.Count - 1].Cells[Definitions.EDIT_PRODUCT_NORMAL_SELLPRICE].Value =
                    _price[productRow.value_Id];
            }
        }

        /// <summary>
        ///   Handles the SelectedChanged event of the datagridview dtg_select.
        /// </summary>
        private void dtg_SelectedChanged(object sender, EventArgs e)
        {
            btn_edit.Enabled = true;
            if (dtg_Product.SelectedRows.Count != 1)
            {
                btn_edit.Enabled = false;
            }
        }

        /// <summary>
        ///   Handles the Click event of the button btn_edit.
        /// </summary>
        private void btn_edit_Click(object sender, EventArgs e)
        {
            var product = ((DataGridViewRow_NomalProduct) dtg_Product.SelectedRows[0]).productId;
            var productInfo = (DataAccessLayer.GSS.GSS_ValveRow) _products[product];

            var editProductNormalAdd = new EditProduct_NormalAdd(this, productInfo)
                                           {Text = Resources.Title_Edit_Product};
            editProductNormalAdd.ShowDialog();
        }

        /// <summary>
        ///   Handles the Click event of the button Add.
        /// </summary>
        private void btn_Add_Click(object sender, EventArgs e)
        {
            var editProductNormalAdd = new EditProduct_NormalAdd(this) {Text = Resources.Title_Add_Product};
            editProductNormalAdd.ShowDialog();
        }
    }
}