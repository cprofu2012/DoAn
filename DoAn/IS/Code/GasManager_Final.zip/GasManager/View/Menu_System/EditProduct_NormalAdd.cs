﻿using System;
using System.Data;
using System.Windows.Forms;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_System
{
    /// <summary>
    ///   Add product without shell's form
    /// </summary>
    public partial class EditProduct_NormalAdd : Form
    {
        private readonly int _originalPricel;
        private readonly EditProduct_Normal _parent;
        private readonly DataAccessLayer.GSS.GSS_ValveRow _productRow;
        private readonly GSS_SuppliersTableAdapter _supplierAdapter = new GSS_SuppliersTableAdapter();
        private readonly GSS_ValueTableAdapter _valueAdapter = new GSS_ValueTableAdapter();
        private readonly GSS_ValveTableAdapter _valveAdapter = new GSS_ValveTableAdapter();

        /// <summary>
        ///   Initializes a new instance of the "EditProduct_NormalAdd" form.
        /// </summary>
        /// <param name = "parent">The form edit product without shell.</param>
        public EditProduct_NormalAdd(EditProduct_Normal parent)
        {
            InitializeComponent();
            _parent = parent;
            SetSupplier(cbb_deliver);
        }

        /// <summary>
        ///   Initializes a new instance of the "EditProduct_NormalAdd" form.
        /// </summary>
        /// <param name = "parent">The form edit product without shell.</param>
        /// <param name = "productRow">The product row.</param>
        public EditProduct_NormalAdd(EditProduct_Normal parent, DataAccessLayer.GSS.GSS_ValveRow productRow)
        {
            InitializeComponent();
            _parent = parent;
            _productRow = productRow;
            SetSupplier(cbb_deliver);


            cbb_deliver.SelectedValue = productRow.valve_SupId;

            var valuedt = _valueAdapter.GetValueById(productRow.value_Id);
            foreach (var value in valuedt)
            {
                txt_sellPrice.Text = "" + value.val_Price;
                _originalPricel = value.val_Price;
            }
            txt_importPrice.Text = productRow.valve_Price + "";
            txt_NameProduct.Text = productRow.valve_Name;
        }

        /// <summary>
        ///   Handles the Click event of the button save.
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_NameProduct.Text.Trim().Length == 0
                || txt_importPrice.Text.Trim().Length == 0
                || txt_sellPrice.Text.Trim().Length == 0
                || cbb_deliver.SelectedValue == null)
            {
                MessageBox.Show(Resources.Msb_Information_require, Resources.Msb_Title_Error, MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            String productDescription;
            int productImportPrice;
            int productsellPrice;
            int productSupplierId;

            try
            {
                productDescription = txt_NameProduct.Text.Trim();
                productImportPrice = Int32.Parse(txt_importPrice.Text.Trim());
                productsellPrice = Int32.Parse(txt_sellPrice.Text.Trim());
                productSupplierId = Int32.Parse(cbb_deliver.SelectedValue.ToString());
            }
            catch (Exception)
            {
                MessageBox.Show(Resources.Msb_Money_Number_Error, Resources.Msb_Title_Error, MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            if (_productRow == null)
            {
                _valueAdapter.Insert(productsellPrice, DateTime.Now);
                var productValueId = (int) _valueAdapter.GetLastIdInserted();
                _valveAdapter.Insert(productDescription, 0, productSupplierId, productValueId, productImportPrice);
            }
            else
            {
                if (
                    productDescription.Equals(_productRow.valve_Name) &&
                    productImportPrice == _productRow.valve_Price &&
                    productsellPrice == _originalPricel &&
                    productSupplierId == _productRow.valve_SupId
                    )
                {
                    return;
                }

                int productValueId = _productRow.valve_Id;
                if (productsellPrice != _originalPricel)
                {
                    _valueAdapter.Insert(productsellPrice, DateTime.Now);
                    productValueId = (int) _valueAdapter.GetLastIdInserted();
                }

                _valveAdapter.Update1(productDescription, _productRow.valve_Quantity, productSupplierId, productValueId,
                    productImportPrice, _productRow.valve_Id);
            }


            _parent.ShowProduct();
        }

        /// <summary>
        ///   Sets the supplier.
        /// </summary>
        /// <param name = "cbb">The combobox.</param>
        private void SetSupplier(ComboBox cbb)
        {
            var delivererTable = new DataTable();
            delivererTable.Columns.Add(Definitions.FIELD_TEXT);
            delivererTable.Columns.Add(Definitions.FIELD_VALUE);
            cbb.DataSource = delivererTable;
            cbb.DisplayMember = Definitions.FIELD_TEXT;
            cbb.ValueMember = Definitions.FIELD_VALUE;

            DataAccessLayer.GSS.GSS_SuppliersDataTable suppliers = _supplierAdapter.GetSuppliers();

            foreach (var supplier in suppliers)
            {
                var dataRow = delivererTable.NewRow();
                dataRow[0] = supplier.sup_Representative;
                dataRow[1] = supplier.sup_Id;
                delivererTable.Rows.Add(dataRow);
            }

            if (delivererTable.Rows.Count > 0)
            {
                cbb.SelectedIndex = 0;
            }
        }
    }
}