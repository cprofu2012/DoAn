﻿using System;
using System.Data;
using System.Windows.Forms;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_System
{
    /// <summary>
    /// Form Add Shell
    /// </summary>
    public partial class EditProduct_WithShell_Add : Form
    {
        private readonly GSS_GasTableAdapter _gasAdapter = new GSS_GasTableAdapter();

        private readonly DataAccessLayer.GSS.GSS_GasRow _gasRow;
        private readonly GSS_GasShellTableAdapter _gasShellAdapter = new GSS_GasShellTableAdapter();

        private readonly int _oriGasPrice;
        private readonly int _oriShellPrice;
        private readonly EditProduct_WithShell _parent;
        private readonly GSS_ShellTableAdapter _shellAdapter = new GSS_ShellTableAdapter();
        private readonly DataAccessLayer.GSS.GSS_ShellRow _shellRow;
        private readonly GSS_SuppliersTableAdapter _supplierAdapter = new GSS_SuppliersTableAdapter();
        private readonly GSS_ValueTableAdapter _valueAdapter = new GSS_ValueTableAdapter();


        /// <summary>
        /// Initializes a new instance of the "EditProduct_WithShell_Add" form.
        /// </summary>
        /// <param name="parent">The parent.</param>
        public EditProduct_WithShell_Add(EditProduct_WithShell parent)
        {
            InitializeComponent();
            _parent = parent;


            SetSupplier(cbb_shellSupplier);
            SetSupplier(cbb_gasSupplier);
        }

        /// <summary>
        /// Initializes a new instance of the "EditProduct_WithShell_Add" form.
        /// </summary>
        /// <param name="parent">The parent.</param>
        /// <param name="gasRow">The gas row.</param>
        /// <param name="shellRow">The shell row.</param>
        public EditProduct_WithShell_Add(EditProduct_WithShell parent, DataAccessLayer.GSS.GSS_GasRow gasRow,
                                         DataAccessLayer.GSS.GSS_ShellRow shellRow)
        {
            InitializeComponent();
            _parent = parent;
            _gasRow = gasRow;
            _shellRow = shellRow;

            txt_gas_description.Text = gasRow.gas_Name;
            txt_gas_importprice.Text = gasRow.gas_Price + "";

            var valuedt = _valueAdapter.GetValueById(gasRow.value_Id);
            foreach (var value in valuedt)
            {
                txt_gas_sellprice.Text = "" + value.val_Price;
                _oriGasPrice = value.val_Price;
            }

            txt_shell_description.Text = shellRow.shell_Name;
            txt_shell_importPrice.Text = shellRow.shell_Price + "";
            var valuedt2 = _valueAdapter.GetValueById(shellRow.value_Id);
            foreach (var value in valuedt2)
            {
                txt_shell_sellprice.Text = "" + value.val_Price;
                _oriShellPrice = value.val_Price;
            }

            SetSupplier(cbb_shellSupplier);
            SetSupplier(cbb_gasSupplier);

            cbb_shellSupplier.SelectedValue = shellRow.shell_SupId;
            cbb_gasSupplier.SelectedValue = gasRow.gas_SupId;
        }

        /// <summary>
        /// Handles the changed event of the textbox txt_gas_description.
        /// </summary>
        private void txt_gas_description_changed(object sender, EventArgs e)
        {
            txt_shell_description.Text = "Vỏ " + txt_gas_description.Text;
        }

        /// <summary>
        /// Handles the Click event of the button Save.
        /// </summary>
        private void btn_save_Click(object sender, EventArgs e)
        {
            if (txt_gas_description.Text.Trim().Length == 0
                || txt_gas_importprice.Text.Trim().Length == 0
                || txt_gas_sellprice.Text.Trim().Length == 0
                || txt_shell_description.Text.Trim().Length == 0
                || txt_shell_importPrice.Text.Trim().Length == 0
                || txt_shell_sellprice.Text.Trim().Length == 0)
            {
                MessageBox.Show(Resources.Msb_Information_require, Resources.Msb_Title_Error, MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            String gasDescription;
            int gasImportPrice;
            int gassellPrice;
            int gasSupplierId;

            String shellDescription;
            int shellImportPrice;
            int shellsellPrice;
            int shellSupplierId;
            try
            {
                gasDescription = txt_gas_description.Text.Trim();
                gasImportPrice = Int32.Parse(txt_gas_importprice.Text.Trim());
                gassellPrice = Int32.Parse(txt_gas_sellprice.Text.Trim());
                gasSupplierId = Int32.Parse(cbb_gasSupplier.SelectedValue.ToString());

                shellDescription = txt_shell_description.Text.Trim();
                shellImportPrice = Int32.Parse(txt_shell_importPrice.Text.Trim());
                shellsellPrice = Int32.Parse(txt_shell_sellprice.Text.Trim());
                shellSupplierId = Int32.Parse(cbb_shellSupplier.SelectedValue.ToString());
            }
            catch (Exception)
            {
                MessageBox.Show(Resources.Msb_Money_Number_Error, Resources.Msb_Title_Error, MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }


            if (_gasRow == null)
            {
                _valueAdapter.Insert(gassellPrice, DateTime.Now);
                var gasValueId = (int) _valueAdapter.GetLastIdInserted();

                _valueAdapter.Insert(shellsellPrice, DateTime.Now);
                var shellValueId = (int) _valueAdapter.GetLastIdInserted();

                _gasAdapter.InsertGas(gasDescription, 0, gasImportPrice, gasSupplierId, "", gasValueId);
                _shellAdapter.Insert(shellDescription, 0, "", shellValueId, shellSupplierId, shellImportPrice);
                _gasShellAdapter.Insert((int) _shellAdapter.GetLastInsertId(), (int) _gasAdapter.GetLastInsertedId());
            }
            else
            {
                int gasValueId = _gasRow.value_Id;
                if (gassellPrice != _oriGasPrice)
                {
                    _valueAdapter.Insert(gassellPrice, DateTime.Now);
                    gasValueId = (int) _valueAdapter.GetLastIdInserted();
                }

                int shellValueId = _shellRow.value_Id;
                if (shellsellPrice != _oriShellPrice)
                {
                    _valueAdapter.Insert(shellsellPrice, DateTime.Now);
                    shellValueId = (int) _valueAdapter.GetLastIdInserted();
                }

                _gasAdapter.UpdateGas(gasDescription, _gasRow.gas_Quantity, gasImportPrice, gasSupplierId, "",
                    gasValueId,
                    _gasRow.gas_Id);
                _shellAdapter.UpdateShell(shellDescription, _shellRow.shell_Quantity, "", shellValueId, shellSupplierId,
                    shellImportPrice, _shellRow.shell_Id);
            }


            _parent.ShowProduct();
        }

        /// <summary>
        /// Sets the supplier.
        /// </summary>
        /// <param name="cbb">The combobox.</param>
        private void SetSupplier(ComboBox cbb)
        {
            var delivererTable = new DataTable();
            delivererTable.Columns.Add(Definitions.FIELD_TEXT);
            delivererTable.Columns.Add(Definitions.FIELD_VALUE);
            cbb.DataSource = delivererTable;
            cbb.DisplayMember = Definitions.FIELD_TEXT;
            cbb.ValueMember = Definitions.FIELD_VALUE;

            var suppliers = _supplierAdapter.GetSuppliers();

            foreach (var supplier in suppliers)
            {
                DataRow dataRow = delivererTable.NewRow();
                dataRow[0] = supplier.sup_Representative;
                dataRow[1] = supplier.sup_Id;
                delivererTable.Rows.Add(dataRow);
            }

            if (delivererTable.Rows.Count > 0)
            {
                cbb.SelectedIndex = 0;
            }
        }
    }
}