﻿using System;
namespace GSS.View.Menu_System
{
    partial class Form_Deliverer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            try
            {
                base.Dispose(disposing);
            }
            catch (Exception) { 
            
            }
            }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Deliverer));
            this.dtg_Deliverer = new System.Windows.Forms.DataGridView();
            this.COLUMN_NAME_DELIVERER_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_DELIVERER_TEL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_DELIVERER_CMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_DELIVERER_REMOVE = new System.Windows.Forms.DataGridViewImageColumn();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_AddDeliverer = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Deliverer)).BeginInit();
            this.SuspendLayout();
            // 
            // dtg_Deliverer
            // 
            this.dtg_Deliverer.AllowUserToAddRows = false;
            this.dtg_Deliverer.AllowUserToDeleteRows = false;
            this.dtg_Deliverer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_Deliverer.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_Deliverer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_Deliverer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.COLUMN_NAME_DELIVERER_NAME,
            this.COLUMN_NAME_DELIVERER_TEL,
            this.COLUMN_NAME_DELIVERER_CMT,
            this.COLUMN_NAME_DELIVERER_REMOVE});
            this.dtg_Deliverer.Location = new System.Drawing.Point(12, 12);
            this.dtg_Deliverer.Name = "dtg_Deliverer";
            this.dtg_Deliverer.ReadOnly = true;
            this.dtg_Deliverer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_Deliverer.Size = new System.Drawing.Size(580, 418);
            this.dtg_Deliverer.TabIndex = 0;
            // 
            // COLUMN_NAME_DELIVERER_NAME
            // 
            this.COLUMN_NAME_DELIVERER_NAME.HeaderText = "Tên";
            this.COLUMN_NAME_DELIVERER_NAME.Name = "COLUMN_NAME_DELIVERER_NAME";
            this.COLUMN_NAME_DELIVERER_NAME.ReadOnly = true;
            this.COLUMN_NAME_DELIVERER_NAME.Width = 150;
            // 
            // COLUMN_NAME_DELIVERER_TEL
            // 
            this.COLUMN_NAME_DELIVERER_TEL.HeaderText = "Số điện thoại";
            this.COLUMN_NAME_DELIVERER_TEL.Name = "COLUMN_NAME_DELIVERER_TEL";
            this.COLUMN_NAME_DELIVERER_TEL.ReadOnly = true;
            this.COLUMN_NAME_DELIVERER_TEL.Width = 150;
            // 
            // COLUMN_NAME_DELIVERER_CMT
            // 
            this.COLUMN_NAME_DELIVERER_CMT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.COLUMN_NAME_DELIVERER_CMT.HeaderText = "Ghi chú";
            this.COLUMN_NAME_DELIVERER_CMT.Name = "COLUMN_NAME_DELIVERER_CMT";
            this.COLUMN_NAME_DELIVERER_CMT.ReadOnly = true;
            // 
            // COLUMN_NAME_DELIVERER_REMOVE
            // 
            this.COLUMN_NAME_DELIVERER_REMOVE.HeaderText = "";
            this.COLUMN_NAME_DELIVERER_REMOVE.Image = ((System.Drawing.Image)(resources.GetObject("COLUMN_NAME_DELIVERER_REMOVE.Image")));
            this.COLUMN_NAME_DELIVERER_REMOVE.Name = "COLUMN_NAME_DELIVERER_REMOVE";
            this.COLUMN_NAME_DELIVERER_REMOVE.ReadOnly = true;
            this.COLUMN_NAME_DELIVERER_REMOVE.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.COLUMN_NAME_DELIVERER_REMOVE.Width = 20;
            // 
            // btn_save
            // 
            this.btn_save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_save.Image = ((System.Drawing.Image)(resources.GetObject("btn_save.Image")));
            this.btn_save.Location = new System.Drawing.Point(552, 439);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(40, 40);
            this.btn_save.TabIndex = 1;
            this.toolTip1.SetToolTip(this.btn_save, "Lưu");
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_AddDeliverer
            // 
            this.btn_AddDeliverer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_AddDeliverer.Image = ((System.Drawing.Image)(resources.GetObject("btn_AddDeliverer.Image")));
            this.btn_AddDeliverer.Location = new System.Drawing.Point(506, 439);
            this.btn_AddDeliverer.Name = "btn_AddDeliverer";
            this.btn_AddDeliverer.Size = new System.Drawing.Size(40, 40);
            this.btn_AddDeliverer.TabIndex = 0;
            this.toolTip1.SetToolTip(this.btn_AddDeliverer, "Thêm");
            this.btn_AddDeliverer.UseVisualStyleBackColor = true;
            this.btn_AddDeliverer.Click += new System.EventHandler(this.btn_AddDeliverer_Click);
            // 
            // Form_Deliverer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 486);
            this.Controls.Add(this.btn_AddDeliverer);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.dtg_Deliverer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_Deliverer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách nhân viên giao hàng";
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Deliverer)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtg_Deliverer;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_AddDeliverer;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_DELIVERER_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_DELIVERER_TEL;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_DELIVERER_CMT;
        private System.Windows.Forms.DataGridViewImageColumn COLUMN_NAME_DELIVERER_REMOVE;
    }
}