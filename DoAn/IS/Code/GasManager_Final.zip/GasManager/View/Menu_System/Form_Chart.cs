﻿using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using GasManager;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;
using Microsoft.Office.Interop.Excel;
using Application = Microsoft.Office.Interop.Excel.Application;

namespace GSS.View.Menu_System
{
    /// <summary>
    ///   Export to excel's chart
    /// </summary>
    public partial class Form_Chart : Form
    {
        private const string IDENTIFY_VALUE_GAS = "1";
        private const string IDENTIFY_VALUE_SHELL = "3";
        private const string IDENTIFY_VALUE_VALVE = "2";
        private readonly SqlConnection _con = new SqlConnection(Resources.ConnectionString);

        /// <summary>
        ///   Initializes a new instance of the "Form_Chart" form.
        /// </summary>
        /// <param name = "parent">The main form.</param>
        public Form_Chart(MainForm parent)
        {
            Parent = parent;
            InitializeComponent();
            Parent = parent;
        }

        public new MainForm Parent { get; set; }

        /// <summary>
        ///   Handles the Click event of the button btn_Export.
        /// </summary>
        private void btn_Export_Click(object sender, EventArgs e)
        {
            var from =
                dtp_from.Value.AddHours(0 - dtp_from.Value.Hour).AddMinutes(0 - dtp_from.Value.Minute).AddSeconds(0 -
                                                                                                                  dtp_from
                                                                                                                      .
                                                                                                                      Value
                                                                                                                      .
                                                                                                                      Second);
            var to =
                dtp_to.Value.AddHours(0 - dtp_to.Value.Hour).AddMinutes(0 - dtp_to.Value.Minute).AddSeconds(0 -
                                                                                                            dtp_to.Value
                                                                                                                .Second)
                    .AddDays(1).AddSeconds(0 - 1);

            if (rbt_callHour.Checked)
            {
                var callAdapter = new GSS_CallTableAdapter();
                DataAccessLayer.GSS.GSS_CallDataTable calls = null;

                calls = txt_Top.Text.Trim().Equals("0")
                            ? callAdapter.GetDataTwoDate(from, to)
                            : callAdapter.GetDataTopTwoDate(Int32.Parse(txt_Top.Text), from, to);

                var callByHour = new[]
                                     {
                                         "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                                         "0", "0", "0", "0", "0", "0", "0", "0"
                                     };
                foreach (var call in calls)
                {
                    callByHour[call.call_Time.Hour] = (Int32.Parse(callByHour[call.call_Time.Hour]) + 1) + "";
                }
                ExportCallByHour(callByHour);
            }
            else if (rbt_hotDay.Checked)
            {
                var dayAndValue = new Hashtable();
                if (txt_Top.Text.Trim().Equals("0"))
                {
                    var selectSql =
                        "SELECT  DATEADD(dd, 0, DATEDIFF(dd, 0, ode_Date)) ,SUM(ode_PaidMoney - ode_ImportPrice) FROM GSS_Order WHERE  (ode_CustomerId <> 0) AND (ode_Date BETWEEN '" +
                        from + "' AND '" + to +
                        "') GROUP BY DATEADD(dd, 0, DATEDIFF(dd, 0, ode_Date)) ORDER BY SUM(ode_PaidMoney - ode_ImportPrice) DESC";


                    var cmd = new SqlCommand(selectSql, _con);

                    _con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        dayAndValue.Add(reader[0].ToString(), reader[1].ToString());
                    }
                    reader.Close();
                    _con.Close();
                }
                else
                {
                    var selectSql = "SELECT TOP(" + txt_Top.Text.Trim() +
                                    ")  DATEADD(dd, 0, DATEDIFF(dd, 0, ode_Date)) ,SUM(ode_PaidMoney - ode_ImportPrice) FROM GSS_Order WHERE  (ode_CustomerId <> 0) AND (ode_Date BETWEEN '" +
                                    from + "' AND '" + to +
                                    "')GROUP BY DATEADD(dd, 0, DATEDIFF(dd, 0, ode_Date)) ORDER BY SUM(ode_PaidMoney - ode_ImportPrice) DESC";


                    var cmd = new SqlCommand(selectSql, _con);

                    _con.Open();
                    var reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        dayAndValue.Add(reader[0].ToString(), reader[1].ToString());
                    }
                    reader.Close();
                    _con.Close();
                }

                ExportHotDay(dayAndValue);
            }
            else if (rbt_callCustomer.Checked)
            {
                var orderAdapter = new GSS_OrderTableAdapter();

                var customerAndValue = new Hashtable();

                if (txt_Top.Text.Trim().Equals("0"))
                {
                    var selectSql =
                        "SELECT  ode_CustomerId FROM GSS_Order WHERE  (ode_CustomerId <> 0) AND (ode_Date BETWEEN '" +
                        from + "' AND '" + to +
                        "') GROUP BY ode_CustomerId ORDER BY SUM(ode_PaidMoney - ode_ImportPrice) DESC";


                    var cmd = new SqlCommand(selectSql, _con);

                    _con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        customerAndValue.Add(reader[0].ToString(),
                            orderAdapter.GetHotCustomerValue(Int32.Parse(reader[0].ToString())));
                    }
                    reader.Close();
                    _con.Close();
                }
                else
                {
                    var selectSql = "SELECT TOP(" + txt_Top.Text.Trim() +
                                    ") ode_CustomerId FROM GSS_Order WHERE  (ode_CustomerId <> 0) AND (ode_Date BETWEEN '" +
                                    from + "' AND '" + to +
                                    "') GROUP BY ode_CustomerId ORDER BY SUM(ode_PaidMoney - ode_ImportPrice) DESC";


                    var cmd = new SqlCommand(selectSql, _con);

                    _con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        customerAndValue.Add(reader[0].ToString(),
                            orderAdapter.GetHotCustomerValue(Int32.Parse(reader[0].ToString())));
                    }
                    reader.Close();
                    _con.Close();
                }

                ExportHotCustomer(customerAndValue);
            }
            else if (rbt_hotProduct.Checked)
            {
                var customerAndValue = new Hashtable();
                var selectSql = "";


                selectSql += "(SELECT   " + IDENTIFY_VALUE_SHELL + ", ode_ShellId, SUM(ode_Quantity)\n";
                selectSql += "FROM GSS_Order \n";
                selectSql +=
                    "WHERE  (ode_CustomerId <> 0) AND (ode_Date BETWEEN '1/31/2012 10:12:05 PM' AND '12/31/2012 10:12:05 PM') AND ode_ShellId IS NOT NULL\n";
                selectSql += "GROUP BY ode_ShellId)\n";

                selectSql += "UNION\n";

                selectSql += "(SELECT   " + IDENTIFY_VALUE_VALVE + ",ode_ValveId, SUM(ode_Quantity)\n";
                selectSql += "  FROM GSS_Order \n";
                selectSql +=
                    "WHERE  (ode_CustomerId <> 0) AND (ode_Date BETWEEN '1/31/2012 10:12:05 PM' AND '12/31/2012 10:12:05 PM') AND ode_ValveId IS NOT NULL\n";
                selectSql += "GROUP BY ode_ValveId)\n";

                selectSql += "UNION\n";

                selectSql += "(SELECT  " + IDENTIFY_VALUE_GAS + ", ode_GasId, SUM(ode_Quantity)\n";
                selectSql += " FROM GSS_Order \n";
                selectSql +=
                    " WHERE  (ode_CustomerId <> 0) AND (ode_Date BETWEEN '1/31/2012 10:12:05 PM' AND '12/31/2012 10:12:05 PM') AND ode_GasId IS NOT NULL\n";
                selectSql += "GROUP BY ode_GasId)\n";


                selectSql += " ORDER BY SUM(ode_Quantity) DESC\n";


                var cmd = new SqlCommand(selectSql, _con);

                _con.Open();
                SqlDataReader reader = cmd.ExecuteReader();


                if (txt_Top.Text.Trim().Equals("0"))
                {
                    while (reader.Read())
                    {
                        if (reader[0].ToString().Equals(IDENTIFY_VALUE_VALVE))
                        {
                            foreach (DataRow row in Parent.ValveTable.Rows)
                            {
                                if (row[1].ToString().Equals(reader[1].ToString()))
                                    customerAndValue.Add(row[0].ToString(), reader[2].ToString());
                                break;
                            }
                        }
                        else if (reader[0].ToString().Equals(IDENTIFY_VALUE_GAS))
                        {
                            foreach (DataRow row in Parent.GasTable.Rows)
                            {
                                if (row[1].ToString().Equals(reader[1].ToString()))
                                    customerAndValue.Add(row[0].ToString(), reader[2].ToString());
                                break;
                            }
                        }
                        else if (reader[0].ToString().Equals(IDENTIFY_VALUE_SHELL))
                        {
                            foreach (DataRow row in Parent.ShellTable.Rows)
                            {
                                if (row[1].ToString().Equals(reader[1].ToString()))
                                    customerAndValue.Add(row[0].ToString(), reader[2].ToString());
                                break;
                            }
                        }
                    }
                }
                else
                {
                    var loop = Int32.Parse(txt_Top.Text.Trim());
                    var count = 0;
                    while (reader.Read())
                    {
                        if (reader[0].ToString().Equals(IDENTIFY_VALUE_VALVE))
                        {
                            foreach (DataRow row in Parent.ValveTable.Rows)
                            {
                                if (row[1].ToString().Equals(reader[1].ToString()))
                                    customerAndValue.Add(row[0].ToString(), reader[2].ToString());
                                break;
                            }
                        }
                        else if (reader[0].ToString().Equals(IDENTIFY_VALUE_GAS))
                        {
                            foreach (DataRow row in Parent.GasTable.Rows)
                            {
                                if (row[1].ToString().Equals(reader[1].ToString()))
                                    customerAndValue.Add(row[0].ToString(), reader[2].ToString());
                                break;
                            }
                        }
                        else if (reader[0].ToString().Equals(IDENTIFY_VALUE_SHELL))
                        {
                            foreach (DataRow row in Parent.ShellTable.Rows)
                            {
                                if (row[1].ToString().Equals(reader[1].ToString()))
                                    customerAndValue.Add(row[0].ToString(), reader[2].ToString());
                                break;
                            }
                        }


                        count++;
                        if (count == loop)
                        {
                            break;
                        }
                    }
                }

                reader.Close();
                _con.Close();
                ExportHotProduct(customerAndValue);
            }
        }

        /// <summary>
        ///   Exports the call by hours.
        /// </summary>
        /// <param name = "callByHour">The call by hour.</param>
        private static void ExportCallByHour(String[] callByHour)
        {
            object misValue = Missing.Value;

            var xlApp = new Application {Visible = true};
            var xlWorkBook = xlApp.Workbooks.Add(misValue);
            var xlWorkSheet = (Worksheet) xlWorkBook.Worksheets.Item[1];

            //add data 
            xlWorkSheet.Cells[1, 1] = "Giờ";
            xlWorkSheet.Cells[1, 2] = "0h";
            xlWorkSheet.Cells[1, 3] = "1h";
            xlWorkSheet.Cells[1, 4] = "2h";
            xlWorkSheet.Cells[1, 5] = "3h";
            xlWorkSheet.Cells[1, 6] = "4h";
            xlWorkSheet.Cells[1, 7] = "5h";
            xlWorkSheet.Cells[1, 8] = "6h";
            xlWorkSheet.Cells[1, 9] = "7h";
            xlWorkSheet.Cells[1, 10] = "8h";
            xlWorkSheet.Cells[1, 11] = "9h";
            xlWorkSheet.Cells[1, 12] = "10h";
            xlWorkSheet.Cells[1, 13] = "11h";
            xlWorkSheet.Cells[1, 14] = "12h";
            xlWorkSheet.Cells[1, 15] = "13h";
            xlWorkSheet.Cells[1, 16] = "14h";
            xlWorkSheet.Cells[1, 17] = "15h";
            xlWorkSheet.Cells[1, 18] = "16h";
            xlWorkSheet.Cells[1, 19] = "17h";
            xlWorkSheet.Cells[1, 20] = "18h";
            xlWorkSheet.Cells[1, 21] = "19h";
            xlWorkSheet.Cells[1, 22] = "20h";
            xlWorkSheet.Cells[1, 23] = "21h";
            xlWorkSheet.Cells[1, 24] = "22h";
            xlWorkSheet.Cells[1, 25] = "23h";

            xlWorkSheet.Cells[2, 1] = "Số cuộc gọi";
            xlWorkSheet.Cells[2, 2] = callByHour[0];
            xlWorkSheet.Cells[2, 3] = callByHour[1];
            xlWorkSheet.Cells[2, 4] = callByHour[2];
            xlWorkSheet.Cells[2, 5] = callByHour[3];
            xlWorkSheet.Cells[2, 6] = callByHour[4];
            xlWorkSheet.Cells[2, 7] = callByHour[5];
            xlWorkSheet.Cells[2, 8] = callByHour[6];
            xlWorkSheet.Cells[2, 9] = callByHour[7];
            xlWorkSheet.Cells[2, 10] = callByHour[8];
            xlWorkSheet.Cells[2, 11] = callByHour[9];
            xlWorkSheet.Cells[2, 12] = callByHour[10];
            xlWorkSheet.Cells[2, 13] = callByHour[11];
            xlWorkSheet.Cells[2, 14] = callByHour[12];
            xlWorkSheet.Cells[2, 15] = callByHour[13];
            xlWorkSheet.Cells[2, 16] = callByHour[14];
            xlWorkSheet.Cells[2, 17] = callByHour[15];
            xlWorkSheet.Cells[2, 18] = callByHour[16];
            xlWorkSheet.Cells[2, 19] = callByHour[17];
            xlWorkSheet.Cells[2, 20] = callByHour[18];
            xlWorkSheet.Cells[2, 21] = callByHour[19];
            xlWorkSheet.Cells[2, 22] = callByHour[20];
            xlWorkSheet.Cells[2, 23] = callByHour[21];
            xlWorkSheet.Cells[2, 24] = callByHour[22];
            xlWorkSheet.Cells[2, 25] = callByHour[23];

            var xlCharts = (ChartObjects) xlWorkSheet.ChartObjects(Type.Missing);
            var myChart = xlCharts.Add(10, 80, 800, 250);
            var chartPage = myChart.Chart;

            var chartRange = xlWorkSheet.Range["A1", "Y2"];
            chartPage.SetSourceData(chartRange, misValue);
            chartPage.ChartType = XlChartType.xlColumnClustered;
        }

        /// <summary>
        ///   Exports the hot customer.
        /// </summary>
        /// <param name = "customerAndValue">The customer and value.</param>
        private static void ExportHotCustomer(Hashtable customerAndValue)
        {
            object misValue = Missing.Value;

            var xlApp = new Application {Visible = true};
            var xlWorkBook = xlApp.Workbooks.Add(misValue);
            var xlWorkSheet = (Worksheet) xlWorkBook.Worksheets.Item[1];

            //add data 
            xlWorkSheet.Cells[1, 1] = "Mã khách hàng";
            xlWorkSheet.Cells[2, 1] = "Lợi nhuận";

            var count = 2;
            foreach (var customer in customerAndValue.Keys)
            {
                xlWorkSheet.Cells[1, count] = customer.ToString();
                xlWorkSheet.Cells[2, count] = customerAndValue[customer].ToString();
                count++;
            }

            var xlCharts = (ChartObjects) xlWorkSheet.ChartObjects(Type.Missing);
            var myChart = xlCharts.Add(10, 80, 800, 250);
            var chartPage = myChart.Chart;

            var chartRange = xlWorkSheet.Range["A2", "Y2"];
            chartPage.SetSourceData(chartRange, misValue);
            chartPage.ChartType = XlChartType.xlColumnClustered;
        }

        /// <summary>
        ///   Exports the hot day.
        /// </summary>
        /// <param name = "customerAndValue">The customer and value.</param>
        private static void ExportHotDay(Hashtable customerAndValue)
        {
            object misValue = Missing.Value;

            var xlApp = new Application {Visible = true};
            var xlWorkBook = xlApp.Workbooks.Add(misValue);
            var xlWorkSheet = (Worksheet) xlWorkBook.Worksheets.Item[1];

            //add data 
            xlWorkSheet.Cells[1, 1] = "Ngày";
            xlWorkSheet.Cells[2, 1] = "Lợi nhuận";

            var count = 2;
            foreach (var customer in customerAndValue.Keys)
            {
                xlWorkSheet.Cells[1, count] = customer.ToString();
                xlWorkSheet.Cells[2, count] = customerAndValue[customer].ToString();
                count++;
            }

            var xlCharts = (ChartObjects) xlWorkSheet.ChartObjects(Type.Missing);
            var myChart = xlCharts.Add(10, 80, 800, 250);
            var chartPage = myChart.Chart;

            var chartRange = xlWorkSheet.Range["A2", "Y2"];
            chartPage.SetSourceData(chartRange, misValue);
            chartPage.ChartType = XlChartType.xlColumnClustered;
        }

        /// <summary>
        ///   Exports the hot product.
        /// </summary>
        /// <param name = "customerAndValue">The customer and value.</param>
        private static void ExportHotProduct(Hashtable customerAndValue)
        {
            object misValue = Missing.Value;

            var xlApp = new Application {Visible = true};
            var xlWorkBook = xlApp.Workbooks.Add(misValue);
            var xlWorkSheet = (Worksheet) xlWorkBook.Worksheets.Item[1];

            //add data 
            xlWorkSheet.Cells[1, 1] = "Tên hàng";
            xlWorkSheet.Cells[2, 1] = "Số lượng bán";

            var count = 2;
            foreach (var customer in customerAndValue.Keys)
            {
                xlWorkSheet.Cells[1, count] = customer.ToString();
                xlWorkSheet.Cells[2, count] = customerAndValue[customer].ToString();
                count++;
            }

            var xlCharts = (ChartObjects) xlWorkSheet.ChartObjects(Type.Missing);
            var myChart = xlCharts.Add(10, 80, 800, 250);
            var chartPage = myChart.Chart;

            var chartRange = xlWorkSheet.Range["A2", "Y2"];
            chartPage.SetSourceData(chartRange, misValue);
            chartPage.ChartType = XlChartType.xlColumnClustered;
        }


        /// <summary>
        ///   Handles the Changed event of the txt_Top control.
        /// </summary>
        private void txt_Top_Changed(object sender, EventArgs e)
        {
            for (var count = 0; count < txt_Top.Text.Length; count++)
            {
                if ((txt_Top.Text[count]) != '0'
                    && (txt_Top.Text[count]) != '1'
                    && (txt_Top.Text[count]) != '2'
                    && (txt_Top.Text[count]) != '3'
                    && (txt_Top.Text[count]) != '4'
                    && (txt_Top.Text[count]) != '5'
                    && (txt_Top.Text[count]) != '6'
                    && (txt_Top.Text[count]) != '7'
                    && (txt_Top.Text[count]) != '8'
                    && (txt_Top.Text[count]) != '9'
                    )
                {
                    txt_Top.Text = txt_Top.Text.Remove(count, 1);
                    count--;
                }
            }
        }

        /// <summary>
        ///   Handles the CheckedChanged event of the hotDate control.
        /// </summary>
        private void hotDate_CheckedChanged(object sender, EventArgs e)
        {
            txt_Top.Text = "10";
        }

        /// <summary>
        ///   Handles the CheckedChanged event of the hotProuct control.
        /// </summary>
        private void hotProuct_CheckedChanged(object sender, EventArgs e)
        {
            txt_Top.Text = "10";
        }

        /// <summary>
        ///   Handles the CheckedChanged event of the hotCustomer control.
        /// </summary>
        private void hotCustomer_CheckedChanged(object sender, EventArgs e)
        {
            txt_Top.Text = "10";
        }

        /// <summary>
        ///   Handles the Changed event of the hot_Hour control.
        /// </summary>
        private void hot_Hour_Changed(object sender, EventArgs e)
        {
            txt_Top.Text = "0";
        }

        /// <summary>
        ///   Handles the Changed event of the dtp_from control.
        /// </summary>
        private void dtp_from_Changed(object sender, EventArgs e)
        {
            if (dtp_to.Value.CompareTo(dtp_from.Value) < 0)
            {
                dtp_to.Value = dtp_from.Value;
            }
        }

        /// <summary>
        ///   Handles the Changed event of the dtp_to control.
        /// </summary>
        private void dtp_to_Changed(object sender, EventArgs e)
        {
            if (dtp_to.Value.CompareTo(dtp_from.Value) < 0)
            {
                dtp_to.Value = dtp_from.Value;
            }
        }
    }
}