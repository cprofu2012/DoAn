﻿namespace GSS.View.Menu_System
{
    partial class Form_Chart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Chart));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.labdkd = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtp_to = new System.Windows.Forms.DateTimePicker();
            this.dtp_from = new System.Windows.Forms.DateTimePicker();
            this.btn_Export = new System.Windows.Forms.Button();
            this.rbt_callHour = new System.Windows.Forms.RadioButton();
            this.rbt_hotProduct = new System.Windows.Forms.RadioButton();
            this.rbt_hotDay = new System.Windows.Forms.RadioButton();
            this.rbt_callCustomer = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_Top = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.labdkd);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.dtp_to);
            this.groupBox2.Controls.Add(this.dtp_from);
            this.groupBox2.Location = new System.Drawing.Point(18, 73);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(599, 54);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Lọc theo ngày";
            // 
            // labdkd
            // 
            this.labdkd.AutoSize = true;
            this.labdkd.Location = new System.Drawing.Point(305, 22);
            this.labdkd.Name = "labdkd";
            this.labdkd.Size = new System.Drawing.Size(27, 13);
            this.labdkd.TabIndex = 3;
            this.labdkd.Text = "Đến";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Từ";
            // 
            // dtp_to
            // 
            this.dtp_to.Location = new System.Drawing.Point(338, 19);
            this.dtp_to.Name = "dtp_to";
            this.dtp_to.Size = new System.Drawing.Size(242, 20);
            this.dtp_to.TabIndex = 1;
            this.dtp_to.ValueChanged += new System.EventHandler(this.dtp_to_Changed);
            // 
            // dtp_from
            // 
            this.dtp_from.Location = new System.Drawing.Point(49, 19);
            this.dtp_from.Name = "dtp_from";
            this.dtp_from.Size = new System.Drawing.Size(231, 20);
            this.dtp_from.TabIndex = 0;
            this.dtp_from.Value = new System.DateTime(2012, 1, 1, 0, 0, 0, 0);
            this.dtp_from.ValueChanged += new System.EventHandler(this.dtp_from_Changed);
            // 
            // btn_Export
            // 
            this.btn_Export.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Export.Image = ((System.Drawing.Image)(resources.GetObject("btn_Export.Image")));
            this.btn_Export.Location = new System.Drawing.Point(577, 211);
            this.btn_Export.Name = "btn_Export";
            this.btn_Export.Size = new System.Drawing.Size(40, 40);
            this.btn_Export.TabIndex = 0;
            this.toolTip1.SetToolTip(this.btn_Export, "Xuất Excel");
            this.btn_Export.UseVisualStyleBackColor = true;
            this.btn_Export.Click += new System.EventHandler(this.btn_Export_Click);
            // 
            // rbt_callHour
            // 
            this.rbt_callHour.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.rbt_callHour.AutoSize = true;
            this.rbt_callHour.Checked = true;
            this.rbt_callHour.Location = new System.Drawing.Point(20, 19);
            this.rbt_callHour.Name = "rbt_callHour";
            this.rbt_callHour.Size = new System.Drawing.Size(119, 17);
            this.rbt_callHour.TabIndex = 0;
            this.rbt_callHour.TabStop = true;
            this.rbt_callHour.Text = "Giờ gọi đông khách";
            this.rbt_callHour.UseVisualStyleBackColor = true;
            this.rbt_callHour.CheckedChanged += new System.EventHandler(this.hot_Hour_Changed);
            // 
            // rbt_hotProduct
            // 
            this.rbt_hotProduct.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.rbt_hotProduct.AutoSize = true;
            this.rbt_hotProduct.Location = new System.Drawing.Point(145, 19);
            this.rbt_hotProduct.Name = "rbt_hotProduct";
            this.rbt_hotProduct.Size = new System.Drawing.Size(122, 17);
            this.rbt_hotProduct.TabIndex = 1;
            this.rbt_hotProduct.Text = "Hàng bán chạy nhất";
            this.rbt_hotProduct.UseVisualStyleBackColor = true;
            this.rbt_hotProduct.CheckedChanged += new System.EventHandler(this.hotProuct_CheckedChanged);
            // 
            // rbt_hotDay
            // 
            this.rbt_hotDay.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.rbt_hotDay.AutoSize = true;
            this.rbt_hotDay.Location = new System.Drawing.Point(276, 19);
            this.rbt_hotDay.Name = "rbt_hotDay";
            this.rbt_hotDay.Size = new System.Drawing.Size(121, 17);
            this.rbt_hotDay.TabIndex = 2;
            this.rbt_hotDay.Text = "Ngày bán chạy nhất";
            this.rbt_hotDay.UseVisualStyleBackColor = true;
            this.rbt_hotDay.CheckedChanged += new System.EventHandler(this.hotDate_CheckedChanged);
            // 
            // rbt_callCustomer
            // 
            this.rbt_callCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.rbt_callCustomer.AutoSize = true;
            this.rbt_callCustomer.Location = new System.Drawing.Point(403, 19);
            this.rbt_callCustomer.Name = "rbt_callCustomer";
            this.rbt_callCustomer.Size = new System.Drawing.Size(158, 17);
            this.rbt_callCustomer.TabIndex = 3;
            this.rbt_callCustomer.Text = "Khách hàng nhiều lợi nhuận";
            this.rbt_callCustomer.UseVisualStyleBackColor = true;
            this.rbt_callCustomer.CheckedChanged += new System.EventHandler(this.hotCustomer_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.rbt_callHour);
            this.groupBox5.Controls.Add(this.rbt_callCustomer);
            this.groupBox5.Controls.Add(this.rbt_hotProduct);
            this.groupBox5.Controls.Add(this.rbt_hotDay);
            this.groupBox5.Location = new System.Drawing.Point(18, 11);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(599, 49);
            this.groupBox5.TabIndex = 12;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Loại biểu đồ";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.txt_Top);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(18, 141);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(599, 54);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Giới hạn lấy dữ liệu";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(340, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Note: 0 là lấy tất cả";
            // 
            // txt_Top
            // 
            this.txt_Top.Location = new System.Drawing.Point(49, 22);
            this.txt_Top.Name = "txt_Top";
            this.txt_Top.Size = new System.Drawing.Size(140, 20);
            this.txt_Top.TabIndex = 0;
            this.txt_Top.Text = "0";
            this.txt_Top.TextChanged += new System.EventHandler(this.txt_Top_Changed);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(195, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "bản ghi đầu tiên";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Lấy";
            // 
            // Form_Chart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 263);
            this.Controls.Add(this.btn_Export);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(646, 301);
            this.Name = "Form_Chart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Xuất biểu đồ";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label labdkd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtp_to;
        private System.Windows.Forms.DateTimePicker dtp_from;
        private System.Windows.Forms.Button btn_Export;
        private System.Windows.Forms.RadioButton rbt_callHour;
        private System.Windows.Forms.RadioButton rbt_hotProduct;
        private System.Windows.Forms.RadioButton rbt_hotDay;
        private System.Windows.Forms.RadioButton rbt_callCustomer;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txt_Top;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}