﻿using System;
using System.Collections;
using System.Windows.Forms;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_System
{
    /// <summary>
    ///   Edit product with shell's form
    /// </summary>
    public partial class EditProduct_WithShell : Form
    {
        private readonly Hashtable _gas = new Hashtable();
        private readonly GSS_GasTableAdapter _gasAdapter = new GSS_GasTableAdapter();
        private readonly GSS_GasShellTableAdapter _gasShellAdapter = new GSS_GasShellTableAdapter();

        private readonly Hashtable _gasshell = new Hashtable();
        private readonly Hashtable _price = new Hashtable();
        private readonly Hashtable _shell = new Hashtable();
        private readonly GSS_ShellTableAdapter _shellAdapter = new GSS_ShellTableAdapter();
        private readonly GSS_ValueTableAdapter _valueAdapter = new GSS_ValueTableAdapter();

        /// <summary>
        ///   Initializes a new instance of the "EditProduct_WithShell" form.
        /// </summary>
        public EditProduct_WithShell()
        {
            InitializeComponent();
            ShowProduct();
        }


        /// <summary>
        ///   Shows products.
        /// </summary>
        public void ShowProduct()
        {
            dtg_Products.Rows.Clear();

            _gasshell.Clear();
            _gas.Clear();
            _shell.Clear();
            _price.Clear();

            var gasshelldt = _gasShellAdapter.GetGasShell();
            foreach (var gasshellRow in gasshelldt)
            {
                _gasshell.Add(gasshellRow.gas_Id, gasshellRow.shell_id);
            }

            var gasdt = _gasAdapter.GetGass();
            foreach (var gasRow in gasdt)
            {
                _gas.Add(gasRow.gas_Id, gasRow);
            }

            var shelldt = _shellAdapter.GetShells();
            foreach (var shellRow in shelldt)
            {
                _shell.Add(shellRow.shell_Id, shellRow);
            }

            var valuedt = _valueAdapter.GetValues();
            foreach (var valueRow in valuedt)
            {
                _price.Add(valueRow.val_Id, valueRow.val_Price);
            }

            foreach (var key in _gasshell.Keys)
            {
                var gasId = key;
                var shellId = _gasshell[key];

                var gasInfo = (DataAccessLayer.GSS.GSS_GasRow) _gas[gasId];
                var shellInfo = (DataAccessLayer.GSS.GSS_ShellRow) _shell[shellId];

                var gasRow = new DataGridViewRow_ShelledProduct();
                dtg_Products.Rows.Add(gasRow);
                ((DataGridViewRow_ShelledProduct) dtg_Products.Rows[dtg_Products.Rows.Count - 1]).SetAttribute(false,
                    gasInfo.gas_Id);
                dtg_Products.Rows[dtg_Products.Rows.Count - 1].Cells[Definitions.PRODUCT_WITH_SHELL_NAME].Value =
                    gasInfo.gas_Name;
                dtg_Products.Rows[dtg_Products.Rows.Count - 1].Cells[Definitions.PRODUCT_WITH_SHELL_KIND].Value =
                    Resources.Intestine;
                dtg_Products.Rows[dtg_Products.Rows.Count - 1].Cells[Definitions.PRODUCT_WITH_SHELL_IMPORT].Value =
                    gasInfo.gas_Price;
                dtg_Products.Rows[dtg_Products.Rows.Count - 1].Cells[Definitions.PRODUCT_WITH_SHELL_PRICE].Value =
                    _price[gasInfo.value_Id];

                var shellRow = new DataGridViewRow_ShelledProduct();
                dtg_Products.Rows.Add(shellRow);
                ((DataGridViewRow_ShelledProduct) dtg_Products.Rows[dtg_Products.Rows.Count - 1]).SetAttribute(true,
                    shellInfo.shell_Id);
                dtg_Products.Rows[dtg_Products.Rows.Count - 1].Cells[Definitions.PRODUCT_WITH_SHELL_NAME].Value =
                    shellInfo.shell_Name;
                dtg_Products.Rows[dtg_Products.Rows.Count - 1].Cells[Definitions.PRODUCT_WITH_SHELL_KIND].Value =
                    Resources.Shell;
                dtg_Products.Rows[dtg_Products.Rows.Count - 1].Cells[Definitions.PRODUCT_WITH_SHELL_IMPORT].Value =
                    shellInfo.shell_Price;
                dtg_Products.Rows[dtg_Products.Rows.Count - 1].Cells[Definitions.PRODUCT_WITH_SHELL_PRICE].Value =
                    _price[shellInfo.value_Id];
            }
        }

        /// <summary>
        ///   Handles the Click event of the button Add.
        /// </summary>
        private void btn_add_Click(object sender, EventArgs e)
        {
            var editProductWithShellAdd = new EditProduct_WithShell_Add(this) {Text = Resources.Title_Add_Product};
            editProductWithShellAdd.ShowDialog();
        }

        /// <summary>
        ///   Handles the SelectionChanged event of the datagridview dtg_selection.
        /// </summary>
        private void dtg_selection_changed(object sender, EventArgs e)
        {
            btn_edit.Enabled = dtg_Products.SelectedRows.Count == 1;
        }

        /// <summary>
        ///   Handles the Click event of the button btn_edit.
        /// </summary>
        private void btn_edit_Click(object sender, EventArgs e)
        {
            if (((DataGridViewRow_ShelledProduct) dtg_Products.SelectedRows[0]).isShell)
            {
                var shellId = ((DataGridViewRow_ShelledProduct) dtg_Products.SelectedRows[0]).productId;
                var gasId = 0;

                foreach (var key in _gasshell.Keys)
                {
                    if (shellId == (int) _gasshell[key])
                    {
                        gasId = (int) key;
                    }
                }

                var gasInfo = (DataAccessLayer.GSS.GSS_GasRow) _gas[gasId];
                var shellInfo = (DataAccessLayer.GSS.GSS_ShellRow) _shell[shellId];


                var editProductWithShellAdd = new EditProduct_WithShell_Add(this, gasInfo, shellInfo)
                                                  {Text = Resources.Title_Edit_Product};
                editProductWithShellAdd.ShowDialog();
            }
            else
            {
                int gasId = ((DataGridViewRow_ShelledProduct) dtg_Products.SelectedRows[0]).productId;
                var shellId = (int) _gasshell[gasId];
                var gasInfo = (DataAccessLayer.GSS.GSS_GasRow) _gas[gasId];
                var shellInfo = (DataAccessLayer.GSS.GSS_ShellRow) _shell[shellId];

                var editProductWithShellAdd = new EditProduct_WithShell_Add(this, gasInfo, shellInfo)
                                                  {Text = Resources.Title_Edit_Product};
                editProductWithShellAdd.ShowDialog();
            }
        }
    }
}