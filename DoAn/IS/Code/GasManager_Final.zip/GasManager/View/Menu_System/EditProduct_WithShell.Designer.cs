﻿namespace GSS.View.Menu_System
{
    partial class EditProduct_WithShell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditProduct_WithShell));
            this.dtg_Products = new System.Windows.Forms.DataGridView();
            this.PRODUCT_WITH_SHELL_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRODUCT_WITH_SHELL_PRICE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRODUCT_WITH_SHELL_IMPORT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRODUCT_WITH_SHELL_KIND = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_edit = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Products)).BeginInit();
            this.SuspendLayout();
            // 
            // dtg_Products
            // 
            this.dtg_Products.AllowUserToAddRows = false;
            this.dtg_Products.AllowUserToDeleteRows = false;
            this.dtg_Products.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_Products.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_Products.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_Products.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PRODUCT_WITH_SHELL_NAME,
            this.PRODUCT_WITH_SHELL_PRICE,
            this.PRODUCT_WITH_SHELL_IMPORT,
            this.PRODUCT_WITH_SHELL_KIND});
            this.dtg_Products.Location = new System.Drawing.Point(12, 12);
            this.dtg_Products.Name = "dtg_Products";
            this.dtg_Products.ReadOnly = true;
            this.dtg_Products.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_Products.Size = new System.Drawing.Size(704, 493);
            this.dtg_Products.TabIndex = 0;
            this.dtg_Products.SelectionChanged += new System.EventHandler(this.dtg_selection_changed);
            // 
            // PRODUCT_WITH_SHELL_NAME
            // 
            this.PRODUCT_WITH_SHELL_NAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PRODUCT_WITH_SHELL_NAME.HeaderText = "Tên";
            this.PRODUCT_WITH_SHELL_NAME.Name = "PRODUCT_WITH_SHELL_NAME";
            this.PRODUCT_WITH_SHELL_NAME.ReadOnly = true;
            // 
            // PRODUCT_WITH_SHELL_PRICE
            // 
            this.PRODUCT_WITH_SHELL_PRICE.HeaderText = "Giá bán";
            this.PRODUCT_WITH_SHELL_PRICE.Name = "PRODUCT_WITH_SHELL_PRICE";
            this.PRODUCT_WITH_SHELL_PRICE.ReadOnly = true;
            // 
            // PRODUCT_WITH_SHELL_IMPORT
            // 
            this.PRODUCT_WITH_SHELL_IMPORT.HeaderText = "Giá nhập";
            this.PRODUCT_WITH_SHELL_IMPORT.Name = "PRODUCT_WITH_SHELL_IMPORT";
            this.PRODUCT_WITH_SHELL_IMPORT.ReadOnly = true;
            // 
            // PRODUCT_WITH_SHELL_KIND
            // 
            this.PRODUCT_WITH_SHELL_KIND.HeaderText = "Loại";
            this.PRODUCT_WITH_SHELL_KIND.Name = "PRODUCT_WITH_SHELL_KIND";
            this.PRODUCT_WITH_SHELL_KIND.ReadOnly = true;
            // 
            // btn_edit
            // 
            this.btn_edit.Enabled = false;
            this.btn_edit.Image = ((System.Drawing.Image)(resources.GetObject("btn_edit.Image")));
            this.btn_edit.Location = new System.Drawing.Point(676, 510);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(40, 40);
            this.btn_edit.TabIndex = 1;
            this.toolTip1.SetToolTip(this.btn_edit, "Sửa");
            this.btn_edit.UseVisualStyleBackColor = true;
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // btn_add
            // 
            this.btn_add.Image = ((System.Drawing.Image)(resources.GetObject("btn_add.Image")));
            this.btn_add.Location = new System.Drawing.Point(630, 510);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(40, 40);
            this.btn_add.TabIndex = 0;
            this.toolTip1.SetToolTip(this.btn_add, "Thêm");
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // EditProduct_WithShell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 562);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_edit);
            this.Controls.Add(this.dtg_Products);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EditProduct_WithShell";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách bình và vỏ";
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Products)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtg_Products;
        private System.Windows.Forms.Button btn_edit;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRODUCT_WITH_SHELL_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRODUCT_WITH_SHELL_PRICE;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRODUCT_WITH_SHELL_IMPORT;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRODUCT_WITH_SHELL_KIND;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}