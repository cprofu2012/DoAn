﻿namespace GSS.View.Menu_System
{
    partial class Form_Supplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Supplier));
            this.dtg_Supplier = new System.Windows.Forms.DataGridView();
            this.COLUMN_NAME_SUPPLIER_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_SUPPLIER_TEL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_SUPPLIER_ADDRESS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_SUPPLIER_NOTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_SUPPLIER_REMOVE = new System.Windows.Forms.DataGridViewImageColumn();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Supplier)).BeginInit();
            this.SuspendLayout();
            // 
            // dtg_Supplier
            // 
            this.dtg_Supplier.AllowUserToAddRows = false;
            this.dtg_Supplier.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_Supplier.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_Supplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_Supplier.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.COLUMN_NAME_SUPPLIER_NAME,
            this.COLUMN_NAME_SUPPLIER_TEL,
            this.COLUMN_NAME_SUPPLIER_ADDRESS,
            this.COLUMN_NAME_SUPPLIER_NOTE,
            this.COLUMN_NAME_SUPPLIER_REMOVE});
            this.dtg_Supplier.Location = new System.Drawing.Point(12, 12);
            this.dtg_Supplier.Name = "dtg_Supplier";
            this.dtg_Supplier.ReadOnly = true;
            this.dtg_Supplier.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_Supplier.Size = new System.Drawing.Size(722, 386);
            this.dtg_Supplier.TabIndex = 0;
            // 
            // COLUMN_NAME_SUPPLIER_NAME
            // 
            this.COLUMN_NAME_SUPPLIER_NAME.HeaderText = "Tên";
            this.COLUMN_NAME_SUPPLIER_NAME.Name = "COLUMN_NAME_SUPPLIER_NAME";
            this.COLUMN_NAME_SUPPLIER_NAME.ReadOnly = true;
            this.COLUMN_NAME_SUPPLIER_NAME.Width = 180;
            // 
            // COLUMN_NAME_SUPPLIER_TEL
            // 
            this.COLUMN_NAME_SUPPLIER_TEL.HeaderText = "Điện thoại";
            this.COLUMN_NAME_SUPPLIER_TEL.Name = "COLUMN_NAME_SUPPLIER_TEL";
            this.COLUMN_NAME_SUPPLIER_TEL.ReadOnly = true;
            // 
            // COLUMN_NAME_SUPPLIER_ADDRESS
            // 
            this.COLUMN_NAME_SUPPLIER_ADDRESS.HeaderText = "Địa chỉ";
            this.COLUMN_NAME_SUPPLIER_ADDRESS.Name = "COLUMN_NAME_SUPPLIER_ADDRESS";
            this.COLUMN_NAME_SUPPLIER_ADDRESS.ReadOnly = true;
            this.COLUMN_NAME_SUPPLIER_ADDRESS.Width = 200;
            // 
            // COLUMN_NAME_SUPPLIER_NOTE
            // 
            this.COLUMN_NAME_SUPPLIER_NOTE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.COLUMN_NAME_SUPPLIER_NOTE.HeaderText = "Ghi chú";
            this.COLUMN_NAME_SUPPLIER_NOTE.Name = "COLUMN_NAME_SUPPLIER_NOTE";
            this.COLUMN_NAME_SUPPLIER_NOTE.ReadOnly = true;
            // 
            // COLUMN_NAME_SUPPLIER_REMOVE
            // 
            this.COLUMN_NAME_SUPPLIER_REMOVE.HeaderText = "";
            this.COLUMN_NAME_SUPPLIER_REMOVE.Image = ((System.Drawing.Image)(resources.GetObject("COLUMN_NAME_SUPPLIER_REMOVE.Image")));
            this.COLUMN_NAME_SUPPLIER_REMOVE.Name = "COLUMN_NAME_SUPPLIER_REMOVE";
            this.COLUMN_NAME_SUPPLIER_REMOVE.ReadOnly = true;
            this.COLUMN_NAME_SUPPLIER_REMOVE.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.COLUMN_NAME_SUPPLIER_REMOVE.Width = 20;
            // 
            // btn_Save
            // 
            this.btn_Save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Save.Image = ((System.Drawing.Image)(resources.GetObject("btn_Save.Image")));
            this.btn_Save.Location = new System.Drawing.Point(694, 404);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(40, 40);
            this.btn_Save.TabIndex = 1;
            this.toolTip1.SetToolTip(this.btn_Save, "Lưu");
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_add
            // 
            this.btn_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_add.Image = ((System.Drawing.Image)(resources.GetObject("btn_add.Image")));
            this.btn_add.Location = new System.Drawing.Point(648, 404);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(40, 40);
            this.btn_add.TabIndex = 0;
            this.toolTip1.SetToolTip(this.btn_add, "Thêm");
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // Form_Supplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 451);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.dtg_Supplier);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_Supplier";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách nhà phân phối";
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Supplier)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtg_Supplier;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_SUPPLIER_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_SUPPLIER_TEL;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_SUPPLIER_ADDRESS;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_SUPPLIER_NOTE;
        private System.Windows.Forms.DataGridViewImageColumn COLUMN_NAME_SUPPLIER_REMOVE;
    }
}