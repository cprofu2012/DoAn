﻿using System.Windows.Forms;
using GSS.Properties;

namespace GSS.View.Menu_System
{
    /// <summary>
    /// Change bill template
    /// </summary>
    
    public partial class Form_Bill : Form
    {
        /// <summary>
        /// Initializes a new instance of the "Form_Bill" form.
        /// </summary>
        
        public Form_Bill()
        {
            InitializeComponent();

            txt_storename.Text = Settings.Default.NAME_STORE;
            txt_telephone.Text = Settings.Default.PHONES_STORE;
            txt_address.Text = Settings.Default.ADDRESS_STORE;
            txt_website.Text = Settings.Default.WEBSITE_STORE;
        }

        /// <summary>
        /// Save the change when close form.
        /// </summary>
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Settings.Default.NAME_STORE = txt_storename.Text;
            Settings.Default.PHONES_STORE = txt_telephone.Text;
            Settings.Default.ADDRESS_STORE = txt_address.Text;
            Settings.Default.WEBSITE_STORE = txt_website.Text;
            Settings.Default.Save();
            base.OnFormClosing(e);
        }
    }
}