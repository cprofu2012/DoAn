﻿namespace GSS.View.Menu_System
{
    partial class EditProduct_Normal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditProduct_Normal));
            this.dtg_Product = new System.Windows.Forms.DataGridView();
            this.EDIT_PRODUCT_NORMAL_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EDIT_PRODUCT_NORMAL_IMPORTPRICE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EDIT_PRODUCT_NORMAL_SELLPRICE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_edit = new System.Windows.Forms.Button();
            this.btn_Add = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Product)).BeginInit();
            this.SuspendLayout();
            // 
            // dtg_Product
            // 
            this.dtg_Product.AllowUserToAddRows = false;
            this.dtg_Product.AllowUserToDeleteRows = false;
            this.dtg_Product.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_Product.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dtg_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_Product.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EDIT_PRODUCT_NORMAL_NAME,
            this.EDIT_PRODUCT_NORMAL_IMPORTPRICE,
            this.EDIT_PRODUCT_NORMAL_SELLPRICE});
            this.dtg_Product.Location = new System.Drawing.Point(12, 12);
            this.dtg_Product.Name = "dtg_Product";
            this.dtg_Product.ReadOnly = true;
            this.dtg_Product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_Product.Size = new System.Drawing.Size(531, 391);
            this.dtg_Product.TabIndex = 0;
            this.dtg_Product.SelectionChanged += new System.EventHandler(this.dtg_SelectedChanged);
            // 
            // EDIT_PRODUCT_NORMAL_NAME
            // 
            this.EDIT_PRODUCT_NORMAL_NAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.EDIT_PRODUCT_NORMAL_NAME.HeaderText = "Tên";
            this.EDIT_PRODUCT_NORMAL_NAME.Name = "EDIT_PRODUCT_NORMAL_NAME";
            this.EDIT_PRODUCT_NORMAL_NAME.ReadOnly = true;
            // 
            // EDIT_PRODUCT_NORMAL_IMPORTPRICE
            // 
            this.EDIT_PRODUCT_NORMAL_IMPORTPRICE.HeaderText = "Giá nhập";
            this.EDIT_PRODUCT_NORMAL_IMPORTPRICE.Name = "EDIT_PRODUCT_NORMAL_IMPORTPRICE";
            this.EDIT_PRODUCT_NORMAL_IMPORTPRICE.ReadOnly = true;
            // 
            // EDIT_PRODUCT_NORMAL_SELLPRICE
            // 
            this.EDIT_PRODUCT_NORMAL_SELLPRICE.HeaderText = "Giá bán";
            this.EDIT_PRODUCT_NORMAL_SELLPRICE.Name = "EDIT_PRODUCT_NORMAL_SELLPRICE";
            this.EDIT_PRODUCT_NORMAL_SELLPRICE.ReadOnly = true;
            // 
            // btn_edit
            // 
            this.btn_edit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_edit.Enabled = false;
            this.btn_edit.Image = ((System.Drawing.Image)(resources.GetObject("btn_edit.Image")));
            this.btn_edit.Location = new System.Drawing.Point(503, 409);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(40, 40);
            this.btn_edit.TabIndex = 1;
            this.toolTip1.SetToolTip(this.btn_edit, "Sửa");
            this.btn_edit.UseVisualStyleBackColor = true;
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // btn_Add
            // 
            this.btn_Add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Add.Image = ((System.Drawing.Image)(resources.GetObject("btn_Add.Image")));
            this.btn_Add.Location = new System.Drawing.Point(457, 409);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(40, 40);
            this.btn_Add.TabIndex = 0;
            this.toolTip1.SetToolTip(this.btn_Add, "Thêm");
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // EditProduct_Normal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 452);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.btn_edit);
            this.Controls.Add(this.dtg_Product);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EditProduct_Normal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách sản phẩm";
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Product)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtg_Product;
        private System.Windows.Forms.Button btn_edit;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.DataGridViewTextBoxColumn EDIT_PRODUCT_NORMAL_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn EDIT_PRODUCT_NORMAL_IMPORTPRICE;
        private System.Windows.Forms.DataGridViewTextBoxColumn EDIT_PRODUCT_NORMAL_SELLPRICE;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}