﻿namespace GSS.View.Menu_System
{
    partial class Form_Bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Bill));
            this.dtg_bill = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_storename = new System.Windows.Forms.TextBox();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.txt_telephone = new System.Windows.Forms.TextBox();
            this.txt_website = new System.Windows.Forms.TextBox();
            this.lbl_customercode_ins = new System.Windows.Forms.Label();
            this.lbl_customernameins = new System.Windows.Forms.Label();
            this.lbl_phone_ins = new System.Windows.Forms.Label();
            this.lbl_address_ins = new System.Windows.Forms.Label();
            this.lbl_customercode = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_phone = new System.Windows.Forms.Label();
            this.lbl_address = new System.Windows.Forms.Label();
            this.txt_note = new System.Windows.Forms.Label();
            this.txt_note_ins = new System.Windows.Forms.Label();
            this.txt_money = new System.Windows.Forms.Label();
            this.txt_money_ins = new System.Windows.Forms.Label();
            this.txt_customer_sign = new System.Windows.Forms.Label();
            this.txt_deliver_sign = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_bill)).BeginInit();
            this.SuspendLayout();
            // 
            // dtg_bill
            // 
            this.dtg_bill.AllowUserToAddRows = false;
            this.dtg_bill.AllowUserToDeleteRows = false;
            this.dtg_bill.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtg_bill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_bill.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dtg_bill.Location = new System.Drawing.Point(35, 285);
            this.dtg_bill.Name = "dtg_bill";
            this.dtg_bill.Size = new System.Drawing.Size(524, 119);
            this.dtg_bill.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Stt";
            this.Column1.Name = "Column1";
            this.Column1.Width = 40;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "Tên hàng";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Số lượng";
            this.Column3.Name = "Column3";
            this.Column3.Width = 80;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Thành tiền";
            this.Column4.Name = "Column4";
            this.Column4.Width = 120;
            // 
            // txt_storename
            // 
            this.txt_storename.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_storename.Location = new System.Drawing.Point(162, 6);
            this.txt_storename.Name = "txt_storename";
            this.txt_storename.Size = new System.Drawing.Size(297, 29);
            this.txt_storename.TabIndex = 0;
            this.txt_storename.Text = "CÔNG TY TNHH GAS VIỆT NAM";
            this.txt_storename.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_address
            // 
            this.txt_address.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_address.Location = new System.Drawing.Point(121, 41);
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(378, 21);
            this.txt_address.TabIndex = 1;
            this.txt_address.Text = "Số 123 đường Phạm Hùng";
            // 
            // txt_telephone
            // 
            this.txt_telephone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_telephone.Location = new System.Drawing.Point(121, 69);
            this.txt_telephone.Name = "txt_telephone";
            this.txt_telephone.Size = new System.Drawing.Size(378, 20);
            this.txt_telephone.TabIndex = 2;
            this.txt_telephone.Text = "SĐT: 043.1234567 - 0912222222";
            // 
            // txt_website
            // 
            this.txt_website.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_website.Location = new System.Drawing.Point(121, 96);
            this.txt_website.Name = "txt_website";
            this.txt_website.Size = new System.Drawing.Size(378, 20);
            this.txt_website.TabIndex = 3;
            this.txt_website.Text = "Website: http://www.gas_seller.com";
            // 
            // lbl_customercode_ins
            // 
            this.lbl_customercode_ins.AutoSize = true;
            this.lbl_customercode_ins.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customercode_ins.Location = new System.Drawing.Point(32, 200);
            this.lbl_customercode_ins.Name = "lbl_customercode_ins";
            this.lbl_customercode_ins.Size = new System.Drawing.Size(45, 15);
            this.lbl_customercode_ins.TabIndex = 8;
            this.lbl_customercode_ins.Text = "Mã KH";
            // 
            // lbl_customernameins
            // 
            this.lbl_customernameins.AutoSize = true;
            this.lbl_customernameins.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customernameins.Location = new System.Drawing.Point(32, 218);
            this.lbl_customernameins.Name = "lbl_customernameins";
            this.lbl_customernameins.Size = new System.Drawing.Size(28, 15);
            this.lbl_customernameins.TabIndex = 9;
            this.lbl_customernameins.Text = "Tên";
            // 
            // lbl_phone_ins
            // 
            this.lbl_phone_ins.AutoSize = true;
            this.lbl_phone_ins.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_phone_ins.Location = new System.Drawing.Point(32, 235);
            this.lbl_phone_ins.Name = "lbl_phone_ins";
            this.lbl_phone_ins.Size = new System.Drawing.Size(31, 15);
            this.lbl_phone_ins.TabIndex = 10;
            this.lbl_phone_ins.Text = "SĐT";
            // 
            // lbl_address_ins
            // 
            this.lbl_address_ins.AutoSize = true;
            this.lbl_address_ins.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_address_ins.Location = new System.Drawing.Point(32, 252);
            this.lbl_address_ins.Name = "lbl_address_ins";
            this.lbl_address_ins.Size = new System.Drawing.Size(48, 15);
            this.lbl_address_ins.TabIndex = 11;
            this.lbl_address_ins.Text = "Địa chỉ:";
            // 
            // lbl_customercode
            // 
            this.lbl_customercode.AutoSize = true;
            this.lbl_customercode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customercode.Location = new System.Drawing.Point(98, 200);
            this.lbl_customercode.Name = "lbl_customercode";
            this.lbl_customercode.Size = new System.Drawing.Size(31, 15);
            this.lbl_customercode.TabIndex = 12;
            this.lbl_customercode.Text = "001";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(98, 218);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(129, 15);
            this.lbl_customername.TabIndex = 13;
            this.lbl_customername.Text = "Hoàng Thanh Tuấn";
            // 
            // lbl_phone
            // 
            this.lbl_phone.AutoSize = true;
            this.lbl_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_phone.Location = new System.Drawing.Point(98, 235);
            this.lbl_phone.Name = "lbl_phone";
            this.lbl_phone.Size = new System.Drawing.Size(184, 15);
            this.lbl_phone.TabIndex = 14;
            this.lbl_phone.Text = "0941234567 - 043 2345678";
            // 
            // lbl_address
            // 
            this.lbl_address.AutoSize = true;
            this.lbl_address.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_address.Location = new System.Drawing.Point(98, 252);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(289, 15);
            this.lbl_address.TabIndex = 15;
            this.lbl_address.Text = "Số 1 Đinh Tiên Hoàng - Hoàn Kiếm - Hà Nội";
            // 
            // txt_note
            // 
            this.txt_note.AutoSize = true;
            this.txt_note.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_note.Location = new System.Drawing.Point(98, 433);
            this.txt_note.Name = "txt_note";
            this.txt_note.Size = new System.Drawing.Size(215, 15);
            this.txt_note.TabIndex = 17;
            this.txt_note.Text = "Đem xe to chở 20 bình gas cũ về";
            // 
            // txt_note_ins
            // 
            this.txt_note_ins.AutoSize = true;
            this.txt_note_ins.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_note_ins.Location = new System.Drawing.Point(32, 433);
            this.txt_note_ins.Name = "txt_note_ins";
            this.txt_note_ins.Size = new System.Drawing.Size(52, 15);
            this.txt_note_ins.TabIndex = 16;
            this.txt_note_ins.Text = "Ghi chú:";
            // 
            // txt_money
            // 
            this.txt_money.AutoSize = true;
            this.txt_money.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_money.Location = new System.Drawing.Point(464, 407);
            this.txt_money.Name = "txt_money";
            this.txt_money.Size = new System.Drawing.Size(89, 15);
            this.txt_money.TabIndex = 19;
            this.txt_money.Text = "xxx.xxx đồng";
            // 
            // txt_money_ins
            // 
            this.txt_money_ins.AutoSize = true;
            this.txt_money_ins.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_money_ins.Location = new System.Drawing.Point(398, 407);
            this.txt_money_ins.Name = "txt_money_ins";
            this.txt_money_ins.Size = new System.Drawing.Size(61, 15);
            this.txt_money_ins.TabIndex = 18;
            this.txt_money_ins.Text = "Tổng tiền:";
            // 
            // txt_customer_sign
            // 
            this.txt_customer_sign.AutoSize = true;
            this.txt_customer_sign.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customer_sign.Location = new System.Drawing.Point(70, 483);
            this.txt_customer_sign.Name = "txt_customer_sign";
            this.txt_customer_sign.Size = new System.Drawing.Size(87, 15);
            this.txt_customer_sign.TabIndex = 20;
            this.txt_customer_sign.Text = "Khách hàng ký";
            // 
            // txt_deliver_sign
            // 
            this.txt_deliver_sign.AutoSize = true;
            this.txt_deliver_sign.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_deliver_sign.Location = new System.Drawing.Point(440, 483);
            this.txt_deliver_sign.Name = "txt_deliver_sign";
            this.txt_deliver_sign.Size = new System.Drawing.Size(78, 15);
            this.txt_deliver_sign.TabIndex = 21;
            this.txt_deliver_sign.Text = "Giao hàng ký";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(216, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 20);
            this.label1.TabIndex = 22;
            this.label1.Text = "HÓA ĐƠN BÁN HÀNG";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label2.Location = new System.Drawing.Point(237, 165);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "( giao cho khách hàng )";
            // 
            // Form_Bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 662);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_deliver_sign);
            this.Controls.Add(this.txt_customer_sign);
            this.Controls.Add(this.txt_money);
            this.Controls.Add(this.txt_money_ins);
            this.Controls.Add(this.txt_note);
            this.Controls.Add(this.txt_note_ins);
            this.Controls.Add(this.lbl_address);
            this.Controls.Add(this.lbl_phone);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.lbl_customercode);
            this.Controls.Add(this.lbl_address_ins);
            this.Controls.Add(this.lbl_phone_ins);
            this.Controls.Add(this.lbl_customernameins);
            this.Controls.Add(this.lbl_customercode_ins);
            this.Controls.Add(this.txt_website);
            this.Controls.Add(this.txt_telephone);
            this.Controls.Add(this.txt_address);
            this.Controls.Add(this.txt_storename);
            this.Controls.Add(this.dtg_bill);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(600, 700);
            this.MinimumSize = new System.Drawing.Size(600, 700);
            this.Name = "Form_Bill";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sửa hóa đơn";
            ((System.ComponentModel.ISupportInitialize)(this.dtg_bill)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtg_bill;
        private System.Windows.Forms.TextBox txt_storename;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.TextBox txt_telephone;
        private System.Windows.Forms.TextBox txt_website;
        private System.Windows.Forms.Label lbl_customercode_ins;
        private System.Windows.Forms.Label lbl_customernameins;
        private System.Windows.Forms.Label lbl_phone_ins;
        private System.Windows.Forms.Label lbl_address_ins;
        private System.Windows.Forms.Label lbl_customercode;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_phone;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.Label txt_note;
        private System.Windows.Forms.Label txt_note_ins;
        private System.Windows.Forms.Label txt_money;
        private System.Windows.Forms.Label txt_money_ins;
        private System.Windows.Forms.Label txt_customer_sign;
        private System.Windows.Forms.Label txt_deliver_sign;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}