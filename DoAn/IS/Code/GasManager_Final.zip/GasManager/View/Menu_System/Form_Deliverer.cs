﻿using System;
using System.Windows.Forms;
using GasManager;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_System
{
    /// <summary>
    ///   Deliverer management form
    /// </summary>
    public partial class Form_Deliverer : Form
    {
        private readonly GSS_DelivererTableAdapter _deliverAdapter = new GSS_DelivererTableAdapter();

        private readonly MainForm _mainForm;

        /// <summary>
        ///   Initializes a new instance of the "Form_Deliverer" form.
        /// </summary>
        /// <param name = "mainForm">The main form.</param>
        public Form_Deliverer(MainForm mainForm)
        {
            InitializeComponent();

            _mainForm = mainForm;

            dtg_Deliverer.CellClick += dtg_Deliverer_CellClick;

            LoadDeliver();
        }

        /// <summary>
        ///   Handles the CellClick event of the DataGridView dtg_Deliverer.
        /// </summary>
        private void dtg_Deliverer_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dtg_Deliverer.Columns[Definitions.COLUMN_NAME_DELIVERER_REMOVE].Index)
            {
                var result =
                    MessageBox.Show(
                        string.Format(Resources.Deliverer_Delete_Confirm,
                            (dtg_Deliverer.Rows[e.RowIndex]).Cells[Definitions.COLUMN_NAME_DELIVERER_NAME].Value),
                        Resources.Msb_Title_Delete_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (((DataGridViewRow_Deliverer) dtg_Deliverer.Rows[e.RowIndex]).deliver == null)
                    {
                        dtg_Deliverer.Rows.RemoveAt(e.RowIndex);
                    }
                    else
                    {
                        try
                        {
                            _deliverAdapter.DeleteDeliverer(
                                ((DataGridViewRow_Deliverer) dtg_Deliverer.Rows[e.RowIndex]).deliver.del_Id);
                            dtg_Deliverer.Rows.RemoveAt(e.RowIndex);
                            LoadDeliver();
                        }
                        catch (Exception)
                        {
                            MessageBox.Show(Resources.Deliverer_Delete_Error, Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }


        /// <summary>
        ///   Loads delivers.
        /// </summary>
        private void LoadDeliver()
        {
            try
            {
                dtg_Deliverer.Rows.Clear();
                var delivers = _deliverAdapter.GetDeliverers();
                foreach (var deliver in delivers)
                {
                    var dtw = new DataGridViewRow_Deliverer();
                    dtg_Deliverer.Rows.Add(dtw);
                    ((DataGridViewRow_Deliverer) dtg_Deliverer.Rows[dtg_Deliverer.Rows.Count - 1]).deliver = deliver;
                    (dtg_Deliverer.Rows[dtg_Deliverer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_DELIVERER_NAME].
                        Value = deliver.del_Name;
                    (dtg_Deliverer.Rows[dtg_Deliverer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_DELIVERER_TEL].
                        Value = deliver.del_telephone;
                    (dtg_Deliverer.Rows[dtg_Deliverer.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_DELIVERER_CMT].
                        Value = (deliver.IsNull("del_comment") ? "" : deliver.del_comment);
                }
                _mainForm.LoadDeliver();
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        ///   Handles the Click event of the btn_AddDeliverer control.
        /// </summary>
        private void btn_AddDeliverer_Click(object sender, EventArgs e)
        {
            var dtw = new DataGridViewRow_Deliverer();
            dtg_Deliverer.Rows.Add(dtw);
        }

        /// <summary>
        ///   Handles the Click event of the button Save.
        /// </summary>
        private void btn_save_Click(object sender, EventArgs e)
        {
            var errCode = "";
            var forgetName = false;
            var forgetNumber = false;
            var tenNumber = false;
            var number = false;

            loopagain:
            foreach (DataGridViewRow_Deliverer deliver in dtg_Deliverer.Rows)
            {
                if ((deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_NAME].Value == null ||
                     deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_NAME].Value.ToString().Trim().Length == 0)
                    &&
                    (deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_TEL].Value == null ||
                     deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_TEL].Value.ToString().Trim().Length == 0)
                    &&
                    (deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_CMT].Value == null ||
                     deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_CMT].Value.ToString().Trim().Length == 0)
                    && deliver.deliver == null)
                {
                    dtg_Deliverer.Rows.Remove(deliver);
                    goto loopagain;
                }

                if (deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_NAME].Value == null ||
                    deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_NAME].Value.ToString().Trim().Length == 0)
                {
                    forgetName = true;
                }
                else if (deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_TEL].Value == null ||
                         deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_TEL].Value.ToString().Trim().Length == 0)
                {
                    forgetNumber = true;
                }

                try
                {
                    if (deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_TEL].Value.ToString().Trim().Length < 10)
                    {
                        tenNumber = true;
                    }
                    Int64.Parse(deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_TEL].Value.ToString());
                }
                catch (Exception)
                {
                    number = true;
                }
            }

            if (forgetName)
                errCode += Resources.Missing_User_Name;
            if (forgetNumber)
                errCode += Resources.Missing_User_Phone;
            if (tenNumber)
                errCode += Resources.Msb_PhoneNo_Digit + "\r\n";
            if (number)
                errCode += Resources.Msb_Phone_Number_Error + "\r\n";

            if (errCode.Trim().Length > 0)
            {
                MessageBox.Show(errCode);
            }
            else
            {
                foreach (DataGridViewRow_Deliverer deliver in dtg_Deliverer.Rows)
                {
                    if (deliver.deliver != null)
                    {
                        _deliverAdapter.UpdateDeliver(
                            deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_NAME].Value.ToString(),
                            deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_TEL].Value.ToString(),
                            deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_CMT].Value == null
                                ? ""
                                : deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_CMT].Value.ToString(),
                            deliver.deliver.del_Id);
                    }
                    else if (deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_NAME].Value.ToString().Trim().Length > 0
                             && deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_TEL].Value.ToString().Trim().Length > 0)
                    {
                        _deliverAdapter.InsertDeliverer(
                            deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_NAME].Value.ToString(),
                            deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_TEL].Value.ToString(),
                            deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_CMT].Value == null
                                ? ""
                                : deliver.Cells[Definitions.COLUMN_NAME_DELIVERER_CMT].Value.ToString());
                    }
                }

                LoadDeliver();
            }
        }
    }
}