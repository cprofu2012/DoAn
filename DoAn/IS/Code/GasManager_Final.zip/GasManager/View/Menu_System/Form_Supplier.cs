﻿using System;
using System.Windows.Forms;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_System
{
    /// <summary>
    /// Supplier maganement form
    /// </summary>
    public partial class Form_Supplier : Form
    {
        private readonly GSS_SuppliersTableAdapter _supplierAdapter = new GSS_SuppliersTableAdapter();

        /// <summary>
        /// Initializes a new instance of the "Form_Supplier" form.
        /// </summary>
        public Form_Supplier()
        {
            InitializeComponent();
            dtg_Supplier.CellClick += dtg_Deliverer_CellClick;
            LoadSupplier();
        }

        /// <summary>
        /// Handles the CellClick event of the datagridview Deliverer.
        /// </summary>
        private void dtg_Deliverer_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dtg_Supplier.Columns[Definitions.COLUMN_NAME_SUPPLIER_REMOVE].Index)
            {
                var result =
                    MessageBox.Show(
                        string.Format(Resources.Deliverer_Delete_Confirm,
                            (dtg_Supplier.Rows[e.RowIndex]).Cells[Definitions.COLUMN_NAME_SUPPLIER_NAME].Value),
                        Resources.Msb_Title_Delete_Confirm, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (((DataGridViewRow_Supplier) dtg_Supplier.Rows[e.RowIndex]).supplier == null)
                    {
                        dtg_Supplier.Rows.RemoveAt(e.RowIndex);
                    }
                    else
                    {
                        try
                        {
                            _supplierAdapter.DeleteSupplier(
                                ((DataGridViewRow_Supplier) dtg_Supplier.Rows[e.RowIndex]).supplier.sup_Id);
                            dtg_Supplier.Rows.RemoveAt(e.RowIndex);
                            LoadSupplier();
                        }
                        catch (Exception)
                        {
                            MessageBox.Show(Resources.Deliverer_Delete_Error, Resources.Msb_Title_Error,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Loads the suppliers.
        /// </summary>
        private void LoadSupplier()
        {
            try
            {
                dtg_Supplier.Rows.Clear();
                var suppliers = _supplierAdapter.GetSuppliers();
                foreach (var supplier in suppliers)
                {
                    var dtw = new DataGridViewRow_Supplier();
                    dtg_Supplier.Rows.Add(dtw);
                    ((DataGridViewRow_Supplier) dtg_Supplier.Rows[dtg_Supplier.Rows.Count - 1]).supplier = supplier;
                    (dtg_Supplier.Rows[dtg_Supplier.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_SUPPLIER_NAME].Value
                        = supplier.sup_Representative;
                    (dtg_Supplier.Rows[dtg_Supplier.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_SUPPLIER_TEL].Value =
                        supplier.sup_Telephone;
                    (dtg_Supplier.Rows[dtg_Supplier.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_SUPPLIER_ADDRESS].
                        Value = supplier.sup_Address;
                    (dtg_Supplier.Rows[dtg_Supplier.Rows.Count - 1]).Cells[Definitions.COLUMN_NAME_SUPPLIER_NOTE].Value
                        = (supplier.IsNull("sup_Note") ? "" : supplier.sup_Note);
                }
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Handles the Click event of the button Save.
        /// </summary>
        private void btn_Save_Click(object sender, EventArgs e)
        {
            var forgetName = false;
            var forgetNumber = false;
            var forgetAddress = false;
            var tenNumber = false;
            var number = false;
            var errCode = "";
            loopagain:
            foreach (DataGridViewRow_Supplier supplier in dtg_Supplier.Rows)
            {
                if ((supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NAME].Value == null ||
                     supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NAME].Value.ToString().Trim().Length == 0)
                    &&
                    (supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_TEL].Value == null ||
                     supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_TEL].Value.ToString().Trim().Length == 0)
                    &&
                    (supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NOTE].Value == null ||
                     supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NOTE].Value.ToString().Trim().Length == 0)
                    &&
                    (supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_ADDRESS].Value == null ||
                     supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_ADDRESS].Value.ToString().Trim().Length == 0)
                    && supplier.supplier == null)
                {
                    dtg_Supplier.Rows.Remove(supplier);
                    goto loopagain;
                }

                if (supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NAME].Value == null ||
                    supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NAME].Value.ToString().Trim().Length == 0)
                {
                    forgetName = true;
                }
                else if (supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_TEL].Value == null ||
                         supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_TEL].Value.ToString().Trim().Length == 0)
                {
                    forgetNumber = true;
                }
                else if (supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_ADDRESS].Value == null ||
                         supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_ADDRESS].Value.ToString().Trim().Length == 0)
                {
                    forgetAddress = true;
                }

                try
                {
                    if (supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_TEL].Value.ToString().Trim().Length < 10)
                    {
                        tenNumber = true;
                    }
                    Int64.Parse(supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_TEL].Value.ToString());
                }
                catch (Exception)
                {
                    number = true;
                }
            }

            if (forgetName)
                errCode += "Bạn chưa điền tên nhà cung cấp\r\n";
            if (forgetNumber)
                errCode += "Bạn chưa điền Số điện thoại nhà cung cấp\r\n";
            if (tenNumber)
                errCode += "Số điện thoại nhà cung cấp phải có ít nhất 10 chữ số\r\n";
            if (number)
                errCode += "Số điện thoại nhà cung cấp phải là số\r\n";
            if (forgetAddress)
                errCode += "Bạn chưa điền địa chỉ nhà cung cấp\r\n";


            if (errCode.Trim().Length > 0)
            {
                MessageBox.Show(errCode);
            }
            else
            {
                foreach (DataGridViewRow_Supplier supplier in dtg_Supplier.Rows)
                {
                    if (supplier.supplier != null)
                    {
                        _supplierAdapter.UpdateSupplier(
                            supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NAME].Value.ToString(),
                            supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_TEL].Value.ToString(),
                            supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_ADDRESS].Value.ToString(),
                            supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NOTE].Value == null
                                ? ""
                                : supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NOTE].Value.ToString(),
                            supplier.supplier.sup_Id);
                    }
                    else if (supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NAME].Value.ToString().Trim().Length > 0
                             && supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_TEL].Value.ToString().Trim().Length > 0)
                    {
                        _supplierAdapter.InsertSupplier(
                            supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NAME].Value.ToString(),
                            supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_TEL].Value.ToString(),
                            supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_ADDRESS].Value.ToString(),
                            supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NOTE].Value == null
                                ? ""
                                : supplier.Cells[Definitions.COLUMN_NAME_SUPPLIER_NOTE].Value.ToString());
                    }
                }

                LoadSupplier();
            }
        }

        /// <summary>
        /// Handles the Click event of the button Add.
        /// </summary>
        private void btn_add_Click(object sender, EventArgs e)
        {
            var dtw = new DataGridViewRow_Supplier();
            dtg_Supplier.Rows.Add(dtw);
        }
    }
}