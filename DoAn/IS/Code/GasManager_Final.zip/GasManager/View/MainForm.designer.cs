﻿namespace GasManager
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ImageList editImageList;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.editTreeView = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tsmi_system = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchHàngHóaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sửXóaMãBìnhVàMãVỏToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sửaXóaMãHàngThôngThườngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smi_deliverer = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchNhàCungCấpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.càiĐặtModemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.càiĐặtMẫuHóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tạoBảnSaoDữLiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phụcHồiTừBảnSaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiệnÍchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sốMãToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sốBánToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chămSócKMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhậpHàngTừSảnXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xuấtHàngĐểTiêuDùngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kiểmHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kếToánToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doanhThuBánHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêBánHàngNhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchKháchNợVỏToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchKháchNợTiềnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listPanel = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpn_order = new System.Windows.Forms.TabPage();
            this.label28 = new System.Windows.Forms.Label();
            this.txt_CustomerRecordFilter = new System.Windows.Forms.TextBox();
            this.ckb_CustomerRecordFilter = new System.Windows.Forms.CheckBox();
            this.ckb_CustomerDateFilter = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.dtg_Order = new System.Windows.Forms.DataGridView();
            this.COLUMN_NAME_ORDER_SELLCODE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_ORDER_CUSNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_ORDER_CUSTEL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_ORDER_CUSADD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_ORDER_GOODKIND = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_ORDER_QUANTITY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_ORDER_PRICE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_ORDER_DELIVERER = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_ORDER_SELLDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_ORDER_REMOVE = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dtp_ToDate = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.earchLabel = new System.Windows.Forms.Label();
            this.dtp_FromDate = new System.Windows.Forms.DateTimePicker();
            this.txt_searchOrder = new System.Windows.Forms.TextBox();
            this.btn_AddNewOrder = new System.Windows.Forms.Button();
            this.btn_EditExistingOrder = new System.Windows.Forms.Button();
            this.tpn_customer = new System.Windows.Forms.TabPage();
            this.btn_addorder = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.dtg_Customer = new System.Windows.Forms.DataGridView();
            this.COLUMN_NAME_CUSTOMER_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_CUSTOMER_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_CUSTOMER_ADDRESS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_CUSTOMER_DISTRICT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_CUSTOMER_CITY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_CUSTOMER_HOMEPHONE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_CUSTOMER_MOBILE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLUMN_NAME_CUSTOMER_REMOVE = new System.Windows.Forms.DataGridViewButtonColumn();
            this.txt_SearchCustomer = new System.Windows.Forms.TextBox();
            this.btn_EditUser = new System.Windows.Forms.Button();
            this.btn_AddNewUser = new System.Windows.Forms.Button();
            this.editPanel = new System.Windows.Forms.Panel();
            this.btn_addCustomerOrder = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ptb_map = new System.Windows.Forms.PictureBox();
            this.btn_map = new System.Windows.Forms.Button();
            this.btn_MobileDiary = new System.Windows.Forms.Button();
            this.btn_HomephoneDiary = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_DistrictCustomer = new System.Windows.Forms.TextBox();
            this.txt_CityCustomer = new System.Windows.Forms.TextBox();
            this.txt_MobileCutomer = new System.Windows.Forms.TextBox();
            this.txt_HomePhoneCustomer = new System.Windows.Forms.TextBox();
            this.btn_SaveCustomer = new System.Windows.Forms.Button();
            this.btn_CloseEditting = new System.Windows.Forms.Button();
            this.txt_NameCustomer = new System.Windows.Forms.TextBox();
            this.txt_AddressCustomer = new System.Windows.Forms.TextBox();
            this.txt_IdCustomer = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grb_OrderDetails = new System.Windows.Forms.GroupBox();
            this.lbl_borrow = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.lbl_BorrowMoney = new System.Windows.Forms.Label();
            this.lbl_BorrowShell = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txt_PaidMoney = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txt_ReturnShell = new System.Windows.Forms.TextBox();
            this.txt_OrderQuantity = new System.Windows.Forms.TextBox();
            this.cbb_OrderKindGood = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cbb_OrderDeliverer = new System.Windows.Forms.ComboBox();
            this.txt_OrderPrice = new System.Windows.Forms.TextBox();
            this.dt_OrderSellDate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cbb_OrderGoodCode = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_OrderComment = new System.Windows.Forms.TextBox();
            this.lbl_ActionStatus = new System.Windows.Forms.Label();
            this.pnl_EditOrder = new System.Windows.Forms.Panel();
            this.ptb_order = new System.Windows.Forms.PictureBox();
            this.txt_OrderId = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cbb_Customer = new System.Windows.Forms.ComboBox();
            this.btn_OrderPrint = new System.Windows.Forms.Button();
            this.btn_OrderSave = new System.Windows.Forms.Button();
            this.btn_OrderClose = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txt_OrderCustomerDistrict = new System.Windows.Forms.TextBox();
            this.txt_OrderCustomerCity = new System.Windows.Forms.TextBox();
            this.txt_OrderCustomerMobile = new System.Windows.Forms.TextBox();
            this.txt_OrderCustomerHomePhone = new System.Windows.Forms.TextBox();
            this.txt_OrderCustomerName = new System.Windows.Forms.TextBox();
            this.txt_OrderCustomerAddess = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.tmr_SearchOrder = new System.Windows.Forms.Timer(this.components);
            this.tmr_SearchCustomer = new System.Windows.Forms.Timer(this.components);
            this.sfd_ChooseBackupDBLocation = new System.Windows.Forms.SaveFileDialog();
            this.ofd_ChooseBackupDB = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiệnÍchToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gọiĐiệnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gửiTinNhắnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhậtXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tàiKhoảnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.prd_Order = new System.Windows.Forms.PrintDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_SendMessage = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_Call = new System.Windows.Forms.Button();
            this.btn_duecustomer = new System.Windows.Forms.Button();
            this.btn_salary = new System.Windows.Forms.Button();
            this.btn_chart = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.btn_exportexcel = new System.Windows.Forms.Button();
            this.btn_diary = new System.Windows.Forms.Button();
            this.lbl_modemStatus = new System.Windows.Forms.Label();
            this.tmr_CheckModem = new System.Windows.Forms.Timer(this.components);
            this.valveOrdersTableAdapter1 = new GSS.DataAccessLayer.GSSTableAdapters.ValveOrdersTableAdapter();
            this.tmr_UpdateStatus = new System.Windows.Forms.Timer(this.components);
            this.pnl_Call = new System.Windows.Forms.Panel();
            this.btn_Hangup = new System.Windows.Forms.Button();
            this.lbl_PhoneNo = new System.Windows.Forms.Label();
            this.lbl_Timer = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.tmr_Call = new System.Windows.Forms.Timer(this.components);
            editImageList = new System.Windows.Forms.ImageList(this.components);
            this.listPanel.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpn_order.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Order)).BeginInit();
            this.tpn_customer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Customer)).BeginInit();
            this.editPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_map)).BeginInit();
            this.grb_OrderDetails.SuspendLayout();
            this.pnl_EditOrder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_order)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnl_Call.SuspendLayout();
            this.SuspendLayout();
            // 
            // editImageList
            // 
            editImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("editImageList.ImageStream")));
            editImageList.TransparentColor = System.Drawing.Color.Transparent;
            editImageList.Images.SetKeyName(0, "group (2).png");
            editImageList.Images.SetKeyName(1, "user_edit.png");
            editImageList.Images.SetKeyName(2, "phone_sound.png");
            editImageList.Images.SetKeyName(3, "chart_curve_edit.png");
            // 
            // editTreeView
            // 
            resources.ApplyResources(this.editTreeView, "editTreeView");
            this.editTreeView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editTreeView.ImageList = this.imageList1;
            this.editTreeView.ItemHeight = 27;
            this.editTreeView.Name = "editTreeView";
            this.editTreeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            ((System.Windows.Forms.TreeNode)(resources.GetObject("editTreeView.Nodes"))),
            ((System.Windows.Forms.TreeNode)(resources.GetObject("editTreeView.Nodes1"))),
            ((System.Windows.Forms.TreeNode)(resources.GetObject("editTreeView.Nodes2"))),
            ((System.Windows.Forms.TreeNode)(resources.GetObject("editTreeView.Nodes3")))});
            this.editTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.editTreeView_AfterSelect);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "user_suit.png");
            this.imageList1.Images.SetKeyName(1, "user_edit.png");
            this.imageList1.Images.SetKeyName(2, "phone_sound.png");
            this.imageList1.Images.SetKeyName(3, "chart_line_edit.png");
            this.imageList1.Images.SetKeyName(4, "1.png");
            this.imageList1.Images.SetKeyName(5, "2.png");
            this.imageList1.Images.SetKeyName(6, "3.png");
            this.imageList1.Images.SetKeyName(7, "4.png");
            this.imageList1.Images.SetKeyName(8, "5.png");
            this.imageList1.Images.SetKeyName(9, "ìninitive.png");
            this.imageList1.Images.SetKeyName(10, "cancel (2).png");
            this.imageList1.Images.SetKeyName(11, "cancel (2).png");
            // 
            // tsmi_system
            // 
            this.tsmi_system.Name = "tsmi_system";
            resources.ApplyResources(this.tsmi_system, "tsmi_system");
            // 
            // danhSáchHàngHóaToolStripMenuItem
            // 
            this.danhSáchHàngHóaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sửXóaMãBìnhVàMãVỏToolStripMenuItem,
            this.sửaXóaMãHàngThôngThườngToolStripMenuItem});
            this.danhSáchHàngHóaToolStripMenuItem.Name = "danhSáchHàngHóaToolStripMenuItem";
            resources.ApplyResources(this.danhSáchHàngHóaToolStripMenuItem, "danhSáchHàngHóaToolStripMenuItem");
            // 
            // sửXóaMãBìnhVàMãVỏToolStripMenuItem
            // 
            this.sửXóaMãBìnhVàMãVỏToolStripMenuItem.Name = "sửXóaMãBìnhVàMãVỏToolStripMenuItem";
            resources.ApplyResources(this.sửXóaMãBìnhVàMãVỏToolStripMenuItem, "sửXóaMãBìnhVàMãVỏToolStripMenuItem");
            this.sửXóaMãBìnhVàMãVỏToolStripMenuItem.Click += new System.EventHandler(this.sửXóaMãBìnhVàMãVỏToolStripMenuItem_Click);
            // 
            // sửaXóaMãHàngThôngThườngToolStripMenuItem
            // 
            this.sửaXóaMãHàngThôngThườngToolStripMenuItem.Name = "sửaXóaMãHàngThôngThườngToolStripMenuItem";
            resources.ApplyResources(this.sửaXóaMãHàngThôngThườngToolStripMenuItem, "sửaXóaMãHàngThôngThườngToolStripMenuItem");
            this.sửaXóaMãHàngThôngThườngToolStripMenuItem.Click += new System.EventHandler(this.sửaXóaMãHàngThôngThườngToolStripMenuItem_Click);
            // 
            // smi_deliverer
            // 
            this.smi_deliverer.Name = "smi_deliverer";
            resources.ApplyResources(this.smi_deliverer, "smi_deliverer");
            this.smi_deliverer.Click += new System.EventHandler(this.smi_deliverer_Click);
            // 
            // danhSáchNhàCungCấpToolStripMenuItem
            // 
            this.danhSáchNhàCungCấpToolStripMenuItem.Name = "danhSáchNhàCungCấpToolStripMenuItem";
            resources.ApplyResources(this.danhSáchNhàCungCấpToolStripMenuItem, "danhSáchNhàCungCấpToolStripMenuItem");
            this.danhSáchNhàCungCấpToolStripMenuItem.Click += new System.EventHandler(this.danhSáchNhàCungCấpToolStripMenuItem_Click);
            // 
            // càiĐặtModemToolStripMenuItem
            // 
            this.càiĐặtModemToolStripMenuItem.Name = "càiĐặtModemToolStripMenuItem";
            resources.ApplyResources(this.càiĐặtModemToolStripMenuItem, "càiĐặtModemToolStripMenuItem");
            this.càiĐặtModemToolStripMenuItem.Click += new System.EventHandler(this.kiểmTraModemToolStripMenuItem_Click);
            // 
            // càiĐặtMẫuHóaĐơnToolStripMenuItem
            // 
            this.càiĐặtMẫuHóaĐơnToolStripMenuItem.Name = "càiĐặtMẫuHóaĐơnToolStripMenuItem";
            resources.ApplyResources(this.càiĐặtMẫuHóaĐơnToolStripMenuItem, "càiĐặtMẫuHóaĐơnToolStripMenuItem");
            this.càiĐặtMẫuHóaĐơnToolStripMenuItem.Click += new System.EventHandler(this.càiĐặtMẫuHóaĐơnToolStripMenuItem_Click);
            // 
            // tạoBảnSaoDữLiệuToolStripMenuItem
            // 
            this.tạoBảnSaoDữLiệuToolStripMenuItem.Name = "tạoBảnSaoDữLiệuToolStripMenuItem";
            resources.ApplyResources(this.tạoBảnSaoDữLiệuToolStripMenuItem, "tạoBảnSaoDữLiệuToolStripMenuItem");
            this.tạoBảnSaoDữLiệuToolStripMenuItem.Click += new System.EventHandler(this.tạoBảnSaoDữLiệuToolStripMenuItem_Click);
            // 
            // phụcHồiTừBảnSaoToolStripMenuItem
            // 
            this.phụcHồiTừBảnSaoToolStripMenuItem.Name = "phụcHồiTừBảnSaoToolStripMenuItem";
            resources.ApplyResources(this.phụcHồiTừBảnSaoToolStripMenuItem, "phụcHồiTừBảnSaoToolStripMenuItem");
            this.phụcHồiTừBảnSaoToolStripMenuItem.Click += new System.EventHandler(this.phụcHồiTừBảnSaoToolStripMenuItem_Click);
            // 
            // tiệnÍchToolStripMenuItem
            // 
            this.tiệnÍchToolStripMenuItem.Name = "tiệnÍchToolStripMenuItem";
            resources.ApplyResources(this.tiệnÍchToolStripMenuItem, "tiệnÍchToolStripMenuItem");
            // 
            // sốMãToolStripMenuItem
            // 
            this.sốMãToolStripMenuItem.Name = "sốMãToolStripMenuItem";
            resources.ApplyResources(this.sốMãToolStripMenuItem, "sốMãToolStripMenuItem");
            // 
            // sốBánToolStripMenuItem
            // 
            this.sốBánToolStripMenuItem.Name = "sốBánToolStripMenuItem";
            resources.ApplyResources(this.sốBánToolStripMenuItem, "sốBánToolStripMenuItem");
            // 
            // chămSócKMToolStripMenuItem
            // 
            this.chămSócKMToolStripMenuItem.Name = "chămSócKMToolStripMenuItem";
            resources.ApplyResources(this.chămSócKMToolStripMenuItem, "chămSócKMToolStripMenuItem");
            // 
            // nhậpHàngTừSảnXuấtToolStripMenuItem
            // 
            this.nhậpHàngTừSảnXuấtToolStripMenuItem.Name = "nhậpHàngTừSảnXuấtToolStripMenuItem";
            resources.ApplyResources(this.nhậpHàngTừSảnXuấtToolStripMenuItem, "nhậpHàngTừSảnXuấtToolStripMenuItem");
            this.nhậpHàngTừSảnXuấtToolStripMenuItem.Click += new System.EventHandler(this.nhậpHàngTừSảnXuấtToolStripMenuItem_Click);
            // 
            // xuấtHàngĐểTiêuDùngToolStripMenuItem
            // 
            this.xuấtHàngĐểTiêuDùngToolStripMenuItem.Name = "xuấtHàngĐểTiêuDùngToolStripMenuItem";
            resources.ApplyResources(this.xuấtHàngĐểTiêuDùngToolStripMenuItem, "xuấtHàngĐểTiêuDùngToolStripMenuItem");
            this.xuấtHàngĐểTiêuDùngToolStripMenuItem.Click += new System.EventHandler(this.xuấtHàngĐểTiêuDùngToolStripMenuItem_Click);
            // 
            // kiểmHàngToolStripMenuItem
            // 
            this.kiểmHàngToolStripMenuItem.Name = "kiểmHàngToolStripMenuItem";
            resources.ApplyResources(this.kiểmHàngToolStripMenuItem, "kiểmHàngToolStripMenuItem");
            this.kiểmHàngToolStripMenuItem.Click += new System.EventHandler(this.kiểmHàngToolStripMenuItem_Click);
            // 
            // kếToánToolStripMenuItem
            // 
            this.kếToánToolStripMenuItem.Name = "kếToánToolStripMenuItem";
            resources.ApplyResources(this.kếToánToolStripMenuItem, "kếToánToolStripMenuItem");
            // 
            // doanhThuBánHàngToolStripMenuItem
            // 
            this.doanhThuBánHàngToolStripMenuItem.Name = "doanhThuBánHàngToolStripMenuItem";
            resources.ApplyResources(this.doanhThuBánHàngToolStripMenuItem, "doanhThuBánHàngToolStripMenuItem");
            this.doanhThuBánHàngToolStripMenuItem.Click += new System.EventHandler(this.doanhThuBánHàngToolStripMenuItem_Click);
            // 
            // thốngKêBánHàngNhânViênToolStripMenuItem
            // 
            this.thốngKêBánHàngNhânViênToolStripMenuItem.Name = "thốngKêBánHàngNhânViênToolStripMenuItem";
            resources.ApplyResources(this.thốngKêBánHàngNhânViênToolStripMenuItem, "thốngKêBánHàngNhânViênToolStripMenuItem");
            this.thốngKêBánHàngNhânViênToolStripMenuItem.Click += new System.EventHandler(this.thốngKêBánHàngNhânViênToolStripMenuItem_Click);
            // 
            // danhSáchKháchNợVỏToolStripMenuItem
            // 
            this.danhSáchKháchNợVỏToolStripMenuItem.Name = "danhSáchKháchNợVỏToolStripMenuItem";
            resources.ApplyResources(this.danhSáchKháchNợVỏToolStripMenuItem, "danhSáchKháchNợVỏToolStripMenuItem");
            this.danhSáchKháchNợVỏToolStripMenuItem.Click += new System.EventHandler(this.danhSáchKháchNợVỏToolStripMenuItem_Click);
            // 
            // danhSáchKháchNợTiềnToolStripMenuItem
            // 
            this.danhSáchKháchNợTiềnToolStripMenuItem.Name = "danhSáchKháchNợTiềnToolStripMenuItem";
            resources.ApplyResources(this.danhSáchKháchNợTiềnToolStripMenuItem, "danhSáchKháchNợTiềnToolStripMenuItem");
            this.danhSáchKháchNợTiềnToolStripMenuItem.Click += new System.EventHandler(this.danhSáchKháchNợTiềnToolStripMenuItem_Click);
            // 
            // tàiKhoảnToolStripMenuItem
            // 
            this.tàiKhoảnToolStripMenuItem.Name = "tàiKhoảnToolStripMenuItem";
            resources.ApplyResources(this.tàiKhoảnToolStripMenuItem, "tàiKhoảnToolStripMenuItem");
            // 
            // quảnLýTàiKhoảnToolStripMenuItem
            // 
            this.quảnLýTàiKhoảnToolStripMenuItem.Name = "quảnLýTàiKhoảnToolStripMenuItem";
            resources.ApplyResources(this.quảnLýTàiKhoảnToolStripMenuItem, "quảnLýTàiKhoảnToolStripMenuItem");
            this.quảnLýTàiKhoảnToolStripMenuItem.Click += new System.EventHandler(this.quảnLýTàiKhoảnToolStripMenuItem_Click);
            // 
            // listPanel
            // 
            resources.ApplyResources(this.listPanel, "listPanel");
            this.listPanel.Controls.Add(this.tabControl1);
            this.listPanel.Name = "listPanel";
            // 
            // tabControl1
            // 
            resources.ApplyResources(this.tabControl1, "tabControl1");
            this.tabControl1.Controls.Add(this.tpn_order);
            this.tabControl1.Controls.Add(this.tpn_customer);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            // 
            // tpn_order
            // 
            this.tpn_order.Controls.Add(this.label28);
            this.tpn_order.Controls.Add(this.txt_CustomerRecordFilter);
            this.tpn_order.Controls.Add(this.ckb_CustomerRecordFilter);
            this.tpn_order.Controls.Add(this.ckb_CustomerDateFilter);
            this.tpn_order.Controls.Add(this.label16);
            this.tpn_order.Controls.Add(this.dtg_Order);
            this.tpn_order.Controls.Add(this.dtp_ToDate);
            this.tpn_order.Controls.Add(this.label15);
            this.tpn_order.Controls.Add(this.earchLabel);
            this.tpn_order.Controls.Add(this.dtp_FromDate);
            this.tpn_order.Controls.Add(this.txt_searchOrder);
            this.tpn_order.Controls.Add(this.btn_AddNewOrder);
            this.tpn_order.Controls.Add(this.btn_EditExistingOrder);
            resources.ApplyResources(this.tpn_order, "tpn_order");
            this.tpn_order.Name = "tpn_order";
            this.tpn_order.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            resources.ApplyResources(this.label28, "label28");
            this.label28.Name = "label28";
            // 
            // txt_CustomerRecordFilter
            // 
            resources.ApplyResources(this.txt_CustomerRecordFilter, "txt_CustomerRecordFilter");
            this.txt_CustomerRecordFilter.Name = "txt_CustomerRecordFilter";
            // 
            // ckb_CustomerRecordFilter
            // 
            resources.ApplyResources(this.ckb_CustomerRecordFilter, "ckb_CustomerRecordFilter");
            this.ckb_CustomerRecordFilter.Name = "ckb_CustomerRecordFilter";
            this.ckb_CustomerRecordFilter.UseVisualStyleBackColor = true;
            // 
            // ckb_CustomerDateFilter
            // 
            resources.ApplyResources(this.ckb_CustomerDateFilter, "ckb_CustomerDateFilter");
            this.ckb_CustomerDateFilter.Name = "ckb_CustomerDateFilter";
            this.ckb_CustomerDateFilter.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // dtg_Order
            // 
            this.dtg_Order.AllowUserToAddRows = false;
            this.dtg_Order.AllowUserToDeleteRows = false;
            resources.ApplyResources(this.dtg_Order, "dtg_Order");
            this.dtg_Order.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_Order.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_Order.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.COLUMN_NAME_ORDER_SELLCODE,
            this.COLUMN_NAME_ORDER_CUSNAME,
            this.COLUMN_NAME_ORDER_CUSTEL,
            this.COLUMN_NAME_ORDER_CUSADD,
            this.COLUMN_NAME_ORDER_GOODKIND,
            this.COLUMN_NAME_ORDER_QUANTITY,
            this.COLUMN_NAME_ORDER_PRICE,
            this.COLUMN_NAME_ORDER_DELIVERER,
            this.COLUMN_NAME_ORDER_SELLDATE,
            this.COLUMN_NAME_ORDER_REMOVE});
            this.dtg_Order.MultiSelect = false;
            this.dtg_Order.Name = "dtg_Order";
            this.dtg_Order.ReadOnly = true;
            this.dtg_Order.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // 
            // COLUMN_NAME_ORDER_SELLCODE
            // 
            resources.ApplyResources(this.COLUMN_NAME_ORDER_SELLCODE, "COLUMN_NAME_ORDER_SELLCODE");
            this.COLUMN_NAME_ORDER_SELLCODE.Name = "COLUMN_NAME_ORDER_SELLCODE";
            this.COLUMN_NAME_ORDER_SELLCODE.ReadOnly = true;
            // 
            // COLUMN_NAME_ORDER_CUSNAME
            // 
            resources.ApplyResources(this.COLUMN_NAME_ORDER_CUSNAME, "COLUMN_NAME_ORDER_CUSNAME");
            this.COLUMN_NAME_ORDER_CUSNAME.Name = "COLUMN_NAME_ORDER_CUSNAME";
            this.COLUMN_NAME_ORDER_CUSNAME.ReadOnly = true;
            // 
            // COLUMN_NAME_ORDER_CUSTEL
            // 
            resources.ApplyResources(this.COLUMN_NAME_ORDER_CUSTEL, "COLUMN_NAME_ORDER_CUSTEL");
            this.COLUMN_NAME_ORDER_CUSTEL.Name = "COLUMN_NAME_ORDER_CUSTEL";
            this.COLUMN_NAME_ORDER_CUSTEL.ReadOnly = true;
            // 
            // COLUMN_NAME_ORDER_CUSADD
            // 
            this.COLUMN_NAME_ORDER_CUSADD.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            resources.ApplyResources(this.COLUMN_NAME_ORDER_CUSADD, "COLUMN_NAME_ORDER_CUSADD");
            this.COLUMN_NAME_ORDER_CUSADD.Name = "COLUMN_NAME_ORDER_CUSADD";
            this.COLUMN_NAME_ORDER_CUSADD.ReadOnly = true;
            // 
            // COLUMN_NAME_ORDER_GOODKIND
            // 
            resources.ApplyResources(this.COLUMN_NAME_ORDER_GOODKIND, "COLUMN_NAME_ORDER_GOODKIND");
            this.COLUMN_NAME_ORDER_GOODKIND.Name = "COLUMN_NAME_ORDER_GOODKIND";
            this.COLUMN_NAME_ORDER_GOODKIND.ReadOnly = true;
            // 
            // COLUMN_NAME_ORDER_QUANTITY
            // 
            resources.ApplyResources(this.COLUMN_NAME_ORDER_QUANTITY, "COLUMN_NAME_ORDER_QUANTITY");
            this.COLUMN_NAME_ORDER_QUANTITY.Name = "COLUMN_NAME_ORDER_QUANTITY";
            this.COLUMN_NAME_ORDER_QUANTITY.ReadOnly = true;
            // 
            // COLUMN_NAME_ORDER_PRICE
            // 
            resources.ApplyResources(this.COLUMN_NAME_ORDER_PRICE, "COLUMN_NAME_ORDER_PRICE");
            this.COLUMN_NAME_ORDER_PRICE.Name = "COLUMN_NAME_ORDER_PRICE";
            this.COLUMN_NAME_ORDER_PRICE.ReadOnly = true;
            // 
            // COLUMN_NAME_ORDER_DELIVERER
            // 
            resources.ApplyResources(this.COLUMN_NAME_ORDER_DELIVERER, "COLUMN_NAME_ORDER_DELIVERER");
            this.COLUMN_NAME_ORDER_DELIVERER.Name = "COLUMN_NAME_ORDER_DELIVERER";
            this.COLUMN_NAME_ORDER_DELIVERER.ReadOnly = true;
            // 
            // COLUMN_NAME_ORDER_SELLDATE
            // 
            resources.ApplyResources(this.COLUMN_NAME_ORDER_SELLDATE, "COLUMN_NAME_ORDER_SELLDATE");
            this.COLUMN_NAME_ORDER_SELLDATE.Name = "COLUMN_NAME_ORDER_SELLDATE";
            this.COLUMN_NAME_ORDER_SELLDATE.ReadOnly = true;
            // 
            // COLUMN_NAME_ORDER_REMOVE
            // 
            resources.ApplyResources(this.COLUMN_NAME_ORDER_REMOVE, "COLUMN_NAME_ORDER_REMOVE");
            this.COLUMN_NAME_ORDER_REMOVE.Name = "COLUMN_NAME_ORDER_REMOVE";
            this.COLUMN_NAME_ORDER_REMOVE.ReadOnly = true;
            // 
            // dtp_ToDate
            // 
            resources.ApplyResources(this.dtp_ToDate, "dtp_ToDate");
            this.dtp_ToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_ToDate.Name = "dtp_ToDate";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // earchLabel
            // 
            resources.ApplyResources(this.earchLabel, "earchLabel");
            this.earchLabel.Name = "earchLabel";
            // 
            // dtp_FromDate
            // 
            resources.ApplyResources(this.dtp_FromDate, "dtp_FromDate");
            this.dtp_FromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_FromDate.Name = "dtp_FromDate";
            // 
            // txt_searchOrder
            // 
            resources.ApplyResources(this.txt_searchOrder, "txt_searchOrder");
            this.txt_searchOrder.Name = "txt_searchOrder";
            // 
            // btn_AddNewOrder
            // 
            resources.ApplyResources(this.btn_AddNewOrder, "btn_AddNewOrder");
            this.btn_AddNewOrder.Name = "btn_AddNewOrder";
            this.toolTip1.SetToolTip(this.btn_AddNewOrder, resources.GetString("btn_AddNewOrder.ToolTip"));
            this.btn_AddNewOrder.UseVisualStyleBackColor = true;
            this.btn_AddNewOrder.Click += new System.EventHandler(this.btn_AddNewOrder_Click);
            // 
            // btn_EditExistingOrder
            // 
            resources.ApplyResources(this.btn_EditExistingOrder, "btn_EditExistingOrder");
            this.btn_EditExistingOrder.Name = "btn_EditExistingOrder";
            this.toolTip1.SetToolTip(this.btn_EditExistingOrder, resources.GetString("btn_EditExistingOrder.ToolTip"));
            this.btn_EditExistingOrder.UseVisualStyleBackColor = true;
            this.btn_EditExistingOrder.Click += new System.EventHandler(this.btn_EditExistingOrder_Click);
            // 
            // tpn_customer
            // 
            this.tpn_customer.Controls.Add(this.btn_addorder);
            this.tpn_customer.Controls.Add(this.label13);
            this.tpn_customer.Controls.Add(this.dtg_Customer);
            this.tpn_customer.Controls.Add(this.txt_SearchCustomer);
            this.tpn_customer.Controls.Add(this.btn_EditUser);
            this.tpn_customer.Controls.Add(this.btn_AddNewUser);
            resources.ApplyResources(this.tpn_customer, "tpn_customer");
            this.tpn_customer.Name = "tpn_customer";
            this.tpn_customer.UseVisualStyleBackColor = true;
            // 
            // btn_addorder
            // 
            resources.ApplyResources(this.btn_addorder, "btn_addorder");
            this.btn_addorder.Name = "btn_addorder";
            this.toolTip1.SetToolTip(this.btn_addorder, resources.GetString("btn_addorder.ToolTip"));
            this.btn_addorder.UseVisualStyleBackColor = true;
            this.btn_addorder.Click += new System.EventHandler(this.btn_addorder_Click);
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // dtg_Customer
            // 
            this.dtg_Customer.AllowUserToAddRows = false;
            this.dtg_Customer.AllowUserToDeleteRows = false;
            resources.ApplyResources(this.dtg_Customer, "dtg_Customer");
            this.dtg_Customer.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_Customer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_Customer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.COLUMN_NAME_CUSTOMER_ID,
            this.COLUMN_NAME_CUSTOMER_NAME,
            this.COLUMN_NAME_CUSTOMER_ADDRESS,
            this.COLUMN_NAME_CUSTOMER_DISTRICT,
            this.COLUMN_NAME_CUSTOMER_CITY,
            this.COLUMN_NAME_CUSTOMER_HOMEPHONE,
            this.COLUMN_NAME_CUSTOMER_MOBILE,
            this.COLUMN_NAME_CUSTOMER_REMOVE});
            this.dtg_Customer.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtg_Customer.MultiSelect = false;
            this.dtg_Customer.Name = "dtg_Customer";
            this.dtg_Customer.ReadOnly = true;
            this.dtg_Customer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // 
            // COLUMN_NAME_CUSTOMER_ID
            // 
            resources.ApplyResources(this.COLUMN_NAME_CUSTOMER_ID, "COLUMN_NAME_CUSTOMER_ID");
            this.COLUMN_NAME_CUSTOMER_ID.Name = "COLUMN_NAME_CUSTOMER_ID";
            this.COLUMN_NAME_CUSTOMER_ID.ReadOnly = true;
            // 
            // COLUMN_NAME_CUSTOMER_NAME
            // 
            resources.ApplyResources(this.COLUMN_NAME_CUSTOMER_NAME, "COLUMN_NAME_CUSTOMER_NAME");
            this.COLUMN_NAME_CUSTOMER_NAME.Name = "COLUMN_NAME_CUSTOMER_NAME";
            this.COLUMN_NAME_CUSTOMER_NAME.ReadOnly = true;
            // 
            // COLUMN_NAME_CUSTOMER_ADDRESS
            // 
            this.COLUMN_NAME_CUSTOMER_ADDRESS.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            resources.ApplyResources(this.COLUMN_NAME_CUSTOMER_ADDRESS, "COLUMN_NAME_CUSTOMER_ADDRESS");
            this.COLUMN_NAME_CUSTOMER_ADDRESS.Name = "COLUMN_NAME_CUSTOMER_ADDRESS";
            this.COLUMN_NAME_CUSTOMER_ADDRESS.ReadOnly = true;
            // 
            // COLUMN_NAME_CUSTOMER_DISTRICT
            // 
            resources.ApplyResources(this.COLUMN_NAME_CUSTOMER_DISTRICT, "COLUMN_NAME_CUSTOMER_DISTRICT");
            this.COLUMN_NAME_CUSTOMER_DISTRICT.Name = "COLUMN_NAME_CUSTOMER_DISTRICT";
            this.COLUMN_NAME_CUSTOMER_DISTRICT.ReadOnly = true;
            // 
            // COLUMN_NAME_CUSTOMER_CITY
            // 
            resources.ApplyResources(this.COLUMN_NAME_CUSTOMER_CITY, "COLUMN_NAME_CUSTOMER_CITY");
            this.COLUMN_NAME_CUSTOMER_CITY.Name = "COLUMN_NAME_CUSTOMER_CITY";
            this.COLUMN_NAME_CUSTOMER_CITY.ReadOnly = true;
            // 
            // COLUMN_NAME_CUSTOMER_HOMEPHONE
            // 
            resources.ApplyResources(this.COLUMN_NAME_CUSTOMER_HOMEPHONE, "COLUMN_NAME_CUSTOMER_HOMEPHONE");
            this.COLUMN_NAME_CUSTOMER_HOMEPHONE.Name = "COLUMN_NAME_CUSTOMER_HOMEPHONE";
            this.COLUMN_NAME_CUSTOMER_HOMEPHONE.ReadOnly = true;
            // 
            // COLUMN_NAME_CUSTOMER_MOBILE
            // 
            resources.ApplyResources(this.COLUMN_NAME_CUSTOMER_MOBILE, "COLUMN_NAME_CUSTOMER_MOBILE");
            this.COLUMN_NAME_CUSTOMER_MOBILE.Name = "COLUMN_NAME_CUSTOMER_MOBILE";
            this.COLUMN_NAME_CUSTOMER_MOBILE.ReadOnly = true;
            // 
            // COLUMN_NAME_CUSTOMER_REMOVE
            // 
            resources.ApplyResources(this.COLUMN_NAME_CUSTOMER_REMOVE, "COLUMN_NAME_CUSTOMER_REMOVE");
            this.COLUMN_NAME_CUSTOMER_REMOVE.Name = "COLUMN_NAME_CUSTOMER_REMOVE";
            this.COLUMN_NAME_CUSTOMER_REMOVE.ReadOnly = true;
            // 
            // txt_SearchCustomer
            // 
            resources.ApplyResources(this.txt_SearchCustomer, "txt_SearchCustomer");
            this.txt_SearchCustomer.Name = "txt_SearchCustomer";
            // 
            // btn_EditUser
            // 
            resources.ApplyResources(this.btn_EditUser, "btn_EditUser");
            this.btn_EditUser.Name = "btn_EditUser";
            this.toolTip1.SetToolTip(this.btn_EditUser, resources.GetString("btn_EditUser.ToolTip"));
            this.btn_EditUser.UseVisualStyleBackColor = true;
            this.btn_EditUser.Click += new System.EventHandler(this.btn_EditUser_Click);
            // 
            // btn_AddNewUser
            // 
            resources.ApplyResources(this.btn_AddNewUser, "btn_AddNewUser");
            this.btn_AddNewUser.Name = "btn_AddNewUser";
            this.toolTip1.SetToolTip(this.btn_AddNewUser, resources.GetString("btn_AddNewUser.ToolTip"));
            this.btn_AddNewUser.UseVisualStyleBackColor = true;
            this.btn_AddNewUser.Click += new System.EventHandler(this.btn_AddNewUser_Click);
            // 
            // editPanel
            // 
            resources.ApplyResources(this.editPanel, "editPanel");
            this.editPanel.Controls.Add(this.btn_addCustomerOrder);
            this.editPanel.Controls.Add(this.panel1);
            this.editPanel.Controls.Add(this.btn_MobileDiary);
            this.editPanel.Controls.Add(this.btn_HomephoneDiary);
            this.editPanel.Controls.Add(this.label19);
            this.editPanel.Controls.Add(this.label18);
            this.editPanel.Controls.Add(this.label17);
            this.editPanel.Controls.Add(this.label14);
            this.editPanel.Controls.Add(this.txt_DistrictCustomer);
            this.editPanel.Controls.Add(this.txt_CityCustomer);
            this.editPanel.Controls.Add(this.txt_MobileCutomer);
            this.editPanel.Controls.Add(this.txt_HomePhoneCustomer);
            this.editPanel.Controls.Add(this.btn_SaveCustomer);
            this.editPanel.Controls.Add(this.btn_CloseEditting);
            this.editPanel.Controls.Add(this.txt_NameCustomer);
            this.editPanel.Controls.Add(this.txt_AddressCustomer);
            this.editPanel.Controls.Add(this.txt_IdCustomer);
            this.editPanel.Controls.Add(this.label3);
            this.editPanel.Controls.Add(this.label2);
            this.editPanel.Controls.Add(this.label1);
            this.editPanel.Name = "editPanel";
            // 
            // btn_addCustomerOrder
            // 
            resources.ApplyResources(this.btn_addCustomerOrder, "btn_addCustomerOrder");
            this.btn_addCustomerOrder.Name = "btn_addCustomerOrder";
            this.toolTip1.SetToolTip(this.btn_addCustomerOrder, resources.GetString("btn_addCustomerOrder.ToolTip"));
            this.btn_addCustomerOrder.UseVisualStyleBackColor = true;
            this.btn_addCustomerOrder.Click += new System.EventHandler(this.btn_addCustomerOrder_Click);
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.ptb_map);
            this.panel1.Controls.Add(this.btn_map);
            this.panel1.Name = "panel1";
            // 
            // ptb_map
            // 
            resources.ApplyResources(this.ptb_map, "ptb_map");
            this.ptb_map.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ptb_map.Name = "ptb_map";
            this.ptb_map.TabStop = false;
            // 
            // btn_map
            // 
            resources.ApplyResources(this.btn_map, "btn_map");
            this.btn_map.Name = "btn_map";
            this.btn_map.UseVisualStyleBackColor = true;
            this.btn_map.Click += new System.EventHandler(this.btn_map_Click);
            // 
            // btn_MobileDiary
            // 
            resources.ApplyResources(this.btn_MobileDiary, "btn_MobileDiary");
            this.btn_MobileDiary.Name = "btn_MobileDiary";
            this.btn_MobileDiary.UseVisualStyleBackColor = true;
            this.btn_MobileDiary.Click += new System.EventHandler(this.btn_MobileDiary_Click);
            // 
            // btn_HomephoneDiary
            // 
            resources.ApplyResources(this.btn_HomephoneDiary, "btn_HomephoneDiary");
            this.btn_HomephoneDiary.Name = "btn_HomephoneDiary";
            this.btn_HomephoneDiary.UseVisualStyleBackColor = true;
            this.btn_HomephoneDiary.Click += new System.EventHandler(this.btn_HomephoneDiary_Click);
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // txt_DistrictCustomer
            // 
            resources.ApplyResources(this.txt_DistrictCustomer, "txt_DistrictCustomer");
            this.txt_DistrictCustomer.Name = "txt_DistrictCustomer";
            // 
            // txt_CityCustomer
            // 
            resources.ApplyResources(this.txt_CityCustomer, "txt_CityCustomer");
            this.txt_CityCustomer.Name = "txt_CityCustomer";
            // 
            // txt_MobileCutomer
            // 
            resources.ApplyResources(this.txt_MobileCutomer, "txt_MobileCutomer");
            this.txt_MobileCutomer.Name = "txt_MobileCutomer";
            // 
            // txt_HomePhoneCustomer
            // 
            resources.ApplyResources(this.txt_HomePhoneCustomer, "txt_HomePhoneCustomer");
            this.txt_HomePhoneCustomer.Name = "txt_HomePhoneCustomer";
            // 
            // btn_SaveCustomer
            // 
            resources.ApplyResources(this.btn_SaveCustomer, "btn_SaveCustomer");
            this.btn_SaveCustomer.Name = "btn_SaveCustomer";
            this.toolTip1.SetToolTip(this.btn_SaveCustomer, resources.GetString("btn_SaveCustomer.ToolTip"));
            this.btn_SaveCustomer.UseVisualStyleBackColor = true;
            this.btn_SaveCustomer.Click += new System.EventHandler(this.btn_SaveCustomer_Click);
            // 
            // btn_CloseEditting
            // 
            resources.ApplyResources(this.btn_CloseEditting, "btn_CloseEditting");
            this.btn_CloseEditting.Name = "btn_CloseEditting";
            this.toolTip1.SetToolTip(this.btn_CloseEditting, resources.GetString("btn_CloseEditting.ToolTip"));
            this.btn_CloseEditting.UseVisualStyleBackColor = true;
            this.btn_CloseEditting.Click += new System.EventHandler(this.btn_CloseEditting_Click);
            // 
            // txt_NameCustomer
            // 
            resources.ApplyResources(this.txt_NameCustomer, "txt_NameCustomer");
            this.txt_NameCustomer.Name = "txt_NameCustomer";
            // 
            // txt_AddressCustomer
            // 
            resources.ApplyResources(this.txt_AddressCustomer, "txt_AddressCustomer");
            this.txt_AddressCustomer.Name = "txt_AddressCustomer";
            // 
            // txt_IdCustomer
            // 
            resources.ApplyResources(this.txt_IdCustomer, "txt_IdCustomer");
            this.txt_IdCustomer.Name = "txt_IdCustomer";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // grb_OrderDetails
            // 
            resources.ApplyResources(this.grb_OrderDetails, "grb_OrderDetails");
            this.grb_OrderDetails.Controls.Add(this.lbl_borrow);
            this.grb_OrderDetails.Controls.Add(this.label38);
            this.grb_OrderDetails.Controls.Add(this.lbl_BorrowMoney);
            this.grb_OrderDetails.Controls.Add(this.lbl_BorrowShell);
            this.grb_OrderDetails.Controls.Add(this.label32);
            this.grb_OrderDetails.Controls.Add(this.label31);
            this.grb_OrderDetails.Controls.Add(this.label30);
            this.grb_OrderDetails.Controls.Add(this.txt_PaidMoney);
            this.grb_OrderDetails.Controls.Add(this.label29);
            this.grb_OrderDetails.Controls.Add(this.txt_ReturnShell);
            this.grb_OrderDetails.Controls.Add(this.txt_OrderQuantity);
            this.grb_OrderDetails.Controls.Add(this.cbb_OrderKindGood);
            this.grb_OrderDetails.Controls.Add(this.label9);
            this.grb_OrderDetails.Controls.Add(this.cbb_OrderDeliverer);
            this.grb_OrderDetails.Controls.Add(this.txt_OrderPrice);
            this.grb_OrderDetails.Controls.Add(this.dt_OrderSellDate);
            this.grb_OrderDetails.Controls.Add(this.label4);
            this.grb_OrderDetails.Controls.Add(this.label5);
            this.grb_OrderDetails.Controls.Add(this.label6);
            this.grb_OrderDetails.Controls.Add(this.cbb_OrderGoodCode);
            this.grb_OrderDetails.Controls.Add(this.label7);
            this.grb_OrderDetails.Controls.Add(this.label8);
            this.grb_OrderDetails.Controls.Add(this.label11);
            this.grb_OrderDetails.Controls.Add(this.txt_OrderComment);
            this.grb_OrderDetails.Name = "grb_OrderDetails";
            this.grb_OrderDetails.TabStop = false;
            // 
            // lbl_borrow
            // 
            resources.ApplyResources(this.lbl_borrow, "lbl_borrow");
            this.lbl_borrow.Name = "lbl_borrow";
            // 
            // label38
            // 
            resources.ApplyResources(this.label38, "label38");
            this.label38.Name = "label38";
            // 
            // lbl_BorrowMoney
            // 
            resources.ApplyResources(this.lbl_BorrowMoney, "lbl_BorrowMoney");
            this.lbl_BorrowMoney.Name = "lbl_BorrowMoney";
            // 
            // lbl_BorrowShell
            // 
            resources.ApplyResources(this.lbl_BorrowShell, "lbl_BorrowShell");
            this.lbl_BorrowShell.Name = "lbl_BorrowShell";
            // 
            // label32
            // 
            resources.ApplyResources(this.label32, "label32");
            this.label32.Name = "label32";
            // 
            // label31
            // 
            resources.ApplyResources(this.label31, "label31");
            this.label31.Name = "label31";
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.Name = "label30";
            // 
            // txt_PaidMoney
            // 
            resources.ApplyResources(this.txt_PaidMoney, "txt_PaidMoney");
            this.txt_PaidMoney.Name = "txt_PaidMoney";
            this.txt_PaidMoney.TextChanged += new System.EventHandler(this.textbox2_TextChanged);
            // 
            // label29
            // 
            resources.ApplyResources(this.label29, "label29");
            this.label29.Name = "label29";
            // 
            // txt_ReturnShell
            // 
            resources.ApplyResources(this.txt_ReturnShell, "txt_ReturnShell");
            this.txt_ReturnShell.Name = "txt_ReturnShell";
            this.txt_ReturnShell.TextChanged += new System.EventHandler(this.textbox1_TextChanged);
            // 
            // txt_OrderQuantity
            // 
            resources.ApplyResources(this.txt_OrderQuantity, "txt_OrderQuantity");
            this.txt_OrderQuantity.Name = "txt_OrderQuantity";
            // 
            // cbb_OrderKindGood
            // 
            this.cbb_OrderKindGood.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_OrderKindGood.FormattingEnabled = true;
            resources.ApplyResources(this.cbb_OrderKindGood, "cbb_OrderKindGood");
            this.cbb_OrderKindGood.Name = "cbb_OrderKindGood";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // cbb_OrderDeliverer
            // 
            this.cbb_OrderDeliverer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_OrderDeliverer.FormattingEnabled = true;
            resources.ApplyResources(this.cbb_OrderDeliverer, "cbb_OrderDeliverer");
            this.cbb_OrderDeliverer.Name = "cbb_OrderDeliverer";
            // 
            // txt_OrderPrice
            // 
            resources.ApplyResources(this.txt_OrderPrice, "txt_OrderPrice");
            this.txt_OrderPrice.Name = "txt_OrderPrice";
            // 
            // dt_OrderSellDate
            // 
            resources.ApplyResources(this.dt_OrderSellDate, "dt_OrderSellDate");
            this.dt_OrderSellDate.Name = "dt_OrderSellDate";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // cbb_OrderGoodCode
            // 
            this.cbb_OrderGoodCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_OrderGoodCode.FormattingEnabled = true;
            resources.ApplyResources(this.cbb_OrderGoodCode, "cbb_OrderGoodCode");
            this.cbb_OrderGoodCode.Name = "cbb_OrderGoodCode";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // txt_OrderComment
            // 
            resources.ApplyResources(this.txt_OrderComment, "txt_OrderComment");
            this.txt_OrderComment.Name = "txt_OrderComment";
            // 
            // lbl_ActionStatus
            // 
            resources.ApplyResources(this.lbl_ActionStatus, "lbl_ActionStatus");
            this.lbl_ActionStatus.Name = "lbl_ActionStatus";
            // 
            // pnl_EditOrder
            // 
            resources.ApplyResources(this.pnl_EditOrder, "pnl_EditOrder");
            this.pnl_EditOrder.Controls.Add(this.ptb_order);
            this.pnl_EditOrder.Controls.Add(this.txt_OrderId);
            this.pnl_EditOrder.Controls.Add(this.label12);
            this.pnl_EditOrder.Controls.Add(this.cbb_Customer);
            this.pnl_EditOrder.Controls.Add(this.btn_OrderPrint);
            this.pnl_EditOrder.Controls.Add(this.btn_OrderSave);
            this.pnl_EditOrder.Controls.Add(this.btn_OrderClose);
            this.pnl_EditOrder.Controls.Add(this.label20);
            this.pnl_EditOrder.Controls.Add(this.label21);
            this.pnl_EditOrder.Controls.Add(this.label22);
            this.pnl_EditOrder.Controls.Add(this.label23);
            this.pnl_EditOrder.Controls.Add(this.txt_OrderCustomerDistrict);
            this.pnl_EditOrder.Controls.Add(this.grb_OrderDetails);
            this.pnl_EditOrder.Controls.Add(this.txt_OrderCustomerCity);
            this.pnl_EditOrder.Controls.Add(this.txt_OrderCustomerMobile);
            this.pnl_EditOrder.Controls.Add(this.txt_OrderCustomerHomePhone);
            this.pnl_EditOrder.Controls.Add(this.txt_OrderCustomerName);
            this.pnl_EditOrder.Controls.Add(this.txt_OrderCustomerAddess);
            this.pnl_EditOrder.Controls.Add(this.label24);
            this.pnl_EditOrder.Controls.Add(this.label25);
            this.pnl_EditOrder.Controls.Add(this.label26);
            this.pnl_EditOrder.Name = "pnl_EditOrder";
            // 
            // ptb_order
            // 
            resources.ApplyResources(this.ptb_order, "ptb_order");
            this.ptb_order.Name = "ptb_order";
            this.ptb_order.TabStop = false;
            // 
            // txt_OrderId
            // 
            resources.ApplyResources(this.txt_OrderId, "txt_OrderId");
            this.txt_OrderId.Name = "txt_OrderId";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // cbb_Customer
            // 
            this.cbb_Customer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_Customer.FormattingEnabled = true;
            resources.ApplyResources(this.cbb_Customer, "cbb_Customer");
            this.cbb_Customer.Name = "cbb_Customer";
            // 
            // btn_OrderPrint
            // 
            resources.ApplyResources(this.btn_OrderPrint, "btn_OrderPrint");
            this.btn_OrderPrint.Name = "btn_OrderPrint";
            this.toolTip1.SetToolTip(this.btn_OrderPrint, resources.GetString("btn_OrderPrint.ToolTip"));
            this.btn_OrderPrint.UseVisualStyleBackColor = true;
            this.btn_OrderPrint.Click += new System.EventHandler(this.btn_OrderPrint_Click);
            // 
            // btn_OrderSave
            // 
            resources.ApplyResources(this.btn_OrderSave, "btn_OrderSave");
            this.btn_OrderSave.Name = "btn_OrderSave";
            this.toolTip1.SetToolTip(this.btn_OrderSave, resources.GetString("btn_OrderSave.ToolTip"));
            this.btn_OrderSave.UseVisualStyleBackColor = true;
            this.btn_OrderSave.Click += new System.EventHandler(this.btn_OrderSave_Click);
            // 
            // btn_OrderClose
            // 
            resources.ApplyResources(this.btn_OrderClose, "btn_OrderClose");
            this.btn_OrderClose.Name = "btn_OrderClose";
            this.toolTip1.SetToolTip(this.btn_OrderClose, resources.GetString("btn_OrderClose.ToolTip"));
            this.btn_OrderClose.UseVisualStyleBackColor = true;
            this.btn_OrderClose.Click += new System.EventHandler(this.btn_OrderClose_Click);
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.Name = "label23";
            // 
            // txt_OrderCustomerDistrict
            // 
            resources.ApplyResources(this.txt_OrderCustomerDistrict, "txt_OrderCustomerDistrict");
            this.txt_OrderCustomerDistrict.Name = "txt_OrderCustomerDistrict";
            // 
            // txt_OrderCustomerCity
            // 
            resources.ApplyResources(this.txt_OrderCustomerCity, "txt_OrderCustomerCity");
            this.txt_OrderCustomerCity.Name = "txt_OrderCustomerCity";
            // 
            // txt_OrderCustomerMobile
            // 
            resources.ApplyResources(this.txt_OrderCustomerMobile, "txt_OrderCustomerMobile");
            this.txt_OrderCustomerMobile.Name = "txt_OrderCustomerMobile";
            // 
            // txt_OrderCustomerHomePhone
            // 
            resources.ApplyResources(this.txt_OrderCustomerHomePhone, "txt_OrderCustomerHomePhone");
            this.txt_OrderCustomerHomePhone.Name = "txt_OrderCustomerHomePhone";
            // 
            // txt_OrderCustomerName
            // 
            resources.ApplyResources(this.txt_OrderCustomerName, "txt_OrderCustomerName");
            this.txt_OrderCustomerName.Name = "txt_OrderCustomerName";
            // 
            // txt_OrderCustomerAddess
            // 
            resources.ApplyResources(this.txt_OrderCustomerAddess, "txt_OrderCustomerAddess");
            this.txt_OrderCustomerAddess.Name = "txt_OrderCustomerAddess";
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.Name = "label24";
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.Name = "label25";
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.Name = "label26";
            // 
            // tmr_SearchOrder
            // 
            this.tmr_SearchOrder.Interval = 1000;
            this.tmr_SearchOrder.Tick += new System.EventHandler(this.tmr_Tick_SearchOrder);
            // 
            // tmr_SearchCustomer
            // 
            this.tmr_SearchCustomer.Interval = 1000;
            this.tmr_SearchCustomer.Tick += new System.EventHandler(this.tịk_SearchCustomer);
            // 
            // ofd_ChooseBackupDB
            // 
            this.ofd_ChooseBackupDB.FileName = "openFileDialog1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.tiệnÍchToolStripMenuItem1,
            this.nhậtXuấtToolStripMenuItem,
            this.báoCáoToolStripMenuItem,
            this.tàiKhoảnToolStripMenuItem1});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.càiĐặtModemToolStripMenuItem,
            this.càiĐặtMẫuHóaĐơnToolStripMenuItem,
            this.tạoBảnSaoDữLiệuToolStripMenuItem,
            this.phụcHồiTừBảnSaoToolStripMenuItem,
            this.đăngXuấtToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            resources.ApplyResources(this.hệThốngToolStripMenuItem, "hệThốngToolStripMenuItem");
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            resources.ApplyResources(this.đăngXuấtToolStripMenuItem, "đăngXuấtToolStripMenuItem");
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            resources.ApplyResources(this.thoátToolStripMenuItem, "thoátToolStripMenuItem");
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // tiệnÍchToolStripMenuItem1
            // 
            this.tiệnÍchToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gọiĐiệnToolStripMenuItem,
            this.gửiTinNhắnToolStripMenuItem});
            this.tiệnÍchToolStripMenuItem1.Name = "tiệnÍchToolStripMenuItem1";
            resources.ApplyResources(this.tiệnÍchToolStripMenuItem1, "tiệnÍchToolStripMenuItem1");
            // 
            // gọiĐiệnToolStripMenuItem
            // 
            this.gọiĐiệnToolStripMenuItem.Name = "gọiĐiệnToolStripMenuItem";
            resources.ApplyResources(this.gọiĐiệnToolStripMenuItem, "gọiĐiệnToolStripMenuItem");
            this.gọiĐiệnToolStripMenuItem.Click += new System.EventHandler(this.gọiĐiệnToolStripMenuItem_Click);
            // 
            // gửiTinNhắnToolStripMenuItem
            // 
            this.gửiTinNhắnToolStripMenuItem.Name = "gửiTinNhắnToolStripMenuItem";
            resources.ApplyResources(this.gửiTinNhắnToolStripMenuItem, "gửiTinNhắnToolStripMenuItem");
            this.gửiTinNhắnToolStripMenuItem.Click += new System.EventHandler(this.gửiTinNhắnToolStripMenuItem_Click);
            // 
            // nhậtXuấtToolStripMenuItem
            // 
            this.nhậtXuấtToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nhậpHàngTừSảnXuấtToolStripMenuItem,
            this.xuấtHàngĐểTiêuDùngToolStripMenuItem,
            this.kiểmHàngToolStripMenuItem});
            this.nhậtXuấtToolStripMenuItem.Name = "nhậtXuấtToolStripMenuItem";
            resources.ApplyResources(this.nhậtXuấtToolStripMenuItem, "nhậtXuấtToolStripMenuItem");
            // 
            // báoCáoToolStripMenuItem
            // 
            this.báoCáoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.doanhThuBánHàngToolStripMenuItem,
            this.danhSáchKháchNợTiềnToolStripMenuItem,
            this.danhSáchKháchNợVỏToolStripMenuItem,
            this.thốngKêBánHàngNhânViênToolStripMenuItem});
            this.báoCáoToolStripMenuItem.Name = "báoCáoToolStripMenuItem";
            resources.ApplyResources(this.báoCáoToolStripMenuItem, "báoCáoToolStripMenuItem");
            // 
            // tàiKhoảnToolStripMenuItem1
            // 
            this.tàiKhoảnToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýTàiKhoảnToolStripMenuItem,
            this.danhSáchHàngHóaToolStripMenuItem,
            this.danhSáchNhàCungCấpToolStripMenuItem,
            this.smi_deliverer});
            this.tàiKhoảnToolStripMenuItem1.Name = "tàiKhoảnToolStripMenuItem1";
            resources.ApplyResources(this.tàiKhoảnToolStripMenuItem1, "tàiKhoảnToolStripMenuItem1");
            // 
            // prd_Order
            // 
            this.prd_Order.UseEXDialog = true;
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox1, resources.GetString("pictureBox1.ToolTip"));
            this.pictureBox1.Click += new System.EventHandler(this.lbl_modemStatus_DoubleClick);
            // 
            // btn_SendMessage
            // 
            resources.ApplyResources(this.btn_SendMessage, "btn_SendMessage");
            this.btn_SendMessage.Name = "btn_SendMessage";
            this.btn_SendMessage.UseVisualStyleBackColor = true;
            this.btn_SendMessage.Click += new System.EventHandler(this.btn_SendMessage_Click);
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label10.Name = "label10";
            // 
            // btn_Call
            // 
            resources.ApplyResources(this.btn_Call, "btn_Call");
            this.btn_Call.Name = "btn_Call";
            this.btn_Call.UseVisualStyleBackColor = true;
            this.btn_Call.Click += new System.EventHandler(this.btn_Call_Click);
            // 
            // btn_duecustomer
            // 
            resources.ApplyResources(this.btn_duecustomer, "btn_duecustomer");
            this.btn_duecustomer.Name = "btn_duecustomer";
            this.btn_duecustomer.UseVisualStyleBackColor = true;
            this.btn_duecustomer.Click += new System.EventHandler(this.btn_duecustomer_Click);
            // 
            // btn_salary
            // 
            resources.ApplyResources(this.btn_salary, "btn_salary");
            this.btn_salary.Name = "btn_salary";
            this.btn_salary.UseVisualStyleBackColor = true;
            this.btn_salary.Click += new System.EventHandler(this.btn_salary_Click);
            // 
            // btn_chart
            // 
            resources.ApplyResources(this.btn_chart, "btn_chart");
            this.btn_chart.Name = "btn_chart";
            this.btn_chart.UseVisualStyleBackColor = true;
            this.btn_chart.Click += new System.EventHandler(this.btn_chart_Click);
            // 
            // label36
            // 
            resources.ApplyResources(this.label36, "label36");
            this.label36.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label36.Name = "label36";
            // 
            // label37
            // 
            resources.ApplyResources(this.label37, "label37");
            this.label37.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label37.Name = "label37";
            // 
            // label34
            // 
            resources.ApplyResources(this.label34, "label34");
            this.label34.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label34.Name = "label34";
            // 
            // label35
            // 
            resources.ApplyResources(this.label35, "label35");
            this.label35.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label35.Name = "label35";
            // 
            // label33
            // 
            resources.ApplyResources(this.label33, "label33");
            this.label33.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label33.Name = "label33";
            // 
            // label27
            // 
            resources.ApplyResources(this.label27, "label27");
            this.label27.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label27.Name = "label27";
            // 
            // btn_exportexcel
            // 
            resources.ApplyResources(this.btn_exportexcel, "btn_exportexcel");
            this.btn_exportexcel.Name = "btn_exportexcel";
            this.btn_exportexcel.UseVisualStyleBackColor = true;
            this.btn_exportexcel.Click += new System.EventHandler(this.btn_exportexcel_Click);
            // 
            // btn_diary
            // 
            resources.ApplyResources(this.btn_diary, "btn_diary");
            this.btn_diary.Name = "btn_diary";
            this.btn_diary.UseVisualStyleBackColor = true;
            this.btn_diary.Click += new System.EventHandler(this.btn_diary_Click);
            // 
            // lbl_modemStatus
            // 
            resources.ApplyResources(this.lbl_modemStatus, "lbl_modemStatus");
            this.lbl_modemStatus.ForeColor = System.Drawing.Color.Blue;
            this.lbl_modemStatus.Name = "lbl_modemStatus";
            this.lbl_modemStatus.Click += new System.EventHandler(this.lbl_modemStatus_DoubleClick);
            // 
            // tmr_CheckModem
            // 
            this.tmr_CheckModem.Interval = 60000;
            this.tmr_CheckModem.Tick += new System.EventHandler(this.tmr_CheckModem_Tick);
            // 
            // valveOrdersTableAdapter1
            // 
            this.valveOrdersTableAdapter1.ClearBeforeFill = true;
            // 
            // tmr_UpdateStatus
            // 
            this.tmr_UpdateStatus.Enabled = true;
            this.tmr_UpdateStatus.Interval = 5000;
            this.tmr_UpdateStatus.Tick += new System.EventHandler(this.tmr_UpdateStatus_Tick);
            // 
            // pnl_Call
            // 
            resources.ApplyResources(this.pnl_Call, "pnl_Call");
            this.pnl_Call.Controls.Add(this.btn_Hangup);
            this.pnl_Call.Controls.Add(this.lbl_PhoneNo);
            this.pnl_Call.Controls.Add(this.lbl_Timer);
            this.pnl_Call.Controls.Add(this.label39);
            this.pnl_Call.Controls.Add(this.label40);
            this.pnl_Call.Name = "pnl_Call";
            // 
            // btn_Hangup
            // 
            resources.ApplyResources(this.btn_Hangup, "btn_Hangup");
            this.btn_Hangup.Name = "btn_Hangup";
            this.btn_Hangup.UseVisualStyleBackColor = true;
            this.btn_Hangup.Click += new System.EventHandler(this.btn_Hangup_Click);
            // 
            // lbl_PhoneNo
            // 
            resources.ApplyResources(this.lbl_PhoneNo, "lbl_PhoneNo");
            this.lbl_PhoneNo.ForeColor = System.Drawing.Color.Blue;
            this.lbl_PhoneNo.Name = "lbl_PhoneNo";
            // 
            // lbl_Timer
            // 
            resources.ApplyResources(this.lbl_Timer, "lbl_Timer");
            this.lbl_Timer.Name = "lbl_Timer";
            // 
            // label39
            // 
            resources.ApplyResources(this.label39, "label39");
            this.label39.Name = "label39";
            // 
            // label40
            // 
            resources.ApplyResources(this.label40, "label40");
            this.label40.Name = "label40";
            // 
            // tmr_Call
            // 
            this.tmr_Call.Tick += new System.EventHandler(this.tmr_Call_Tick);
            // 
            // MainForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Controls.Add(this.editPanel);
            this.Controls.Add(this.pnl_EditOrder);
            this.Controls.Add(this.listPanel);
            this.Controls.Add(this.pnl_Call);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbl_modemStatus);
            this.Controls.Add(this.btn_SendMessage);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btn_Call);
            this.Controls.Add(this.btn_duecustomer);
            this.Controls.Add(this.lbl_ActionStatus);
            this.Controls.Add(this.btn_salary);
            this.Controls.Add(this.editTreeView);
            this.Controls.Add(this.btn_chart);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.btn_diary);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.btn_exportexcel);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label33);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.listPanel.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tpn_order.ResumeLayout(false);
            this.tpn_order.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Order)).EndInit();
            this.tpn_customer.ResumeLayout(false);
            this.tpn_customer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Customer)).EndInit();
            this.editPanel.ResumeLayout(false);
            this.editPanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ptb_map)).EndInit();
            this.grb_OrderDetails.ResumeLayout(false);
            this.grb_OrderDetails.PerformLayout();
            this.pnl_EditOrder.ResumeLayout(false);
            this.pnl_EditOrder.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_order)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnl_Call.ResumeLayout(false);
            this.pnl_Call.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem tsmi_system;
        private System.Windows.Forms.ToolStripMenuItem tiệnÍchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sốMãToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sốBánToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chămSócKMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kếToánToolStripMenuItem;
        private System.Windows.Forms.Panel listPanel;
        private System.Windows.Forms.Label earchLabel;
        private System.Windows.Forms.TextBox txt_searchOrder;
        private System.Windows.Forms.Button btn_AddNewOrder;
        private System.Windows.Forms.Button btn_EditExistingOrder;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpn_order;
        private System.Windows.Forms.TabPage tpn_customer;
        private System.Windows.Forms.DataGridView dtg_Order;
        private System.Windows.Forms.Panel editPanel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_NameCustomer;
        private System.Windows.Forms.TextBox txt_AddressCustomer;
        private System.Windows.Forms.TextBox txt_IdCustomer;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbb_OrderGoodCode;
        private System.Windows.Forms.DateTimePicker dt_OrderSellDate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_OrderComment;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btn_SaveCustomer;
        private System.Windows.Forms.Button btn_CloseEditting;
        private System.Windows.Forms.ToolStripMenuItem danhSáchHàngHóaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sửXóaMãBìnhVàMãVỏToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smi_deliverer;
        private System.Windows.Forms.ToolStripMenuItem danhSáchNhàCungCấpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem càiĐặtModemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem càiĐặtMẫuHóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tạoBảnSaoDữLiệuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phụcHồiTừBảnSaoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhậpHàngTừSảnXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xuấtHàngĐểTiêuDùngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kiểmHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doanhThuBánHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêBánHàngNhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchKháchNợVỏToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchKháchNợTiềnToolStripMenuItem;
        private System.Windows.Forms.TextBox txt_HomePhoneCustomer;
        private System.Windows.Forms.TextBox txt_MobileCutomer;
        private System.Windows.Forms.TextBox txt_CityCustomer;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker dtp_ToDate;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dtp_FromDate;
        private System.Windows.Forms.GroupBox grb_OrderDetails;
        private System.Windows.Forms.DataGridView dtg_Customer;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_SearchCustomer;
        private System.Windows.Forms.Button btn_EditUser;
        private System.Windows.Forms.Button btn_AddNewUser;
        private System.Windows.Forms.TextBox txt_DistrictCustomer;
        private System.Windows.Forms.Label lbl_ActionStatus;
        private System.Windows.Forms.TextBox txt_OrderPrice;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel pnl_EditOrder;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txt_OrderCustomerDistrict;
        private System.Windows.Forms.TextBox txt_OrderCustomerCity;
        private System.Windows.Forms.TextBox txt_OrderCustomerMobile;
        private System.Windows.Forms.TextBox txt_OrderCustomerHomePhone;
        private System.Windows.Forms.TextBox txt_OrderCustomerName;
        private System.Windows.Forms.TextBox txt_OrderCustomerAddess;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btn_OrderPrint;
        private System.Windows.Forms.Button btn_OrderSave;
        private System.Windows.Forms.Button btn_OrderClose;
        private System.Windows.Forms.ComboBox cbb_OrderDeliverer;
        private System.Windows.Forms.ComboBox cbb_OrderKindGood;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_OrderId;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbb_Customer;
        private System.Windows.Forms.TextBox txt_OrderQuantity;
        private System.Windows.Forms.CheckBox ckb_CustomerDateFilter;
        private System.Windows.Forms.CheckBox ckb_CustomerRecordFilter;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txt_CustomerRecordFilter;
        private System.Windows.Forms.Timer tmr_SearchOrder;
        private System.Windows.Forms.Timer tmr_SearchCustomer;
        private System.Windows.Forms.Button btn_HomephoneDiary;
        private System.Windows.Forms.Button btn_MobileDiary;
        private System.Windows.Forms.SaveFileDialog sfd_ChooseBackupDBLocation;
        private System.Windows.Forms.OpenFileDialog ofd_ChooseBackupDB;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txt_PaidMoney;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txt_ReturnShell;
        private System.Windows.Forms.Label lbl_BorrowMoney;
        private System.Windows.Forms.Label lbl_BorrowShell;
        private System.Windows.Forms.ToolStripMenuItem sửaXóaMãHàngThôngThườngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýTàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhậtXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tàiKhoảnToolStripMenuItem1;
        private System.Windows.Forms.Button btn_addorder;
        public System.Windows.Forms.TreeView editTreeView;
        private System.Windows.Forms.ImageList imageList1;
        private GSS.DataAccessLayer.GSSTableAdapters.ValveOrdersTableAdapter valveOrdersTableAdapter1;
        private System.Windows.Forms.PrintDialog prd_Order;
        private System.Windows.Forms.Button btn_map;
        private System.Windows.Forms.PictureBox ptb_map;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox ptb_order;
        private System.Windows.Forms.ToolStripMenuItem tiệnÍchToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem gọiĐiệnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gửiTinNhắnToolStripMenuItem;
        private System.Windows.Forms.Button btn_addCustomerOrder;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_ORDER_SELLCODE;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_ORDER_CUSNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_ORDER_CUSTEL;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_ORDER_CUSADD;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_ORDER_GOODKIND;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_ORDER_QUANTITY;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_ORDER_PRICE;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_ORDER_DELIVERER;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_ORDER_SELLDATE;
        private System.Windows.Forms.DataGridViewButtonColumn COLUMN_NAME_ORDER_REMOVE;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btn_SendMessage;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_Call;
        private System.Windows.Forms.Button btn_duecustomer;
        private System.Windows.Forms.Button btn_salary;
        private System.Windows.Forms.Button btn_chart;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btn_exportexcel;
        private System.Windows.Forms.Button btn_diary;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_modemStatus;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.Timer tmr_CheckModem;
        private System.Windows.Forms.Timer tmr_UpdateStatus;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label lbl_borrow;
        private System.Windows.Forms.Panel pnl_Call;
        private System.Windows.Forms.Button btn_Hangup;
        private System.Windows.Forms.Label lbl_PhoneNo;
        private System.Windows.Forms.Label lbl_Timer;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Timer tmr_Call;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_CUSTOMER_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_CUSTOMER_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_CUSTOMER_ADDRESS;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_CUSTOMER_DISTRICT;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_CUSTOMER_CITY;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_CUSTOMER_HOMEPHONE;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLUMN_NAME_CUSTOMER_MOBILE;
        private System.Windows.Forms.DataGridViewButtonColumn COLUMN_NAME_CUSTOMER_REMOVE;
    }
}

