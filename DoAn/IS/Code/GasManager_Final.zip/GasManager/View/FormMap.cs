﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace GSS.View
{
    /// <summary>
    ///   Form get map and path to customer address
    /// </summary>
    public partial class FormMap : Form
    {
        private readonly int _customerId;

        private readonly String _folder = Path.GetDirectoryName(Application.ExecutablePath) + "\\Map\\";

        /// <summary>
        ///   Initializes a new instance of the "FormMap" form.
        /// </summary>
        /// <param name = "customerId">The customer id.</param>
        /// <param name = "address">The address.</param>
        public FormMap(int customerId, String address)
        {
            InitializeComponent();
            _customerId = customerId;
            wbs_map.Url =
                new Uri(Path.GetDirectoryName(Application.ExecutablePath) + "\\GMap\\index.html?addr=" + address);
        }

        [DllImport("gdi32.dll")]
        private static extern bool BitBlt(
            IntPtr hdcDest, // handle to destination DC
            int nXDest, // x-coord of destination upper-left corner
            int nYDest, // y-coord of destination upper-left corner
            int nWidth, // width of destination rectangle
            int nHeight, // height of destination rectangle
            IntPtr hdcSrc, // handle to source DC
            int nXSrc, // x-coordinate of source upper-left corner
            int nYSrc, // y-coordinate of source upper-left corner
            Int32 dwRop // raster operation code
            );

        /// <summary>
        ///   Handles the Click event of the button btn_capture.
        /// </summary>
        private void btn_capture_Click(object sender, EventArgs e)
        {
            RectangleToScreen(ClientRectangle);

            var g1 = wbs_map.CreateGraphics();
            Image myImage = new Bitmap(wbs_map.Width, wbs_map.Height, g1);
            var g2 = Graphics.FromImage(myImage);
            var dc1 = g1.GetHdc();
            var dc2 = g2.GetHdc();
            BitBlt(dc2, 0, 0, wbs_map.Width, wbs_map.Height, dc1, 0, 0, 13369376);
            g1.ReleaseHdc(dc1);
            g2.ReleaseHdc(dc2);

            if (!Directory.Exists(_folder))
            {
                Directory.CreateDirectory(_folder);
            }
            myImage.Save(string.Format("{0}{1}.jpg", _folder, _customerId), ImageFormat.Jpeg);

            MessageBox.Show("Hoàn thành", "Bản đồ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

namespace ScreenShotDemo
{
    /// <summary>
    ///   Provides functions to capture the entire screen, or a particular window, and save it to a file.
    /// </summary>
    public class ScreenCapture
    {
        /// <summary>
        ///   Creates an Image object containing a screen shot of the entire desktop
        /// </summary>
        /// <returns>screen</returns>
        public Image CaptureScreen()
        {
            return CaptureWindow(User32.GetDesktopWindow());
        }

        /// <summary>
        ///   Creates an Image object containing a screen shot of a specific window
        /// </summary>
        /// <param name = "handle">The handle to the window. (In windows forms, this is obtained by the Handle property)</param>
        /// <returns></returns>
        public Image CaptureWindow(IntPtr handle)
        {
            // get te hDC of the target window
            var hdcSrc = User32.GetWindowDC(handle);
            // get the size
            var windowRect = new User32.RECT();
            User32.GetWindowRect(handle, ref windowRect);
            var width = windowRect.right - windowRect.left;
            var height = windowRect.bottom - windowRect.top;
            // create a device context we can copy to
            var hdcDest = GDI32.CreateCompatibleDC(hdcSrc);
            // create a bitmap we can copy it to,
            // using GetDeviceCaps to get the width/height
            var hBitmap = GDI32.CreateCompatibleBitmap(hdcSrc, width, height);
            // select the bitmap object
            var hOld = GDI32.SelectObject(hdcDest, hBitmap);
            // bitblt over
            GDI32.BitBlt(hdcDest, 0, 0, width, height, hdcSrc, 0, 0, GDI32.SRCCOPY);
            // restore selection
            GDI32.SelectObject(hdcDest, hOld);
            // clean up
            GDI32.DeleteDC(hdcDest);
            User32.ReleaseDC(handle, hdcSrc);
            // get a .NET image object for it
            Image img = Image.FromHbitmap(hBitmap);
            // free up the Bitmap object
            GDI32.DeleteObject(hBitmap);
            return img;
        }

        /// <summary>
        ///   Captures a screen shot of a specific window, and saves it to a file
        /// </summary>
        /// <param name = "handle">The handle.</param>
        /// <param name = "filename">The filename.</param>
        /// <param name = "format">The format.</param>
        public void CaptureWindowToFile(IntPtr handle, string filename, ImageFormat format)
        {
            var img = CaptureWindow(handle);
            img.Save(filename, format);
        }

        /// <summary>
        ///   Captures a screen shot of the entire desktop, and saves it to a file
        /// </summary>
        /// <param name = "filename">The filename.</param>
        /// <param name = "format">The format.</param>
        public void CaptureScreenToFile(string filename, ImageFormat format)
        {
            var img = CaptureScreen();
            img.Save(filename, format);
        }

        #region Nested type: GDI32

        /// <summary>
        ///   Helper class containing Gdi32 API functions
        /// </summary>
        private class GDI32
        {
            public const int SRCCOPY = 0x00CC0020; // BitBlt dwRop parameter

            [DllImport("gdi32.dll")]
            public static extern bool BitBlt(IntPtr hObject, int nXDest, int nYDest,
                                             int nWidth, int nHeight, IntPtr hObjectSource,
                                             int nXSrc, int nYSrc, int dwRop);

            /// <summary>
            ///   Creates the compatible bitmap.
            /// </summary>
            [DllImport("gdi32.dll")]
            public static extern IntPtr CreateCompatibleBitmap(IntPtr hDC, int nWidth,
                                                               int nHeight);

            /// <summary>
            ///   Creates the compatible DC.
            /// </summary>
            [DllImport("gdi32.dll")]
            public static extern IntPtr CreateCompatibleDC(IntPtr hDC);

            /// <summary>
            ///   Deletes the DC.
            /// </summary>
            [DllImport("gdi32.dll")]
            public static extern bool DeleteDC(IntPtr hDC);

            /// <summary>
            ///   Deletes the object.
            /// </summary>
            [DllImport("gdi32.dll")]
            public static extern bool DeleteObject(IntPtr hObject);

            /// <summary>
            ///   Selects the object.
            /// </summary>
            [DllImport("gdi32.dll")]
            public static extern IntPtr SelectObject(IntPtr hDC, IntPtr hObject);
        }

        #endregion

        #region Nested type: User32

        /// <summary>
        ///   Helper class containing User32 API functions
        /// </summary>
        private class User32
        {
            /// <summary>
            ///   Gets the desktop window.
            /// </summary>
            [DllImport("user32.dll")]
            public static extern IntPtr GetDesktopWindow();

            /// <summary>
            ///   Gets the window DC.
            /// </summary>
            [DllImport("user32.dll")]
            public static extern IntPtr GetWindowDC(IntPtr hWnd);

            /// <summary>
            ///   Releases the DC.
            /// </summary>
            [DllImport("user32.dll")]
            public static extern IntPtr ReleaseDC(IntPtr hWnd, IntPtr hDC);

            /// <summary>
            ///   Gets the window rect.
            /// </summary>
            [DllImport("user32.dll")]
            public static extern IntPtr GetWindowRect(IntPtr hWnd, ref RECT rect);

            #region Nested type: RECT

            [StructLayout(LayoutKind.Sequential)]
            public struct RECT
            {
                public readonly int left;

                public readonly int top;

                public readonly int right;

                public readonly int bottom;
            }

            #endregion
        }

        #endregion
    }
}