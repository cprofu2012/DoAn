﻿namespace GSS.View.Menu_Check
{
    partial class Check_Products
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Check_Products));
            this.lsb_ListDate = new System.Windows.Forms.ListBox();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.cbb_Deliverers = new System.Windows.Forms.ComboBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtg_Check = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_adddate = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Check)).BeginInit();
            this.SuspendLayout();
            // 
            // lsb_ListDate
            // 
            this.lsb_ListDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.lsb_ListDate.FormattingEnabled = true;
            this.lsb_ListDate.Location = new System.Drawing.Point(12, 12);
            this.lsb_ListDate.Name = "lsb_ListDate";
            this.lsb_ListDate.Size = new System.Drawing.Size(120, 433);
            this.lsb_ListDate.TabIndex = 0;
            // 
            // dtp_Date
            // 
            this.dtp_Date.Location = new System.Drawing.Point(193, 12);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(200, 20);
            this.dtp_Date.TabIndex = 1;
            // 
            // cbb_Deliverers
            // 
            this.cbb_Deliverers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_Deliverers.FormattingEnabled = true;
            this.cbb_Deliverers.Location = new System.Drawing.Point(495, 11);
            this.cbb_Deliverers.Name = "cbb_Deliverers";
            this.cbb_Deliverers.Size = new System.Drawing.Size(121, 21);
            this.cbb_Deliverers.TabIndex = 2;
            // 
            // btn_Save
            // 
            this.btn_Save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Save.Image = ((System.Drawing.Image)(resources.GetObject("btn_Save.Image")));
            this.btn_Save.Location = new System.Drawing.Point(614, 411);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(40, 40);
            this.btn_Save.TabIndex = 6;
            this.toolTip1.SetToolTip(this.btn_Save, "Lưu");
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(155, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Ngày";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(429, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Người kiểm";
            // 
            // dtg_Check
            // 
            this.dtg_Check.AllowUserToAddRows = false;
            this.dtg_Check.AllowUserToDeleteRows = false;
            this.dtg_Check.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_Check.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dtg_Check.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_Check.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Column3,
            this.Column1});
            this.dtg_Check.Location = new System.Drawing.Point(138, 38);
            this.dtg_Check.Name = "dtg_Check";
            this.dtg_Check.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_Check.Size = new System.Drawing.Size(516, 367);
            this.dtg_Check.TabIndex = 3;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "Tên hàng";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Số lượng";
            this.Column3.Name = "Column3";
            this.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "";
            this.Column1.Image = ((System.Drawing.Image)(resources.GetObject("Column1.Image")));
            this.Column1.MinimumWidth = 20;
            this.Column1.Name = "Column1";
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column1.Width = 20;
            // 
            // btn_Add
            // 
            this.btn_Add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Add.Image = ((System.Drawing.Image)(resources.GetObject("btn_Add.Image")));
            this.btn_Add.Location = new System.Drawing.Point(568, 411);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(40, 40);
            this.btn_Add.TabIndex = 5;
            this.toolTip1.SetToolTip(this.btn_Add, "Thêm hàng");
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_adddate
            // 
            this.btn_adddate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_adddate.Image = ((System.Drawing.Image)(resources.GetObject("btn_adddate.Image")));
            this.btn_adddate.Location = new System.Drawing.Point(522, 411);
            this.btn_adddate.Name = "btn_adddate";
            this.btn_adddate.Size = new System.Drawing.Size(40, 40);
            this.btn_adddate.TabIndex = 4;
            this.toolTip1.SetToolTip(this.btn_adddate, "Thêm ngày");
            this.btn_adddate.UseVisualStyleBackColor = true;
            this.btn_adddate.Click += new System.EventHandler(this.btn_adddate_Click);
            // 
            // Check_Products
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 460);
            this.Controls.Add(this.btn_adddate);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.dtg_Check);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.cbb_Deliverers);
            this.Controls.Add(this.dtp_Date);
            this.Controls.Add(this.lsb_ListDate);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Check_Products";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kiểm hàng";
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Check)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lsb_ListDate;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.ComboBox cbb_Deliverers;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dtg_Check;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_adddate;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewImageColumn Column1;
    }
}