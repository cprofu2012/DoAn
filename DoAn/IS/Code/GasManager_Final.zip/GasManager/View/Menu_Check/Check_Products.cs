﻿using System;
using System.Data;
using System.Windows.Forms;
using GSS.Control.Objects;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;

namespace GSS.View.Menu_Check
{
    /// <summary>
    /// Form check product
    /// </summary>
    public partial class Check_Products : Form
    {
        private readonly GSS_CheckTableAdapter _checkAdapter;
        private readonly GSS_CheckGasTableAdapter _checkGasAdapter;
        private readonly GSS_CheckShellTableAdapter _checkShellAdapter;
        private readonly DataTable _checkTable = new DataTable();
        private readonly GSS_CheckValveTableAdapter _checkValveAdapter;
        private readonly GSS_DelivererTableAdapter _deliverAdapter;
        private readonly GSS_GasTableAdapter _gasAdapter;
        private readonly GSS_ShellTableAdapter _shellAdapter;
        private readonly GSS_ValveTableAdapter _valveAdapter;
        
        private const string IDENTIFY_VALUE_GAS = "1";
        private const string IDENTIFY_VALUE_SHELL = "3";
        private const string IDENTIFY_VALUE_VALVE = "2";

        /// <summary>
        /// Initializes a new instance of the "Check_Products" form.
        /// </summary>
        public Check_Products()
        {
            InitializeComponent();

            _checkAdapter = new GSS_CheckTableAdapter();
            ;
            _checkShellAdapter = new GSS_CheckShellTableAdapter();
            _checkValveAdapter = new GSS_CheckValveTableAdapter();
            _checkGasAdapter = new GSS_CheckGasTableAdapter();
            _deliverAdapter = new GSS_DelivererTableAdapter();

            _gasAdapter = new GSS_GasTableAdapter();
            _valveAdapter = new GSS_ValveTableAdapter();
            _shellAdapter = new GSS_ShellTableAdapter();

            LoadDeliver();

            _checkTable.Columns.Add(Definitions.FIELD_TEXT);
            _checkTable.Columns.Add(Definitions.FIELD_VALUE);
            lsb_ListDate.DataSource = _checkTable;
            lsb_ListDate.DisplayMember = Definitions.FIELD_TEXT;
            lsb_ListDate.ValueMember = Definitions.FIELD_VALUE;

            DataAccessLayer.GSS.GSS_CheckDataTable checkes = _checkAdapter.GetChecks();

            foreach (DataAccessLayer.GSS.GSS_CheckRow check in checkes)
            {
                _checkTable.Rows.Add(new object[] {check.check_Date.ToString(), check.check_Id});
            }

            lsb_ListDate.SelectedIndexChanged += lsb_ListDate_SelectedIndexChanged;
            dtg_Check.RowsAdded += dtg_Check_RowsAdded;
            dtg_Check.CellClick += dtg_Check_CellClick;
        }

        /// <summary>
        /// Handles the CellClick event of the DataGridView dtg_Check.
        /// </summary>
        private void dtg_Check_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 2)
            {
                dtg_Check.Rows.RemoveAt(e.RowIndex);
            }
        }

        /// <summary>
        /// Handles the RowsAdded event of the datagridview dtg_Check.
        /// </summary>
        private void dtg_Check_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            GetProductsDataTable(((DataGridViewComboBoxCell) dtg_Check[0, dtg_Check.Rows.Count - 1]), null);
        }


        /// <summary>
        /// Handles the SelectedIndexChanged event of the listbox ListDate.
        /// </summary>
        private void lsb_ListDate_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtp_Date.Value = DateTime.Parse(_checkTable.Rows[lsb_ListDate.SelectedIndex][0].ToString());
            if (lsb_ListDate.SelectedValue == null || lsb_ListDate.SelectedValue == DBNull.Value)
            {
                dtg_Check.Rows.Clear();
            }
            else if (lsb_ListDate.SelectedValue != DBNull.Value)
            {
                dtg_Check.Rows.Clear();

                DataAccessLayer.GSS.GSS_CheckDataTable checkDatatable =
                    _checkAdapter.GetCheckById(Int32.Parse(lsb_ListDate.SelectedValue.ToString()));
                DataAccessLayer.GSS.GSS_CheckRow check = null;

                foreach (var checkTemp in checkDatatable)
                {
                    check = checkTemp;
                }

                dtp_Date.Value = check.check_Date;
                cbb_Deliverers.SelectedValue = check.check_DeliverId;

                DataAccessLayer.GSS.GSS_CheckShellDataTable checkshelles =
                    _checkShellAdapter.GetCheckShellById(check.check_Id);
                DataAccessLayer.GSS.GSS_CheckGasDataTable checkgases = _checkGasAdapter.GetCheckGasById(check.check_Id);
                DataAccessLayer.GSS.GSS_CheckValveDataTable checkvalves =
                    _checkValveAdapter.GetCheckValveById(check.check_Id);

                foreach (DataAccessLayer.GSS.GSS_CheckShellRow checkshell in checkshelles)
                {
                    dtg_Check.RowsAdded -= dtg_Check_RowsAdded;
                    dtg_Check.Rows.Add(new object[] {null, checkshell.checkShell_quantity});

                    dtg_Check.RowsAdded += dtg_Check_RowsAdded;
                    GetProductsDataTable(
                        ((DataGridViewComboBoxCell) dtg_Check.Rows[dtg_Check.Rows.Count - 1].Cells[0]),
                        IDENTIFY_VALUE_SHELL + "|" + checkshell.checkShell_ProductId);
                }
                foreach (DataAccessLayer.GSS.GSS_CheckGasRow checkgas in checkgases)
                {
                    dtg_Check.RowsAdded -= dtg_Check_RowsAdded;
                    dtg_Check.Rows.Add(new object[] {null, checkgas.checkGas_Quantity});
                    dtg_Check.RowsAdded += dtg_Check_RowsAdded;
                    GetProductsDataTable(
                        ((DataGridViewComboBoxCell) dtg_Check.Rows[dtg_Check.Rows.Count - 1].Cells[0]),
                        IDENTIFY_VALUE_GAS + "|" + checkgas.checkGas_ProductId);
                }
                foreach (DataAccessLayer.GSS.GSS_CheckValveRow checkvalve in checkvalves)
                {
                    dtg_Check.RowsAdded -= dtg_Check_RowsAdded;
                    dtg_Check.Rows.Add(new object[] {null, checkvalve.checkValve_quantity});
                    dtg_Check.RowsAdded += dtg_Check_RowsAdded;
                    GetProductsDataTable(
                        ((DataGridViewComboBoxCell) dtg_Check.Rows[dtg_Check.Rows.Count - 1].Cells[0]),
                        IDENTIFY_VALUE_VALVE + "|" + checkvalve.checkValve_ProductId);
                }
            }
        }

        /// <summary>
        /// Handles the Click event of the button Add.
        /// </summary>
        private void btn_Add_Click(object sender, EventArgs e)
        {
            dtg_Check.Rows.Add(new object[] {null, "0"});
        }

        /// <summary>
        /// Gets the products data table.
        /// </summary>
        /// <param name="combobox">The combobox.</param>
        /// <param name="selectedValue">The selected value of the combobox.</param>
        public void GetProductsDataTable(DataGridViewComboBoxCell combobox, object selectedValue)
        {
            var dataTable = new DataTable();
            dataTable.Columns.Add(Definitions.FIELD_TEXT);
            dataTable.Columns.Add(Definitions.FIELD_VALUE);
            combobox.DataSource = dataTable;
            combobox.DisplayMember = Definitions.FIELD_TEXT;
            combobox.ValueMember = Definitions.FIELD_VALUE;

            var gases = _gasAdapter.GetGass();
            var valves = _valveAdapter.GetValves();
            var shelles = _shellAdapter.GetShells();

            foreach (var gas in gases)
            {
                dataTable.Rows.Add(new object[] {gas.gas_Name, IDENTIFY_VALUE_GAS + "|" + gas.gas_Id});
            }
            foreach (var valve in valves)
            {
                dataTable.Rows.Add(new object[] {valve.valve_Name, IDENTIFY_VALUE_VALVE + "|" + valve.valve_Id});
            }
            foreach (DataAccessLayer.GSS.GSS_ShellRow shell in shelles)
            {
                dataTable.Rows.Add(new object[] {shell.shell_Name, IDENTIFY_VALUE_SHELL + "|" + shell.shell_Id});
            }


            if (selectedValue != null && selectedValue != DBNull.Value)
                combobox.Value = selectedValue;
            else if (dataTable.Rows.Count > 0)
                combobox.Value = dataTable.Rows[0][1];
        }

        /// <summary>
        /// Loads delivers.
        /// </summary>
        public void LoadDeliver()
        {
            var delivererTable = new DataTable();
            delivererTable.Columns.Add(Definitions.FIELD_TEXT);
            delivererTable.Columns.Add(Definitions.FIELD_VALUE);
            cbb_Deliverers.DataSource = delivererTable;
            cbb_Deliverers.DisplayMember = Definitions.FIELD_TEXT;
            cbb_Deliverers.ValueMember = Definitions.FIELD_VALUE;

            DataAccessLayer.GSS.GSS_DelivererDataTable deliverers = _deliverAdapter.GetDeliverers();
            foreach (DataAccessLayer.GSS.GSS_DelivererRow deliverer in deliverers)
            {
                if (deliverer.del_Id != 0)
                {
                    var dataRow = delivererTable.NewRow();
                    dataRow[0] = deliverer.del_Name;
                    dataRow[1] = deliverer.del_Id;
                    delivererTable.Rows.Add(dataRow);
                }
            }
        }

        /// <summary>
        /// Handles the Click event of the button Save.
        /// </summary>
        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (lsb_ListDate.SelectedValue == null || lsb_ListDate.SelectedValue == DBNull.Value)
            {
                foreach (DataGridViewRow row in dtg_Check.Rows)
                {
                    var productDetail = (row.Cells[0]).Value.ToString();
                    var strList = productDetail.Split(new[] {'|'});

                    try
                    {
                        Int32.Parse(strList[1]);
                    }
                    catch (Exception)
                    {
                        MessageBox.Show(Resources.Msb_Product_Checked_Error, Resources.Msb_Title_Error,
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    try
                    {
                        Int32.Parse(row.Cells[1].Value.ToString());
                    }
                    catch (Exception)
                    {
                        MessageBox.Show(Resources.Msb_Product_Check_Quantity, Resources.Msb_Title_Error,
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                _checkAdapter.InsertCheck(dtp_Date.Value, 0, Int32.Parse(cbb_Deliverers.SelectedValue.ToString()));
                var checkId = (int) _checkAdapter.GetLastCheck();

                foreach (DataGridViewRow row in dtg_Check.Rows)
                {
                    String productDetail = (row.Cells[0]).Value.ToString();
                    String[] strList = productDetail.Split(new[] {'|'});
                    int productId = Int32.Parse(strList[1]);

                    int quantity = Int32.Parse(row.Cells[1].Value.ToString());


                    if (strList[0].Equals(IDENTIFY_VALUE_GAS))
                    {
                        _checkGasAdapter.InsertCheckGas(productId, quantity, checkId);
                    }
                    else if (strList[0].Equals(IDENTIFY_VALUE_VALVE))
                    {
                        _checkValveAdapter.InsertCheckValve(quantity, productId, checkId);
                    }
                    else if (strList[0].Equals(IDENTIFY_VALUE_SHELL))
                    {
                        _checkShellAdapter.InsertCheckShell(quantity, productId, checkId);
                    }
                }
            }
            else if (lsb_ListDate.SelectedValue != DBNull.Value)
            {
                foreach (DataGridViewRow row in dtg_Check.Rows)
                {
                    var productDetail = (row.Cells[0]).Value.ToString();
                    var strList = productDetail.Split(new[] {'|'});

                    try
                    {
                        Int32.Parse(strList[1]);
                    }
                    catch (Exception)
                    {
                        MessageBox.Show(Resources.Msb_Product_Checked_Error, Resources.Msb_Title_Error,
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    try
                    {
                        Int32.Parse(row.Cells[1].Value.ToString());
                    }
                    catch (Exception)
                    {
                        MessageBox.Show(Resources.Msb_Product_Check_Quantity, Resources.Msb_Title_Error,
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                int checkId = Int32.Parse(lsb_ListDate.SelectedValue.ToString());
                _checkAdapter.UpdateCheck(dtp_Date.Value, 0, Int32.Parse(cbb_Deliverers.SelectedValue.ToString()),
                    checkId);
                _checkShellAdapter.DeleteCheckShellByCheckId(checkId);
                _checkGasAdapter.DeleteCheckGasByCheckId(checkId);
                _checkValveAdapter.DeleteCheckValveByCheckId(checkId);

                foreach (DataGridViewRow row in dtg_Check.Rows)
                {
                    var productDetail = (row.Cells[0]).Value.ToString();
                    var strList = productDetail.Split(new[] {'|'});
                    var productId = Int32.Parse(strList[1]);

                    var quantity = Int32.Parse(row.Cells[1].Value.ToString());


                    if (strList[0].Equals(IDENTIFY_VALUE_GAS))
                    {
                        _checkGasAdapter.InsertCheckGas(productId, quantity, checkId);
                    }
                    else if (strList[0].Equals(IDENTIFY_VALUE_VALVE))
                    {
                        _checkValveAdapter.InsertCheckValve(quantity, productId, checkId);
                    }
                    else if (strList[0].Equals(IDENTIFY_VALUE_SHELL))
                    {
                        _checkShellAdapter.InsertCheckShell(quantity, productId, checkId);
                    }
                }
            }
        }

        /// <summary>
        /// Handles the Click event of the button Add Date.
        /// </summary>
        private void btn_adddate_Click(object sender, EventArgs e)
        {
            _checkTable.Rows.Add(new object[] {DateTime.Now.ToString(), null});
            lsb_ListDate.SelectedIndex = lsb_ListDate.Items.Count - 1;

            dtg_Check.Enabled = true;
            dtp_Date.Enabled = true;
            cbb_Deliverers.Enabled = true;
        }
    }
}