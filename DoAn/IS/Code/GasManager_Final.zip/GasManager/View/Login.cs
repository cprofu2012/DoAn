﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using GasManager;
using GSS.DataAccessLayer.GSSTableAdapters;
using GSS.Properties;
using GSS.View.Menu_Report;

namespace GSS.View
{
    /// <summary>
    ///   Login form
    /// </summary>
    public partial class Login : Form
    {
        private readonly GSS_UserTableAdapter _userAdapter = new GSS_UserTableAdapter();
        private DataAccessLayer.GSS.GSS_UserRow _currUser;
        private MainForm _mainForm;

        /// <summary>
        ///   Initializes a new instance of the "Login" form.
        /// </summary>
        public Login()
        {
            InitializeComponent();
        }

        /// <summary>
        ///   Handles the Click event of the button btn_login.
        /// </summary>
        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_password.Text.Trim().Length == 0 || txt_username.Text.Trim().Length == 0)
            {
                txt_status.Text = Resources.Login_Miss_Field;
                return;
            }

            try
            {
                var users = _userAdapter.GetDataByUsername(txt_username.Text.Trim());
                if (users.Count == 0)
                {
                    txt_status.Text = Resources.Login_Account_Not_Exist;
                }
                else
                {
                    var password = String.Empty;
                    foreach (var user in users)
                    {
                        password = user.user_password;
                        _currUser = user;
                    }

                    string pass = GetMD5(txt_password.Text.Trim());
                    if (pass.Equals(password))
                    {
                        if (_currUser.user_active == 0 && _currUser.user_roleId != 1)
                        {
                            txt_status.Text = Resources.Login_Account_Deactive;
                            return;
                        }
                        Opacity = 0;

                        _mainForm = new MainForm(this, _currUser);
                        Hide();
                        _mainForm.Show();
                        var reportDueDate = new Report_DueDate();
                        reportDueDate.GetData(3, 0);
                        if (reportDueDate.dtg_due_due.Rows.Count > 0)
                            reportDueDate.ShowDialog();
                        else
                            reportDueDate.Dispose();
                    }
                    else
                    {
                        txt_status.Text = Resources.Login_Wrong_Password;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(Resources.Msb_Database_Error, Resources.Msb_Title_Database_Error,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        /// <summary>
        ///   Gets the MD5.
        /// </summary>
        /// <param name = "text">The text.</param>
        /// <returns>MD5 code</returns>
        private static string GetMD5(string text)
        {
            var UE = new UnicodeEncoding();
            var message = UE.GetBytes(text);
            MD5 hashString = new MD5CryptoServiceProvider();
            var hex = String.Empty;

            byte[] hashValue = hashString.ComputeHash(message);
            foreach (var x in hashValue)
            {
                hex += String.Format("{0:x2}", x);
            }
            return hex;
        }
    }
}