﻿namespace GSS.DataAccessLayer {
    
    
    public partial class GSS {
    }
}









