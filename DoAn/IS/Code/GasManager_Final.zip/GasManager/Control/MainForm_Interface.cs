﻿using System;

namespace GSS.Control
{
    /// <summary>
    /// Call function Interface 
    /// </summary>
    
    public interface IMainFormInterface
    {
        /// <summary>
        /// Receives the call.
        /// </summary>
        /// <param name="number">The number.</param>
        /// <param name="message">The message.</param>
        
        void ReceiveCall(String number, String message);

        /// <summary>
        /// Miss call.
        /// </summary>
        /// <param name="phoneNo">The phone number.</param>
        
        void UnAnswer(String phoneNo);

        /// <summary>
        /// Answers the call.
        /// </summary>
        /// <param name="phoneNo">The phone number.</param>
        
        void Answer(String phoneNo);
    }
}
