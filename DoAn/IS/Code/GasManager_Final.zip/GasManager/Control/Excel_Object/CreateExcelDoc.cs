﻿using System;
using System.Drawing;
using Microsoft.Office.Interop.Excel;

namespace GSS.Control.Excel_Object
{
    /// <summary>
    /// Export to excel helper class
    /// </summary>
    
    internal class CreateExcelDoc
    {
        private Application _app;
        private Range _workSheetRange;
        private Workbook _workbook;
        private Worksheet _worksheet;

        /// <summary>
        /// Initializes a new instance of the "CreateExcelDoc" form.
        /// </summary>
        
        public CreateExcelDoc()
        {
            CreateDoc();
        }

        /// <summary>
        /// Creates the doc.
        /// </summary>
        
        public void CreateDoc()
        {
            try
            {
                _app = new Application {Visible = true};
                _workbook = _app.Workbooks.Add(1);
                _worksheet = (Worksheet) _workbook.Sheets[1];
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Creates the headers.
        /// </summary>
        /// <param name="row">The row.</param>
        /// <param name="col">The col.</param>
        /// <param name="htext">The htext.</param>
        /// <param name="cell1">The cell1.</param>
        /// <param name="cell2">The cell2.</param>
        /// <param name="mergeColumns">The merge columns.</param>
        /// <param name="b">The b.</param>
        /// <param name="font">if set to <c>true</c> [font].</param>
        /// <param name="size">The size.</param>
        /// <param name="fcolor">The fcolor.</param>
        
        public void CreateHeaders(int row, int col, string htext, string cell1,
                                  string cell2, int mergeColumns, string b, bool font, int size, string
                                                                                                     fcolor)
        {
            _worksheet.Cells[row, col] = htext;
            _workSheetRange = _worksheet.Range[cell1, cell2];
            _workSheetRange.Merge(mergeColumns);
            switch (b)
            {
                case "YELLOW":
                    _workSheetRange.Interior.Color = Color.Yellow.ToArgb();
                    break;
                case "GRAY":
                    _workSheetRange.Interior.Color = Color.Gray.ToArgb();
                    break;
                case "GAINSBORO":
                    _workSheetRange.Interior.Color =
                        Color.Gainsboro.ToArgb();
                    break;
                case "Turquoise":
                    _workSheetRange.Interior.Color =
                        Color.Turquoise.ToArgb();
                    break;
                case "PeachPuff":
                    _workSheetRange.Interior.Color =
                        Color.PeachPuff.ToArgb();
                    break;
                default:
                    break;
            }

            _workSheetRange.Borders.Color = Color.Black.ToArgb();
            _workSheetRange.Font.Bold = font;
            _workSheetRange.ColumnWidth = size;
            _workSheetRange.Font.Color = fcolor.Equals(String.Empty) ? Color.White.ToArgb() : Color.Black.ToArgb();
        }

        /// <summary>
        /// Adds the data.
        /// </summary>
        /// <param name="row">The row.</param>
        /// <param name="col">The col.</param>
        /// <param name="data">The data.</param>
        /// <param name="cell1">The cell1.</param>
        /// <param name="cell2">The cell2.</param>
        /// <param name="format">The format.</param>
        
        public void AddData(int row, int col, string data,
                            string cell1, string cell2, string format)
        {
            _worksheet.Cells[row, col] = data;
            _workSheetRange = _worksheet.Range[cell1, cell2];
            _workSheetRange.Borders.Color = Color.Black.ToArgb();
            _workSheetRange.NumberFormat = format;
        }
    }
}