﻿using System.Windows.Forms;

namespace GSS.Control.Objects
{
    /// <summary>
    /// DataGridViewRow Promotion class
    /// </summary>
    
    internal class DataGridViewRow_Promotion : DataGridViewRow
    {
        public DataAccessLayer.GSS.GSS_PromotionGasRow gas_promotion;
        public DataAccessLayer.GSS.GSS_PromotionRow promotion;
        public DataAccessLayer.GSS.GSS_PromotionProductRow promotion_product;
        public DataAccessLayer.GSS.GSS_PromotionShellRow shell_promotion;
        public DataAccessLayer.GSS.GSS_PromotionValveRow valve_promotion;
    }
}