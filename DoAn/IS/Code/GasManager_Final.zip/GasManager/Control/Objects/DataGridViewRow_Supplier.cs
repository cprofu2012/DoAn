﻿using System.Windows.Forms;

namespace GSS.Control.Objects
{
    /// <summary>
    /// DataGridViewRow Supplier object
    /// </summary>
    
    internal class DataGridViewRow_Supplier : DataGridViewRow
    {
        public DataAccessLayer.GSS.GSS_SuppliersRow supplier;
    }
}