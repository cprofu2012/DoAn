﻿using System;
using System.Windows.Forms;

namespace GSS.Objects
{
    /// <summary>
    /// DataGridViewRow Order class
    /// </summary>
    
    internal class DataGridViewRow_Order : DataGridViewRow
    {
        public String cus_Address = String.Empty;
        public int cus_Id = -1;
        public String cus_Name = String.Empty;
        public String cus_Phone = String.Empty;
        public int del_Id = -1;
        public String del_Name = String.Empty;
        public String gas_Code = String.Empty;
        public int gas_Id = -1;
        public String gas_Price = String.Empty;
        public String gas_Quantity = String.Empty;
        public String kind_of_product = String.Empty;
        public DataAccessLayer.GSS.GSS_OrderRow row_order;

        public String val_Code = String.Empty;
        public int val_Id = -1;
        public String val_Price = String.Empty;
        public String val_Quantity = String.Empty;
    }
}