﻿using System;

namespace GSS.Control.Objects
{
    internal class Definitions
    {
        public static String COLUMN_NAME_CUSTOMER_ID = "COLUMN_NAME_CUSTOMER_ID";
        public static String COLUMN_NAME_CUSTOMER_NAME = "COLUMN_NAME_CUSTOMER_NAME";
        public static String COLUMN_NAME_CUSTOMER_DISTRICT = "COLUMN_NAME_CUSTOMER_DISTRICT";
        public static String COLUMN_NAME_CUSTOMER_ADDRESS = "COLUMN_NAME_CUSTOMER_ADDRESS";
        public static String COLUMN_NAME_CUSTOMER_CITY = "COLUMN_NAME_CUSTOMER_CITY";
        public static String COLUMN_NAME_CUSTOMER_MOBILE = "COLUMN_NAME_CUSTOMER_MOBILE";
        public static String COLUMN_NAME_CUSTOMER_HOMEPHONE = "COLUMN_NAME_CUSTOMER_HOMEPHONE";
        public static String COLUMN_NAME_CUSTOMER_GASID = "COLUMN_NAME_CUSTOMER_GASID";
        public static String COLUMN_NAME_CUSTOMER_VALID = "COLUMN_NAME_CUSTOMER_VALID";
        public static String COLUMN_NAME_CUSTOMER_SELLDATE = "COLUMN_NAME_CUSTOMER_SELLDATE";
        public static String COLUMN_NAME_CUSTOMER_REMOVE = "COLUMN_NAME_CUSTOMER_REMOVE";


        public static String COLUMN_NAME_ORDER_SELLCODE = "COLUMN_NAME_ORDER_SELLCODE";
        public static String COLUMN_NAME_ORDER_CUSNAME = "COLUMN_NAME_ORDER_CUSNAME";
        public static String COLUMN_NAME_ORDER_CUSTEL = "COLUMN_NAME_ORDER_CUSTEL";
        public static String COLUMN_NAME_ORDER_CUSADD = "COLUMN_NAME_ORDER_CUSADD";
        public static String COLUMN_NAME_ORDER_GOODKIND = "COLUMN_NAME_ORDER_GOODKIND";
        public static String COLUMN_NAME_ORDER_QUANTITY = "COLUMN_NAME_ORDER_QUANTITY";
        public static String COLUMN_NAME_ORDER_PRICE = "COLUMN_NAME_ORDER_PRICE";
        public static String COLUMN_NAME_ORDER_DELIVERER = "COLUMN_NAME_ORDER_DELIVERER";
        public static String COLUMN_NAME_ORDER_SELLDATE = "COLUMN_NAME_ORDER_SELLDATE";
        public static String COLUMN_NAME_ORDER_REMOVE = "COLUMN_NAME_ORDER_REMOVE";

        public static String FIELD_TEXT = "FieldText";
        public static String FIELD_VALUE = "FieldValue";

        public static String COMBOBOX_KINDOF_GAS = "Gas";
        public static String COMBOBOX_KINDOF_VALVE = "Valve";
        public static String COMBOBOX_KINDOF_SHELL = "Vỏ";

        public static String COLUMN_NAME_DELIVERER_NAME = "COLUMN_NAME_DELIVERER_NAME";
        public static String COLUMN_NAME_DELIVERER_TEL = "COLUMN_NAME_DELIVERER_TEL";
        public static String COLUMN_NAME_DELIVERER_CMT = "COLUMN_NAME_DELIVERER_CMT";
        public static String COLUMN_NAME_DELIVERER_REMOVE = "COLUMN_NAME_DELIVERER_REMOVE";

        public static String COLUMN_NAME_SUPPLIER_NAME = "COLUMN_NAME_SUPPLIER_NAME";
        public static String COLUMN_NAME_SUPPLIER_TEL = "COLUMN_NAME_SUPPLIER_TEL";
        public static String COLUMN_NAME_SUPPLIER_NOTE = "COLUMN_NAME_SUPPLIER_NOTE";
        public static String COLUMN_NAME_SUPPLIER_ADDRESS = "COLUMN_NAME_SUPPLIER_ADDRESS";
        public static String COLUMN_NAME_SUPPLIER_REMOVE = "COLUMN_NAME_SUPPLIER_REMOVE";


        public static String COLUMN_NAME_BORROWSHELL_CUSID = "COLUMN_NAME_BORROWSHELL_CUSID";
        public static String COLUMN_NAME_BORROWSHELL_NAME = "COLUMN_NAME_BORROWSHELL_NAME";
        public static String COLUMN_NAME_BORROWSHELL_PHONE = "COLUMN_NAME_BORROWSHELL_PHONE";
        public static String COLUMN_NAME_BORROWSHELL_BORROWNUMBER = "COLUMN_NAME_BORROWSHELL_BORROWNUMBER";
        public static String COLUMN_NAME_BORROWSHELL_KINDSHELL = "COLUMN_NAME_BORROWSHELL_KINDSHELL";

        public static String COLUMN_NAME_CALL_NUMBER = "COLUMN_NAME_CALL_NUMBER";
        public static String COLUMN_NAME_CALL_STATUS = "COLUMN_NAME_CALL_STATUS";

        public static String COLUMN_NAME_CHECKBOX = "checkboxHeader";

        public static int EXPIRED_DAY_GAS = 60;
        public static int EXPIRED_DAY_VALVE = 120;
        public static int EXPIRED_DAY_SHELL = 100;

        public static String EXPORT_TO_USE_DATE = "EXPORT_TO_USE_DATE";
        public static String EXPORT_TO_USE_PRODUCT = "EXPORT_TO_USE_PRODUCT";
        public static String EXPORT_TO_USE_QUANTITY = "EXPORT_TO_USE_QUANTITY";


        public static String PRODUCT_WITH_SHELL_NAME = "PRODUCT_WITH_SHELL_NAME";
        public static String PRODUCT_WITH_SHELL_REMOVE = "PRODUCT_WITH_SHELL_REMOVE";
        public static String PRODUCT_WITH_SHELL_KIND = "PRODUCT_WITH_SHELL_KIND";
        public static String PRODUCT_WITH_SHELL_IMPORT = "PRODUCT_WITH_SHELL_IMPORT";
        public static String PRODUCT_WITH_SHELL_PRICE = "PRODUCT_WITH_SHELL_PRICE";

        public static String EDIT_PRODUCT_NORMAL_NAME = "EDIT_PRODUCT_NORMAL_NAME";
        public static String EDIT_PRODUCT_NORMAL_IMPORTPRICE = "EDIT_PRODUCT_NORMAL_IMPORTPRICE";
        public static String EDIT_PRODUCT_NORMAL_SELLPRICE = "EDIT_PRODUCT_NORMAL_SELLPRICE";

        public static String CUSTOMER_HOMENUMBER = "cus_HomeNumber";
        public static String CUSTOMER_PHONENUMBER = "cus_PhoneNumber";
        public static String CUSTOMER_SELL_DATE = "cus_SellDate";

        public static String ORDER_SHELL_ID = "ode_ShellId";
        public static String ORDER_VALVE_ID = "ode_ValveId";
        public static String ORDER_GAS_ID = "ode_GasId";

        public static String BACKUP_FILTER = "Backup file|*.bak";

        public static int BAUD = 115200;
        public static int DATA_BITS = 8;
        public static String STOP_BITS = "1";
        public static String PARITY = "NONE";
        public static int RESPONSE_TIMEOUT = 500;
        public static int RECEIVE_TIMEOUT = 1000;

        public static string RESPONSE_OK = "\r\nOK\r\n";
        public static string RESPONSE_NO_CARRIER = "\r\nNO CARRIER\r\n";
        public static string RESPONSE_NO_ANSWER = "\r\nNO ANSWER\r\n";
        public static string RESPONSE_NO_DIALTONE = "\r\nNO DIALTONE\r\n";
        public static string RESPONSE_RING = "\r\nRING\r\n";
        public static string RESPONSE_END = "\r\n";
        public static string RESPONSE_BUSY = "\r\nBUSY\r\n";
        public static string RESPONSE_ERROR = "\r\nERROR\r\n";
        public static string RESPONSE_CONTINUE = "\r\n> ";

        public static string CALL_STATE = "CALL_STATE";
        public static string CALLING_STATE = "CALLING_STATE";
        public static string CALL_RECEIVING_STATE = "CALL_RECEIVING_STATE";
        public static string CALL_RECEIVED_STATE = "CALL_RECEIVED_STATE";
        public static string SMS_SENDING_STATE = "SMS_SENDING_STATE";
        public static string SMS_RECEIVING_STATE = "SMS_RECEIVING_STATE";
        public static string CHECK_STATE = "CHECK_STATE";

        public static string CMD_ERROR = "ERROR";
        public static string CMD_RECEIVE_SIGNAL = "+CLIP";
        public static string CMD_MESSAGE_FORMAT_CONFIG = "AT+CMGF=1";
        public static string CMD_MESSAGE_SEND = "AT+CMGS=\"";
        public static string CMD_DIAL = "ATD";
        public static string CMD_ANSWER = "ATA";
        public static string CMD_STOP = "ATH";
        public static string CMD_CHECK = "AT+CPIN?";

        public static string QUERRY_SEARCHER = "SELECT * FROM Win32_PnPEntity";
        public static string FIELD_HARDWARE_ID = "HardwareId";
        public static string FIELD_NAME = "Name";
        public static string COM_FILTER = "COM";
    }
}