﻿using System;
using System.Windows.Forms;

namespace GSS.Objects
{
    public class TreeNode_User : TreeNode
    {
        public int call;
        public String cus_Address = String.Empty;
        public String cus_Avatar = String.Empty;
        public String cus_City = String.Empty;
        public String cus_Distric = String.Empty;
        public int cus_GasId = -1;
        public String cus_HomeNumber = String.Empty;
        public String cus_Name = String.Empty;
        public String cus_PhoneNumber = String.Empty;
        public DateTime cus_SellDate;
        public int cus_ValveId = -1;
        public bool isAnswered;
        public DataAccessLayer.GSS.GSS_CustomerRow node_customer;

        public TreeNode_User(String name)
        {
            Text = name;
            node_customer = null;
        }


        public void loadNode()
        {
            cus_Name = node_customer.cus_Name;
            cus_City = node_customer.cus_City;
            cus_Distric = node_customer.cus_Distric;
            cus_Address = node_customer.cus_Address;
            cus_HomeNumber = node_customer.cus_HomeNumber;
            cus_PhoneNumber = node_customer.cus_PhoneNumber;
            cus_Avatar = node_customer.cus_Avatar;

            cus_GasId = node_customer.IsNull("cus_GasId") ? -1 : node_customer.cus_GasId;
            cus_ValveId = node_customer.IsNull("cus_ValveId") ? -1 : node_customer.cus_ValveId;
            cus_SellDate = node_customer.IsNull("cus_SellDate") ? new DateTime() : node_customer.cus_SellDate;
        }
    }
}