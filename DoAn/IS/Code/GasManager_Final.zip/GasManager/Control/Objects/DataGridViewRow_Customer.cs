﻿using System.Windows.Forms;

namespace GSS.Objects
{
    /// <summary>
    /// DataGridViewRow Customer class
    /// </summary>
    
    internal class DataGridViewRow_Customer : DataGridViewRow
    {
        public DataAccessLayer.GSS.GSS_CustomerRow row_customer;
    }
}