﻿using System;
using System.IO;
using System.IO.Ports;
using System.Management;
using System.Text;
using System.Threading;
using GSS.Properties;

namespace GSS.Control.Objects
{
    public class Modem_Control
    {
        #region Definition

        #region Delegates

        public delegate void CallDelegate(string status, string phoneNo);

        public delegate void MessageDelegate(string responseMessage);

        #endregion

        public static AutoResetEvent receiveNow;
        public static string Status = String.Empty;
        public static string State = String.Empty;
        private bool _isAcceptResetState;
        private bool isOK = false;
        int timeout = 300;
        private DateTime dt;
        string _buffer = string.Empty;

        public CallDelegate CallFormDelegate; // Cap nhat trang thai cuoc goi di
        public CallDelegate CallReceiveDelegate; // Cap nhat thong tin cuoc goi toi
        public MessageDelegate SMSDelegate;
        private SerialPort _port = new SerialPort();

        #endregion

        #region Get Com port from hardware ID OK

        /// <summary>
        /// Gets the name of COM port by hardware id.
        /// </summary>
        /// <param name="hardwareId">The hardware id.</param>
        /// <returns>Return the name of COM port</returns>
        public string GetComPort(string hardwareId)
        {
            try
            {
                var searcher =
                    new ManagementObjectSearcher(Definitions.QUERRY_SEARCHER);

                foreach (ManagementObject port in searcher.Get())
                {
                    string name = port[Definitions.FIELD_NAME].ToString();
                    if (name.Contains(Definitions.COM_FILTER))
                    {
                        var o = (string[])port[Definitions.FIELD_HARDWARE_ID];
                        if (o != null)
                        {
                            if (o.Length > 1)
                            {
                                string[] sp = SerialPort.GetPortNames();
                                if (o[1] == hardwareId)
                                {
                                    foreach (string portName in sp)
                                    {
                                        if (name.Contains(portName)) return portName;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (ManagementException)
            {
            }
            return null;
        }

        #endregion

        #region Open - Close port OK

        /// <summary>
        /// Opens the COM port.
        /// </summary>
        public void OpenPort()
        {
            if (_port.IsOpen) return;
            receiveNow = new AutoResetEvent(false);
            _port = new SerialPort
            {
                BaudRate = int.Parse(Resources.BAUD),
                DataBits = Definitions.DATA_BITS,
                DtrEnable = true,
                RtsEnable = true,
                ReadTimeout = Definitions.RECEIVE_TIMEOUT,
                WriteTimeout = Definitions.RESPONSE_TIMEOUT,
                Encoding = Encoding.GetEncoding(Resources.Message_Encoding)
            };
            switch (Definitions.PARITY)
            {
                case "Odd":
                    _port.Parity = Parity.Odd;
                    break;
                case "None":
                    _port.Parity = Parity.None;
                    break;
                case "Even":
                    _port.Parity = Parity.Even;
                    break;
            }
            switch (Definitions.STOP_BITS)
            {
                case "1":
                    _port.StopBits = StopBits.One;
                    break;
                case "1.5":
                    _port.StopBits = StopBits.OnePointFive;
                    break;
                case "2":
                    _port.StopBits = StopBits.Two;
                    break;
            }
            _port.DataReceived += PortDataReceived;
            try
            {
                _port.PortName = GetComPort(Resources.HardwareID);

                _port.Open();
                //         ExecCommand("AT+CLIP=1", Properties.Resources.Error_Modem_Connect);
            }
            catch (Exception)
            {
                throw new ApplicationException(Resources.Error_Modem_Connect);
            }
        }

        /// <summary>
        /// Closes the COM port.
        /// </summary>
        public void ClosePort()
        {
            if (!_port.IsOpen) return;
            try
            {
                _port.Close();
                _port.DataReceived -= PortDataReceived;
                _port = null;
            }
            catch { }
        }

        #endregion

        #region Execute Command OK
        /// <summary>
        /// Send AT command to SIM module, throw new exception if have.
        /// </summary>
        /// <param name="command">AT command.</param>
        /// <param name="errorMessage">error to throw exception</param>
        
        public void ExecCommand(string command, string errorMessage)
        {
            try
            {
                _port.DiscardOutBuffer();
                _port.DiscardInBuffer();
                receiveNow.Reset();
                _port.Write(command + "\r");
            }
            catch (IOException ex)
            {
                throw new ApplicationException(Resources.Error_Modem_Connect);
            }
            catch { }
        }

        /// <summary>
        /// Send AT command to SIM module, receive response and check the result.
        /// </summary>
        /// <param name="input">AT command.</param>
        /// <param name="expect">The expect. of the result</param>
        /// <returns>boolean value whether the expect is ok</returns>
        private bool ExecuteCommand(string input, string expect)
        {
            lock (this)
            {
                string command = input + "\r";
                receiveNow.Reset();
                // write command
                _port.DiscardOutBuffer();
                _port.DiscardInBuffer();
                _port.Write(command);
                // receive response
                string result = "";
                while (receiveNow.WaitOne(timeout, false))
                {
                    //           receiveNow.Reset();

                    for (string str = _port.ReadExisting(); str.Length > 0; str = _port.ReadExisting())
                    {
                        result += str;
                    }
                }
                return result.Contains(expect);
            }
        }
        #endregion

        #region Receive Data

        /// <summary>
        /// Ports the data received.
        /// </summary>
        public void PortDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (e.EventType == SerialData.Chars)
            {
                receiveNow.Set();
            }
            if (State != Definitions.SMS_SENDING_STATE)
                CallStatus();
        }

        /// <summary>
        /// Reads the response.
        /// </summary>
        /// <returns>existing data on input stream</returns>
        public string ReadResponse()
        {
            _buffer = String.Empty;
            do
            {
                if (receiveNow.WaitOne(timeout, false))
                {
                    string t = _port.ReadExisting();
                    _buffer += t;
                    Console.WriteLine("buffer " + _buffer + "|||");
                }
                else
                {
                    Console.WriteLine("exception");
                    throw new ApplicationException(Resources.Error_Response_Not_Received);
                }
            } while (!_buffer.EndsWith(Definitions.RESPONSE_OK) &&
                     !_buffer.EndsWith(Definitions.RESPONSE_NO_CARRIER) &&
                     !_buffer.EndsWith(Definitions.RESPONSE_NO_ANSWER) &&
                     !_buffer.EndsWith(Definitions.RESPONSE_NO_DIALTONE) &&
                     !_buffer.EndsWith(Definitions.RESPONSE_RING) &&
                     !_buffer.EndsWith(Definitions.RESPONSE_END) &&
                     !_buffer.EndsWith(Definitions.RESPONSE_BUSY) &&
                     !_buffer.EndsWith(Definitions.RESPONSE_ERROR) &&
                     !_buffer.EndsWith(Definitions.RESPONSE_CONTINUE));

            Console.WriteLine((DateTime.Now - dt).TotalMilliseconds);
            _isAcceptResetState = true;
            isOK = true;
            return _buffer;
        }

        #endregion

        /// <summary>
        /// Status of the call.
        /// </summary>
        public void CallStatus()
        {
            string result;
            string number;
            string responseData;
            try
            {
                responseData = ReadResponse();
             //   Console.WriteLine("response: " + responseData + "|| " + State + " |");
                #region Xử lý cuộc gọi
                #region Có cuộc gọi đến
                if (responseData.Contains(Definitions.CMD_RECEIVE_SIGNAL))
                {
                    int posStart = responseData.IndexOf("\"");
                    int posEnd = responseData.IndexOf("\"", posStart + 1);
                    number = responseData.Substring(posStart + 1, posEnd - posStart - 1);
                    result = Resources.Call_Receive_Number + number;
                    State = Definitions.CALL_RECEIVING_STATE;
                    CallReceiveDelegate(result, number);
                }
                #endregion
                #region
                if (responseData.Contains("+CCWA"))
                {
                    ExecuteCommand("AT+CHLD=0", Definitions.RESPONSE_OK);
                    result = Resources.Call_Missed;
                    number = Resources.Call_Finished_Signal;
                    State = String.Empty;
                    CallReceiveDelegate(result, number);
                }
                #endregion

                // 
                // if (!_isAcceptResetState)
                //   return;

                #region Không phải gọi đến, không phải gọi đi, không phải đang check???
                if (State.Equals(String.Empty))
                    return;
                #endregion
                #region Gọi đi
                if (State.Equals(Definitions.CALLING_STATE))                        // đang gọi đi
                {
           //         Console.WriteLine("Calling state");
                    if (responseData.EndsWith(Definitions.RESPONSE_OK))
                    {
            //            Console.WriteLine("Response OK");
                        result = Resources.Call_Calling;
                        number = String.Empty;
                        State = Definitions.CALL_STATE;
                        CallFormDelegate(result, number);
                        return;
                    }
                }
                else if (State.Equals(Definitions.CALL_STATE))
                {
          //          Console.WriteLine("Call state");
                    if (responseData.EndsWith(Definitions.RESPONSE_OK))                 // kết thúc, dùng ATH
                    {

          //              Console.WriteLine("resonpose ok");
                        result = Resources.Call_Finished;
                        number = Resources.Call_Finished_Signal;
                        State = String.Empty;
                        CallFormDelegate(result, number);
                    }
                    if (responseData.EndsWith(Definitions.RESPONSE_NO_ANSWER))          // ko trả lời
                    {
           //             Console.WriteLine("no answer");
                        result = Resources.Call_No_Answer;
                        number = Resources.Call_Finished_Signal;
                        State = String.Empty;
                        CallFormDelegate(result, number);
                    }
                    else if (responseData.EndsWith(Definitions.RESPONSE_NO_CARRIER))    // đã trả lời - gọi xong
                    {
            //            Console.WriteLine("No carrier");
                        result = Resources.Call_Finished;
                        number = Resources.Call_Finished_Signal;
                        State = String.Empty;
                        CallFormDelegate(result, number);
                    }
                    else if (responseData.EndsWith(Definitions.RESPONSE_BUSY))          // máy bận
                    {
             //           Console.WriteLine("busy");
                        result = Resources.Call_Busy;
                        number = Resources.Call_Finished_Signal;
                        State = String.Empty;
                        CallFormDelegate(result, number);
                    }
                }
                #endregion
                #region Gọi đến
                else if (State.Equals(Definitions.CALL_RECEIVING_STATE))
                {
                    if (responseData.EndsWith(Definitions.RESPONSE_OK))
                    {

            //            Console.WriteLine("call receiving state, resonpose ok");
                        result = Resources.Call_Received;
                        number = String.Empty;
                        State = Definitions.CALL_RECEIVED_STATE;
                        CallReceiveDelegate(result, number);
                    }
                    if (responseData.EndsWith(Definitions.RESPONSE_NO_CARRIER))
                    {
             //           Console.WriteLine("call receiving state, resonpose no carrier");
                        result = Resources.Call_Missed;
                        number = Resources.Call_Finished_Signal;
                        State = String.Empty;
                        CallReceiveDelegate(result, number);
                    }
                }
                #endregion
                #region Kết thúc cuộc gọi
                else if (State.Equals(Definitions.CALL_RECEIVED_STATE))
                {
                    if (responseData.EndsWith(Definitions.RESPONSE_NO_CARRIER))         // nhận cuộc gọi -> cuộc gọi kết thúc
                    {
          //              Console.WriteLine("call received state, resonpose no carrier");
                        result = Resources.Call_Finished;
                        number = Resources.Call_Finished_Signal;
                        State = String.Empty;
                        CallReceiveDelegate(result, number);
                        CallFormDelegate(result, number);
                    }
                }
                #endregion
                #endregion

                _isAcceptResetState = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                if (_isAcceptResetState && !ex.Message.Equals(Resources.Error_Response_Not_Received))
                {
                    if (State.Equals(Definitions.CALL_STATE))
                        CallFormDelegate(ex.Message, Resources.Call_Finished_Signal);
                    else if (State.Equals(Definitions.CALL_RECEIVED_STATE))
                        CallReceiveDelegate(ex.Message, Resources.Call_Finished_Signal);

                    State = String.Empty;
                }
            }
        }


        #region SMS module    sent
        /// <summary>
        /// Sends the SMS.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="phoneNo">The phone no.</param>
        public string SendSMS(string message, string phoneNo)
        {
            lock (this)
            {
                State = Definitions.SMS_SENDING_STATE;
                try
                {
                    String command = Definitions.CMD_MESSAGE_SEND + phoneNo + "\"";
                    bool isgood = ExecuteCommand(command, Definitions.RESPONSE_CONTINUE);
                    if (!isgood)
                    {
                        return Resources.Error_Phone_No;
                    }
                    command = message + char.ConvertFromUtf32(26) + "\r";
                    timeout = 5000;
                    isgood = ExecuteCommand(command, "+CMGS:");
                    timeout = 1000;
                    State = String.Empty;
                    if (isgood)
                    {
                        return Resources.Message_Send_Success + " tới " + phoneNo;
                    }
                    return Resources.Error_Send_Message + " tới " + phoneNo;
                }
                catch (Exception ex)
                {
                    State = String.Empty;
                    return ex.Message;
                }
            }
        }

        /// <summary>
        /// Sends the multi SMS.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="list">The list of phone number.</param>
        public void SendMultiSMS(string message, string list)
        {
            string response;
            string[] strArr = list.Split(';');
            bool isgood = ExecuteCommand(Definitions.CMD_MESSAGE_FORMAT_CONFIG, Definitions.RESPONSE_OK);
            if (!isgood)
            {
                response = Resources.Error_Set_Message_Format;
                SMSDelegate(response);
            }
            else
                foreach (string t in strArr)
                {
                    if (t != "")
                    {
                        response = SendSMS(message, t);
                        SMSDelegate(response);
                    }
                }
        }
        #endregion

        /// <summary>
        /// Initializes a new instance of the "Modem_Control" class.
        /// </summary>
        public Modem_Control()
        {
            try
            {
                OpenPort();
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        /// <summary>
        /// Determines whether modem is connected.
        /// </summary>
        /// <returns><c>true</c> if modem is connected; otherwise, <c>false</c>.</returns>
        
        public bool IsConnected()
        {
            if (!_port.IsOpen)
                return false;

            if (State.Equals(Definitions.SMS_SENDING_STATE))
                return true;
            try
            {
                State = Definitions.CHECK_STATE;
                ExecCommand("AT", Resources.Error_Modem_Connect);
                Thread.Sleep(200);
                if (isOK)
                {
                    isOK = false;
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
     //           Console.WriteLine("IsConnect Ex: " + ex.Message);
                throw new ApplicationException(ex.Message);
            }
        }

        public string PortName()
        {
            return _port.PortName;
        }


        #region Calling module

        #region MakeCall
        
        /// <summary>
        /// Makes the call.
        /// </summary>
        /// <param name="number">The destination's phone number.</param>
        public void MakeCall(string number)
        {
            try
            {
                dt = DateTime.Now;
                State = Definitions.CALLING_STATE;
                ExecCommand(Definitions.CMD_DIAL + number + ";", Resources.Error_Connect);

            }
            catch (Exception ex)
            {
     //           Console.WriteLine("Call ex");
                CallFormDelegate(ex.Message, string.Empty);
            }

        }

        #endregion

        #region Receive Call

        /// <summary>
        /// Answer incoming call.
        /// </summary>
        public void ReceiveCall()
        {
            try
            {
                State = Definitions.CALL_RECEIVED_STATE;
                ExecCommand(Definitions.CMD_ANSWER, Resources.Error_Connect);
            }
            catch (Exception ex)
            {
     //           Console.WriteLine("receive cal");
                throw new ApplicationException(ex.Message);
            }
        }

        #endregion

        #region Hang Up Call

        /// <summary>
        /// Hangs up a call.
        /// </summary>
        public void HangUpCall()
        {
            try
            {
                dt = DateTime.Now;
                State = Definitions.CALL_STATE;
                ExecCommand(Definitions.CMD_STOP, Resources.Error_Connect);
                CallReceiveDelegate(Resources.Call_Finished, Resources.Call_Finished_Signal);
                CallFormDelegate(Resources.Call_Finished, Resources.Call_Finished_Signal);
            }
            catch (Exception ex)
            {
       //         Console.WriteLine("hang up");
                throw new ApplicationException(Resources.Error_Connect);
            }
        }

        #endregion

        #endregion

    }
}