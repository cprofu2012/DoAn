﻿using System.Windows.Forms;

namespace GSS.Control.Objects
{
    /// <summary>
    /// DataGridViewRow Shelled Product class
    /// </summary>
    
    internal class DataGridViewRow_ShelledProduct : DataGridViewRow
    {
        public bool isShell;
        public int productId;

        /// <summary>
        /// Sets the attribute.
        /// </summary>
        /// <param name="_isShell">if set to <c>true</c> [_isshell].</param>
        /// <param name="_productId">The _product id.</param>
        
        public void SetAttribute(bool _isShell, int _productId)
        {
            isShell = _isShell;
            productId = _productId;
        }
    }
}