﻿using System.Windows.Forms;

namespace GSS.Control.Objects
{
    /// <summary>
    /// DataGridViewRow Nomal Product class
    /// </summary>
    
    internal class DataGridViewRow_NomalProduct : DataGridViewRow
    {
        public int productId;
    }
}