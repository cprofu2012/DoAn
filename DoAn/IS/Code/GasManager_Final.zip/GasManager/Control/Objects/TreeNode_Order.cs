﻿using System;
using System.Windows.Forms;

namespace GSS.Control.Objects
{
    /// <summary>
    /// TreeNode class
    /// </summary>
    internal class TreeNode_Order : TreeNode
    {
        public DataAccessLayer.GSS.GSS_OrderRow node_order;
        public int ode_BorrowMoney;


        public int ode_CustomerId;
        public DateTime ode_Date;
        public int ode_DelivererId;
        public int ode_GasId = -1;
        public int ode_GasValueId = -1;
        public int ode_PaidMoney;
        public int ode_Quantity;
        public int ode_ReturnShell;
        public int ode_ShellId = -1;
        public int ode_ShellValueId = -1;
        public int ode_ValveId = -1;
        public int ode_ValveValueId = -1;
        public String ode_comment;


        /// <summary>
        ///   Initializes a new instance of the "TreeNode_Order" class.
        /// </summary>
        /// <param name = "name">The name.</param>
        public TreeNode_Order(String name)
        {
            Text = name;
            node_order = null;
        }

        /// <summary>
        ///   Loads the node.
        /// </summary>
        public void LoadNode()
        {
            if (node_order == null)
                return;
            ode_CustomerId = node_order.ode_CustomerId;
            ode_Quantity = node_order.ode_Quantity;
            ode_Date = node_order.ode_Date;
            ode_DelivererId = node_order.ode_DelivererId;
            ode_comment = node_order.ode_Comment;

            ode_GasId = node_order.IsNull("ode_GasId") ? -1 : node_order.ode_GasId;
            ode_ValveId = node_order.IsNull("ode_ValveId") ? -1 : node_order.ode_ValveId;
            ode_GasValueId = node_order.IsNull("ode_GasValueId") ? -1 : node_order.ode_GasValueId;
            ode_ValveValueId = node_order.IsNull("ode_ValveValueId") ? -1 : node_order.ode_ValveValueId;
            ode_ShellId = node_order.IsNull("ode_ShellId") ? -1 : node_order.ode_ShellId;
            ode_ShellValueId = node_order.IsNull("ode_ShellValueId") ? -1 : node_order.ode_ShellValueId;
            ode_ReturnShell = node_order.IsNull("ode_ReturnShell") ? 0 : node_order.ode_ReturnShell;
            ode_PaidMoney = node_order.IsNull("ode_PaidMoney") ? 0 : node_order.ode_PaidMoney;
            ode_BorrowMoney = node_order.IsNull("ode_BorrowMoney") ? 0 : node_order.ode_BorrowMoney;
        }
    }
}