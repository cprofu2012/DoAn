﻿using System.Windows.Forms;

namespace GSS.Control.Objects
{
    /// <summary>
    /// DataGridViewRow Deliverer class
    /// </summary>
    
    internal class DataGridViewRow_Deliverer : DataGridViewRow
    {
        public DataAccessLayer.GSS.GSS_DelivererRow deliver;
    }
}